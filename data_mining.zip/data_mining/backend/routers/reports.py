"""Reports router for listing analysis artifacts, exporting CSV records, and generating PDF dossiers."""

import io
from typing import Optional
from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from database import get_db
from models import Dataset, AnalysisResult
from schemas import ReportListResponse, ReportInfo
from routers.helpers import get_dataset_or_404
from services.report_service import generate_pdf_report, generate_csv_report

router = APIRouter()


@router.get("/list", response_model=ReportListResponse)
def list_reports(
    dataset_id: Optional[int] = Query(None, description="Optional dataset ID filter"),
    db: Session = Depends(get_db),
):
    """
    List historical data mining analysis records.
    """
    query = db.query(AnalysisResult)
    if dataset_id is not None:
        query = query.filter(AnalysisResult.dataset_id == dataset_id)

    reports = query.order_by(AnalysisResult.created_at.desc()).all()

    report_items = [
        ReportInfo(
            id=r.id,
            dataset_id=r.dataset_id,
            analysis_type=r.analysis_type,
            created_at=r.created_at,
            parameters=r.parameters or {},
            status=r.status or "completed",
        )
        for r in reports
    ]

    return ReportListResponse(
        reports=report_items,
        total=len(report_items),
    )


@router.get("/csv/{analysis_id}")
def export_csv_report(
    analysis_id: int,
    db: Session = Depends(get_db),
):
    """
    Export specific analysis results as a downloadable CSV table.
    """
    analysis = db.query(AnalysisResult).filter(AnalysisResult.id == analysis_id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail=f"Analysis result {analysis_id} not found.")

    payload = {
        "id": analysis.id,
        "dataset_id": analysis.dataset_id,
        "analysis_type": analysis.analysis_type,
        "parameters": analysis.parameters or {},
        "results": analysis.results or {},
        "summary": analysis.summary or {},
    }

    try:
        csv_content = generate_csv_report(payload)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate CSV report: {str(e)}",
        )

    stream = io.BytesIO(csv_content.encode("utf-8"))
    filename = f"analysis_{analysis.analysis_type}_{analysis.id}.csv"

    return StreamingResponse(
        stream,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.get("/pdf/{dataset_id}")
def export_pdf_report(
    dataset_id: int,
    db: Session = Depends(get_db),
):
    """
    Generate and download a comprehensive multi-section PDF analytical dossier.
    """
    dataset = get_dataset_or_404(db, dataset_id)

    analyses = (
        db.query(AnalysisResult)
        .filter(AnalysisResult.dataset_id == dataset_id)
        .order_by(AnalysisResult.created_at.asc())
        .all()
    )

    dataset_info = {
        "id": dataset.id,
        "name": dataset.name,
        "filename": dataset.filename,
        "original_filename": dataset.original_filename,
        "row_count": dataset.row_count,
        "column_count": dataset.column_count,
        "has_coordinates": dataset.has_coordinates,
        "has_timestamps": dataset.has_timestamps,
        "cleaning_report": dataset.cleaning_report or {},
    }

    analyses_info = [
        {
            "id": a.id,
            "analysis_type": a.analysis_type,
            "parameters": a.parameters or {},
            "results": a.results or {},
            "summary": a.summary or {},
        }
        for a in analyses
    ]

    try:
        pdf_bytes = generate_pdf_report(dataset_info, analyses_info)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate PDF report: {str(e)}",
        )

    stream = io.BytesIO(pdf_bytes)
    filename = f"analytical_report_dataset_{dataset.id}.pdf"

    return StreamingResponse(
        stream,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
