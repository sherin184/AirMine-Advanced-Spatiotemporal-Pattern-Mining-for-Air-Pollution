"""Runner to generate synthetic dataset CSV files."""

import os
import sys

# Ensure local module import works
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from generate_sample import generate_synthetic_data

if __name__ == "__main__":
    sample_csv = os.path.join(current_dir, "synthetic_air_quality.csv")
    uploads_dir = os.path.join(os.path.dirname(current_dir), "uploads")
    upload_csv = os.path.join(uploads_dir, "synthetic_air_quality.csv")

    df = generate_synthetic_data(sample_csv)
    
    # Also save to uploads directory so it's readily available for dataset uploads / testing
    os.makedirs(uploads_dir, exist_ok=True)
    df.to_csv(upload_csv, index=False, na_rep="")
    print(f"Also wrote copy to: {upload_csv}")
