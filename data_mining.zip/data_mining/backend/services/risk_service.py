"""Risk profiling and health assessment service using EPA AQI standards."""

from typing import Dict, List, Any, Optional
import numpy as np
import pandas as pd

# EPA AQI Breakpoints (Concentration Low, Concentration High, AQI Low, AQI High)
AQI_BREAKPOINTS = {
    "PM2_5": [
        (0.0, 12.0, 0, 50),
        (12.1, 35.4, 51, 100),
        (35.5, 55.4, 101, 150),
        (55.5, 150.4, 151, 200),
        (150.5, 250.4, 201, 300),
        (250.5, 500.0, 301, 500),
    ],
    "PM10": [
        (0.0, 54.0, 0, 50),
        (55.0, 154.0, 51, 100),
        (155.0, 254.0, 101, 150),
        (255.0, 354.0, 151, 200),
        (355.0, 424.0, 201, 300),
        (425.0, 604.0, 301, 500),
    ],
    "NO2": [
        (0.0, 53.0, 0, 50),
        (54.0, 100.0, 51, 100),
        (101.0, 360.0, 101, 150),
        (361.0, 649.0, 151, 200),
        (650.0, 1249.0, 201, 300),
        (1250.0, 2049.0, 301, 500),
    ],
    "SO2": [
        (0.0, 35.0, 0, 50),
        (36.0, 75.0, 51, 100),
        (76.0, 185.0, 101, 150),
        (186.0, 304.0, 151, 200),
        (305.0, 604.0, 201, 300),
        (605.0, 1004.0, 301, 500),
    ],
    "CO": [
        (0.0, 4.4, 0, 50),
        (4.5, 9.4, 51, 100),
        (9.5, 12.4, 101, 150),
        (12.5, 15.4, 151, 200),
        (15.5, 30.4, 201, 300),
        (30.5, 50.4, 301, 500),
    ],
    "O3": [
        (0.0, 54.0, 0, 50),
        (55.0, 70.0, 51, 100),
        (71.0, 85.0, 101, 150),
        (86.0, 105.0, 151, 200),
        (106.0, 200.0, 201, 300),
        (201.0, 604.0, 301, 500),
    ],
}

CATEGORY_ORDER = [
    "Good",
    "Moderate",
    "Unhealthy_Sensitive",
    "Unhealthy",
    "Very_Unhealthy",
    "Hazardous",
]

RECOMMENDATIONS_MAP = {
    "Good": "Air quality is satisfactory and poses little or no risk. Great conditions for outdoor activities.",
    "Moderate": "Air quality is acceptable; unusually sensitive individuals should consider limiting prolonged outdoor exertion.",
    "Unhealthy_Sensitive": "Members of sensitive groups (asthma, children, elderly) may experience health effects and should reduce strenuous outdoor activities.",
    "Unhealthy": "General public may begin to experience health effects; sensitive groups should avoid outdoor exertion and wear protective masks.",
    "Very_Unhealthy": "Health alert: The risk of health effects is increased for everyone. Avoid prolonged outdoor exertion and run indoor air filters.",
    "Hazardous": "Emergency conditions: Entire population is likely to be affected. Keep all windows closed, avoid outdoor activities, and use HEPA air purifiers.",
}


def get_risk_category(aqi_value: float) -> str:
    """Classify AQI score into standard EPA category."""
    if aqi_value <= 50:
        return "Good"
    elif aqi_value <= 100:
        return "Moderate"
    elif aqi_value <= 150:
        return "Unhealthy_Sensitive"
    elif aqi_value <= 200:
        return "Unhealthy"
    elif aqi_value <= 300:
        return "Very_Unhealthy"
    else:
        return "Hazardous"


def calculate_sub_index(concentration: float, pollutant: str) -> float:
    """
    Calculate AQI sub-index for a given pollutant concentration using EPA piecewise linear formula:
    I = ((I_high - I_low) / (C_high - C_low)) * (C - C_low) + I_low
    """
    if pd.isna(concentration) or concentration < 0:
        return 0.0

    breakpoints = AQI_BREAKPOINTS.get(pollutant)
    if not breakpoints:
        return float(concentration)

    for c_low, c_high, i_low, i_high in breakpoints:
        if c_low <= concentration <= c_high:
            sub = ((i_high - i_low) / (c_high - c_low)) * (concentration - c_low) + i_low
            return round(float(sub), 1)

    # If concentration exceeds highest breakpoint, extrapolate linearly
    c_low, c_high, i_low, i_high = breakpoints[-1]
    if concentration > c_high:
        sub = ((i_high - i_low) / (c_high - c_low)) * (concentration - c_low) + i_low
        return round(float(min(500.0, max(0.0, sub))), 1)

    return 0.0


def calculate_risk_profile(df: pd.DataFrame, column_mapping: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Generate an environmental risk profile based on EPA AQI standards.
    
    Returns:
        dict: {
            "overall_risk": str,
            "overall_score": float,
            "pollutant_risks": dict,
            "risk_distribution": dict,
            "risk_data": list[dict],
            "recommendations": list[str]
        }
    """
    if df.empty:
        raise ValueError("Cannot calculate risk profile on empty dataframe.")

    working_df = df.copy()
    if column_mapping:
        working_df = working_df.rename(columns=column_mapping)

    pollutant_keys = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3"]
    available_pollutants = [p for p in pollutant_keys if p in working_df.columns]

    # Calculate record-level AQI
    if "AQI" in working_df.columns and working_df["AQI"].notna().sum() > 0:
        record_aqi = pd.to_numeric(working_df["AQI"], errors="coerce")
    else:
        # Compute sub-indices for each pollutant and take max across pollutants
        sub_indices = pd.DataFrame(index=working_df.index)
        for p in available_pollutants:
            series = pd.to_numeric(working_df[p], errors="coerce")
            sub_indices[p] = series.apply(lambda val: calculate_sub_index(val, p) if pd.notna(val) else 0.0)
        
        if not sub_indices.empty:
            record_aqi = sub_indices.max(axis=1)
        else:
            record_aqi = pd.Series(0.0, index=working_df.index)

    # Impute missing record AQIs with median or 0
    aqi_median = record_aqi.median()
    record_aqi = record_aqi.fillna(aqi_median if pd.notna(aqi_median) else 0.0)

    # Assign risk category per record
    record_categories = record_aqi.apply(get_risk_category)

    # Distribution counts initialized with 0 for all standard categories
    risk_distribution: Dict[str, int] = {cat: 0 for cat in CATEGORY_ORDER}
    counts = record_categories.value_counts().to_dict()
    for cat, count in counts.items():
        if cat in risk_distribution:
            risk_distribution[cat] = int(count)

    overall_score = float(round(record_aqi.mean(), 2)) if len(record_aqi) > 0 else 0.0
    overall_risk = get_risk_category(overall_score)

    # Per-pollutant risk breakdown
    pollutant_risks: Dict[str, Dict[str, Any]] = {}
    for p in available_pollutants:
        series = pd.to_numeric(working_df[p], errors="coerce").dropna()
        if not series.empty:
            avg_val = round(float(series.mean()), 2)
            max_val = round(float(series.max()), 2)
            sub_idx = calculate_sub_index(avg_val, p)
            level = get_risk_category(sub_idx)
            pollutant_risks[p] = {
                "avg": avg_val,
                "max": max_val,
                "risk_level": level,
                "sub_index": sub_idx,
            }

    # Generate recommendations
    recommendations: List[str] = []
    recommendations.append(RECOMMENDATIONS_MAP.get(overall_risk, RECOMMENDATIONS_MAP["Moderate"]))

    # Specific pollutant alerts
    for p, stats in pollutant_risks.items():
        if stats["risk_level"] in ["Unhealthy", "Very_Unhealthy", "Hazardous"]:
            recommendations.append(
                f"Elevated levels of {p} detected (Index: {stats['sub_index']}). "
                f"Take precautions against {p} exposure."
            )

    # Assemble risk data (up to 1000 records)
    working_df["risk_score"] = record_aqi.round(1)
    working_df["risk_category"] = record_categories

    sample_size = min(len(working_df), 1000)
    records_subset = working_df.head(sample_size).to_dict(orient="records")

    sanitized_risk_data: List[Dict[str, Any]] = []
    for r in records_subset:
        row_clean = {}
        for k, v in r.items():
            if pd.isna(v) or v is None:
                row_clean[k] = None
            elif isinstance(v, (np.floating, float)):
                row_clean[k] = round(float(v), 2)
            elif isinstance(v, (np.integer, int)):
                row_clean[k] = int(v)
            else:
                row_clean[k] = str(v)
        sanitized_risk_data.append(row_clean)

    return {
        "overall_risk": overall_risk,
        "overall_score": overall_score,
        "pollutant_risks": pollutant_risks,
        "risk_distribution": risk_distribution,
        "risk_data": sanitized_risk_data,
        "recommendations": recommendations,
    }


def calculate_risk_trends(
    df: pd.DataFrame,
    column_mapping: Optional[Dict[str, str]] = None,
    period: str = "daily",
) -> Dict[str, Any]:
    """
    Calculate temporal risk trends grouped by daily, weekly, or monthly intervals.
    
    Returns:
        dict: {
            "trends": list[dict], # {period_label, avg_risk_score, risk_category, record_count}
            "period": str
        }
    """
    if df.empty:
        return {"trends": [], "period": period}

    working_df = df.copy()
    if column_mapping:
        working_df = working_df.rename(columns=column_mapping)

    if "timestamp" not in working_df.columns:
        # Return single aggregated trend if no timestamp
        profile = calculate_risk_profile(working_df)
        return {
            "trends": [
                {
                    "period_label": "All Time",
                    "avg_risk_score": profile["overall_score"],
                    "risk_category": profile["overall_risk"],
                    "record_count": len(working_df),
                }
            ],
            "period": period,
        }

    # Convert timestamps
    ts_series = pd.to_datetime(working_df["timestamp"], errors="coerce")
    valid_mask = ts_series.notna()
    if valid_mask.sum() == 0:
        return {"trends": [], "period": period}

    working_df = working_df[valid_mask].copy()
    working_df["parsed_time"] = ts_series[valid_mask]

    # Calculate AQI score per row
    pollutant_keys = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3"]
    available_pollutants = [p for p in pollutant_keys if p in working_df.columns]

    if "AQI" in working_df.columns and working_df["AQI"].notna().sum() > 0:
        working_df["aqi_score"] = pd.to_numeric(working_df["AQI"], errors="coerce")
    elif available_pollutants:
        sub_indices = pd.DataFrame(index=working_df.index)
        for p in available_pollutants:
            series = pd.to_numeric(working_df[p], errors="coerce")
            sub_indices[p] = series.apply(lambda val: calculate_sub_index(val, p) if pd.notna(val) else 0.0)
        working_df["aqi_score"] = sub_indices.max(axis=1)
    else:
        working_df["aqi_score"] = 0.0

    working_df["aqi_score"] = working_df["aqi_score"].fillna(working_df["aqi_score"].median())

    # Format period label
    if period.lower() == "weekly":
        working_df["period_group"] = working_df["parsed_time"].dt.to_period("W").astype(str)
    elif period.lower() == "monthly":
        working_df["period_group"] = working_df["parsed_time"].dt.strftime("%Y-%m")
    else:  # default daily
        working_df["period_group"] = working_df["parsed_time"].dt.strftime("%Y-%m-%d")

    trends_list: List[Dict[str, Any]] = []
    grouped = working_df.groupby("period_group", sort=True)

    for period_label, group in grouped:
        avg_score = round(float(group["aqi_score"].mean()), 2)
        trends_list.append({
            "period_label": str(period_label),
            "avg_risk_score": avg_score,
            "risk_category": get_risk_category(avg_score),
            "record_count": int(len(group)),
        })

    return {
        "trends": trends_list,
        "period": period,
    }
