import React, { useState, useEffect } from 'react'
import {
  Activity,
  Layers,
  AlertTriangle,
  Wind,
  ShieldAlert,
  Database,
  Calendar,
  Sparkles,
  TrendingUp,
  RefreshCw,
} from 'lucide-react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts'
import { useDataset } from '../hooks/useDataset'
import { api } from '../api/client'
import { KPICard } from '../components/common/KPICard'
import { PollutantLineChart } from '../components/charts/PollutantLineChart'
import { LoadingSpinner } from '../components/common/LoadingSpinner'
import type { KPIResponse, TrendDataPoint } from '../types'

const RISK_COLORS: Record<string, string> = {
  Good: '#10b981',
  Moderate: '#f59e0b',
  'Unhealthy (Sens.)': '#f97316',
  'Unhealthy for Sensitive Groups': '#f97316',
  Unhealthy: '#ef4444',
  'Very Unhealthy': '#a855f7',
  Hazardous: '#991b1b',
}

export const OverviewDashboard: React.FC = () => {
  const { selectedDatasetId, selectedDataset, datasets, refreshDatasets, isLoading: datasetLoading } = useDataset()
  const [kpis, setKpis] = useState<KPIResponse | null>(null)
  const [trends, setTrends] = useState<TrendDataPoint[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)
  const [loadingSample, setLoadingSample] = useState(false)

  const fetchData = async () => {
    if (!selectedDatasetId && datasets.length === 0) {
      setLoading(false)
      return
    }
    setLoading(true)
    setError(null)
    try {
      const [kpiRes, trendRes] = await Promise.all([
        api.overview.getKPIs(selectedDatasetId || undefined),
        api.overview.getTrends(selectedDatasetId || undefined),
      ])
      setKpis(kpiRes)
      setTrends(trendRes)
    } catch (err: any) {
      console.error('Failed to load overview data:', err)
      setError(
        err?.response?.data?.detail ||
          err?.message ||
          'Failed to connect to backend analytics server'
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [selectedDatasetId, datasets.length])

  const handleLoadSample = async () => {
    setLoadingSample(true)
    try {
      await api.datasets.loadSample()
      await refreshDatasets()
    } catch (err: any) {
      alert('Failed to load sample dataset: ' + (err?.response?.data?.detail || err?.message))
    } finally {
      setLoadingSample(false)
    }
  }

  // If no datasets exist at all
  if (!datasetLoading && datasets.length === 0) {
    return (
      <div className="glass-card p-12 text-center max-w-xl mx-auto my-12 border border-slate-800 space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-500/20 to-emerald-500/20 border border-teal-500/30 flex items-center justify-center mx-auto text-teal-400">
          <Database className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-100">Welcome to AirMine Analytics</h2>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            No environmental datasets are currently loaded in your environment. Load our verified synthetic IoT sensor dataset or upload your own CSV records to unlock advanced pattern mining.
          </p>
        </div>
        <div className="pt-2">
          <button
            onClick={handleLoadSample}
            disabled={loadingSample}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 mx-auto shadow-lg shadow-teal-500/25 transition disabled:opacity-50"
          >
            {loadingSample ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            Load Pre-configured Sample Dataset
          </button>
        </div>
      </div>
    )
  }

  if (loading || datasetLoading) {
    return <LoadingSpinner message="Calculating spatiotemporal KPIs and trend curves..." size="lg" />
  }

  // Prepare Risk distribution chart data
  const riskChartData = kpis?.risk_distribution
    ? Object.entries(kpis.risk_distribution).map(([category, count]) => ({
        category,
        count,
        color: RISK_COLORS[category] || '#38bdf8',
      }))
    : []

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner & Quick Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 glass-card p-5 border border-slate-800/80">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <span>Air Quality Intelligence Overview</span>
            {selectedDataset?.is_sample && (
              <span className="text-[10px] bg-teal-500/20 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded-full font-mono uppercase">
                Sample Data
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
            <span>Dataset: {selectedDataset?.name || 'All Datasets'}</span>
            {kpis?.date_range?.start && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1 font-mono text-[11px]">
                  <Calendar className="w-3 h-3 text-slate-500" />
                  {kpis.date_range.start.slice(0, 10)} to {kpis.date_range.end?.slice(0, 10)}
                </span>
              </>
            )}
          </p>
        </div>

        <button
          onClick={fetchData}
          className="self-start md:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 hover:border-teal-400 text-slate-300 hover:text-teal-300 text-xs transition"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Metrics</span>
        </button>
      </div>

      {/* 4 Main KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Total Observations"
          value={kpis?.total_records?.toLocaleString() ?? 0}
          subtitle={`Across ${kpis?.total_datasets ?? 1} active dataset(s)`}
          icon={Layers}
          accent="teal"
          trend={{ value: 'Live Stream', isPositive: true }}
        />
        <KPICard
          title="Average AQI"
          value={kpis?.avg_aqi !== null && kpis?.avg_aqi !== undefined ? kpis.avg_aqi.toFixed(1) : '—'}
          subtitle={
            (kpis?.avg_aqi || 0) > 100
              ? 'Exceeds standard clean air limits'
              : 'Within acceptable ambient norms'
          }
          icon={Activity}
          accent={(kpis?.avg_aqi || 0) > 100 ? 'rose' : 'emerald'}
        />
        <KPICard
          title="Anomaly Detection"
          value={
            kpis?.anomaly_percentage !== null && kpis?.anomaly_percentage !== undefined
              ? `${kpis.anomaly_percentage.toFixed(1)}%`
              : '—'
          }
          subtitle="Flagged by Isolation Forest"
          icon={AlertTriangle}
          accent={(kpis?.anomaly_percentage || 0) > 8 ? 'rose' : 'amber'}
        />
        <KPICard
          title="Datasets Managed"
          value={kpis?.total_datasets ?? datasets.length}
          subtitle="Active sensor corpora"
          icon={Database}
          accent="cyan"
        />
      </div>

      {/* Full Width Pollutant Trends Line Chart */}
      <div className="glass-card p-6 border border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-400" />
              Temporal Pollutant Trends
            </h3>
            <p className="text-xs text-slate-400">
              Aggregated time-series trajectory across sensor stations
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="text-slate-400">
              {trends.length} timestamp intervals plotted
            </span>
          </div>
        </div>

        <div className="mt-4">
          <PollutantLineChart
            data={trends}
            selectedPollutants={['pm25', 'pm10', 'no2', 'so2', 'o3']}
            threshold={50}
            thresholdLabel="WHO Moderate Cutoff (50)"
            height={360}
          />
        </div>
      </div>

      {/* Side-by-side: Risk Distribution Bar Chart + Pollutant Quick Stats Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Risk Distribution Chart */}
        <div className="lg:col-span-6 glass-card p-6 border border-slate-800/80 flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              AQI Health Category Distribution
            </h3>
            <p className="text-xs text-slate-400">
              Classification of observations according to EPA pollution hazard levels
            </p>
          </div>

          <div className="h-[280px] w-full pt-4">
            {riskChartData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                No risk profile categorization generated yet
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskChartData} margin={{ top: 10, right: 10, left: -10, bottom: 25 }}>
                  <XAxis
                    dataKey="category"
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8', fontSize: 10 }}
                    angle={-20}
                    textAnchor="end"
                    interval={0}
                  />
                  <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      borderColor: 'rgba(51, 65, 85, 0.8)',
                      borderRadius: '0.5rem',
                      fontSize: '11px',
                    }}
                  />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {riskChartData.map((entry, idx) => (
                      <Cell key={`bar-${idx}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Pollutant Summary Matrix / Quick Stats */}
        <div className="lg:col-span-6 glass-card p-6 border border-slate-800/80 flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Wind className="w-4 h-4 text-teal-400" />
              Pollutant Summary Statistics
            </h3>
            <p className="text-xs text-slate-400">
              Key statistical properties across major atmospheric contaminants
            </p>
          </div>

          <div className="pt-4 overflow-x-auto flex-1 flex flex-col justify-center">
            {kpis?.pollutant_summary && Object.keys(kpis.pollutant_summary).length > 0 ? (
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-slate-400 font-semibold border-b border-slate-800 text-left">
                    <th className="pb-2">Pollutant</th>
                    <th className="pb-2">Mean</th>
                    <th className="pb-2">Min</th>
                    <th className="pb-2">Max</th>
                    <th className="pb-2">Std Dev</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {Object.entries(kpis.pollutant_summary).map(([key, stat]) => (
                    <tr key={key} className="hover:bg-slate-800/30 transition">
                      <td className="py-2.5 font-bold uppercase text-teal-300">{key}</td>
                      <td className="py-2.5 text-slate-200">
                        {stat.mean !== undefined ? stat.mean.toFixed(1) : '—'}
                      </td>
                      <td className="py-2.5 text-slate-400">
                        {stat.min !== undefined ? stat.min.toFixed(1) : '—'}
                      </td>
                      <td className="py-2.5 text-rose-400">
                        {stat.max !== undefined ? stat.max.toFixed(1) : '—'}
                      </td>
                      <td className="py-2.5 text-slate-400">
                        {stat.std !== undefined ? stat.std.toFixed(2) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center text-slate-500 text-xs py-8">
                No pollutant summary statistics available
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
export default OverviewDashboard
