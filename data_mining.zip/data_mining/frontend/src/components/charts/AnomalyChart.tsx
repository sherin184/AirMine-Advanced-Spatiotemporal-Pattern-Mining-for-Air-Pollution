import React from 'react'
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts'

interface AnomalyChartProps {
  normalData: Record<string, any>[]
  anomalyData: Record<string, any>[]
  xKey?: string
  yKey?: string
  scoreThreshold?: number
  height?: number
}

export const AnomalyChart: React.FC<AnomalyChartProps> = ({
  normalData,
  anomalyData,
  xKey = 'pm25',
  yKey = 'anomaly_score',
  scoreThreshold,
  height = 360,
}) => {
  if (normalData.length === 0 && anomalyData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-xs">
        No anomaly dataset available to chart
      </div>
    )
  }

  return (
    <div className="w-full" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.7} />
          <XAxis
            type="number"
            dataKey={xKey}
            name={xKey}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            label={{
              value: xKey.toUpperCase(),
              fill: '#94a3b8',
              fontSize: 11,
              position: 'bottom',
              offset: 0,
            }}
          />
          <YAxis
            type="number"
            dataKey={yKey}
            name={yKey}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            label={{
              value: yKey === 'anomaly_score' ? 'ANOMALY SCORE' : yKey.toUpperCase(),
              fill: '#94a3b8',
              fontSize: 11,
              angle: -90,
              position: 'left',
              offset: 0,
            }}
          />
          <Tooltip
            cursor={{ strokeDasharray: '3 3', stroke: '#475569' }}
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const pt = payload[0].payload
                const isAnomaly = pt.is_anomaly || pt.anomaly === -1 || pt.anomaly === 1
                return (
                  <div className="bg-slate-900/95 border border-slate-700 p-3 rounded-lg shadow-xl text-xs space-y-1">
                    <p
                      className={`font-bold flex items-center gap-1.5 ${
                        isAnomaly ? 'text-rose-400' : 'text-teal-300'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isAnomaly ? 'bg-rose-500' : 'bg-teal-400'
                        }`}
                      />
                      {isAnomaly ? 'Detected Anomaly' : 'Normal Baseline'}
                    </p>
                    <p className="text-slate-400 font-mono">
                      {xKey}: <span className="text-slate-100">{Number(pt[xKey]).toFixed(2)}</span>
                    </p>
                    {pt[yKey] !== undefined && (
                      <p className="text-slate-400 font-mono">
                        Score: <span className="text-slate-100">{Number(pt[yKey]).toFixed(4)}</span>
                      </p>
                    )}
                    {pt.station_id && (
                      <p className="text-slate-500 text-[10px]">Station: {pt.station_id}</p>
                    )}
                    {pt.timestamp && (
                      <p className="text-slate-500 text-[10px]">Time: {pt.timestamp}</p>
                    )}
                  </div>
                )
              }
              return null
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
            formatter={(value) => <span className="text-slate-300 font-medium">{value}</span>}
          />

          {scoreThreshold !== undefined && (
            <ReferenceLine
              y={scoreThreshold}
              stroke="#f43f5e"
              strokeDasharray="4 4"
              label={{
                value: `Cutoff (${scoreThreshold.toFixed(3)})`,
                fill: '#fb7185',
                fontSize: 10,
                position: 'top',
              }}
            />
          )}

          {/* Normal points */}
          <Scatter
            name={`Normal Records (${normalData.length})`}
            data={normalData}
            fill="#2dd4bf"
            opacity={0.6}
          />

          {/* Anomalous points */}
          <Scatter
            name={`Flagged Anomalies (${anomalyData.length})`}
            data={anomalyData}
            fill="#f43f5e"
            shape="diamond"
            opacity={0.9}
          />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  )
}
export default AnomalyChart
