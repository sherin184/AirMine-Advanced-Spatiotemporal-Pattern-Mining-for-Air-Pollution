"""Spatial router for station mapping and geographic hotspot identification."""

from typing import List, Dict, Any
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from schemas import SpatialResponse, StationData
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.spatial_service import get_station_data, detect_hotspots

router = APIRouter()


@router.get("/data", response_model=SpatialResponse)
def get_spatial_data(
    dataset_id: int = Query(..., description="Target dataset ID"),
    db: Session = Depends(get_db),
):
    """
    Retrieve spatial monitoring station coordinates, pollutant averages, and map center.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        res = get_station_data(df, column_mapping=dataset.column_mapping)
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Spatial analysis failed: {str(e)}",
        )

    return SpatialResponse(
        stations=res.get("stations", []),
        has_coordinates=res.get("has_coordinates", False),
        center=res.get("center"),
        hotspot_count=res.get("hotspot_count", 0),
    )


@router.get("/hotspots", response_model=List[StationData])
def get_spatial_hotspots(
    dataset_id: int = Query(..., description="Target dataset ID"),
    threshold_percentile: float = Query(90.0, ge=50.0, le=99.9, description="Hotspot percentile threshold"),
    db: Session = Depends(get_db),
):
    """
    Detect pollution hotspots across monitoring stations exceeding the concentration threshold.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        hotspots = detect_hotspots(
            df=df,
            column_mapping=dataset.column_mapping,
            threshold_percentile=threshold_percentile,
        )
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Hotspot detection failed: {str(e)}",
        )

    return hotspots
