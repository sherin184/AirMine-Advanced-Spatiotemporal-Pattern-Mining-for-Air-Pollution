import React, { useState, useMemo } from 'react'
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Search,
} from 'lucide-react'

export interface ColumnDef<T = any> {
  key: string
  header: string
  render?: (row: T) => React.ReactNode
  sortable?: boolean
  width?: string
}

interface DataTableProps<T = any> {
  columns: ColumnDef<T>[]
  data: T[]
  pageSize?: number
  totalRows?: number
  currentPage?: number
  onPageChange?: (page: number) => void
  serverPagination?: boolean
  searchable?: boolean
  searchPlaceholder?: string
  emptyMessage?: string
}

export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  pageSize = 10,
  totalRows,
  currentPage = 1,
  onPageChange,
  serverPagination = false,
  searchable = true,
  searchPlaceholder = 'Search records...',
  emptyMessage = 'No records found',
}: DataTableProps<T>) {
  const [searchTerm, setSearchTerm] = useState('')
  const [sortKey, setSortKey] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc')
  const [clientPage, setClientPage] = useState(1)

  const activePage = serverPagination ? currentPage : clientPage

  const handleSort = (key: string) => {
    if (sortKey === key) {
      if (sortDirection === 'asc') {
        setSortDirection('desc')
      } else {
        setSortKey(null)
      }
    } else {
      setSortKey(key)
      setSortDirection('asc')
    }
  }

  // Filter client-side if not server pagination
  const filteredData = useMemo(() => {
    if (serverPagination || !searchTerm.trim()) return data
    const term = searchTerm.toLowerCase()
    return data.filter((item) =>
      columns.some((col) => {
        const val = item[col.key]
        return val !== undefined && val !== null && String(val).toLowerCase().includes(term)
      })
    )
  }, [data, searchTerm, serverPagination, columns])

  // Sort client-side if not server pagination
  const sortedData = useMemo(() => {
    if (serverPagination || !sortKey) return filteredData
    return [...filteredData].sort((a, b) => {
      const aVal = a[sortKey]
      const bVal = b[sortKey]
      if (aVal === bVal) return 0
      if (aVal === null || aVal === undefined) return 1
      if (bVal === null || bVal === undefined) return -1
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal
      }
      return sortDirection === 'asc'
        ? String(aVal).localeCompare(String(bVal))
        : String(bVal).localeCompare(String(aVal))
    })
  }, [filteredData, sortKey, sortDirection, serverPagination])

  const totalPages = serverPagination
    ? Math.max(1, Math.ceil((totalRows || 0) / pageSize))
    : Math.max(1, Math.ceil(sortedData.length / pageSize))

  const paginatedData = useMemo(() => {
    if (serverPagination) return data
    const start = (clientPage - 1) * pageSize
    return sortedData.slice(start, start + pageSize)
  }, [sortedData, clientPage, pageSize, serverPagination, data])

  const goToPage = (page: number) => {
    const target = Math.max(1, Math.min(page, totalPages))
    if (serverPagination) {
      onPageChange?.(target)
    } else {
      setClientPage(target)
    }
  }

  return (
    <div className="glass-card flex flex-col overflow-hidden border border-slate-700/60">
      {/* Top search & controls */}
      {searchable && (
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between gap-4">
          <div className="relative max-w-sm w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value)
                setClientPage(1)
              }}
              placeholder={searchPlaceholder}
              className="w-full bg-slate-900/90 border border-slate-700/80 rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-teal-400 focus:border-teal-400 transition"
            />
          </div>
          <div className="text-xs text-slate-400">
            Showing <span className="font-semibold text-slate-200">{paginatedData.length}</span> of{' '}
            <span className="font-semibold text-slate-200">
              {serverPagination ? totalRows ?? data.length : sortedData.length}
            </span>{' '}
            records
          </div>
        </div>
      )}

      {/* Table container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/80 text-slate-400 font-semibold uppercase tracking-wider border-b border-slate-800">
            <tr>
              {columns.map((col) => {
                const isSortable = col.sortable !== false
                const isSorted = sortKey === col.key
                return (
                  <th
                    key={col.key}
                    scope="col"
                    style={{ width: col.width }}
                    onClick={() => isSortable && handleSort(col.key)}
                    className={`py-3 px-4 ${
                      isSortable
                        ? 'cursor-pointer select-none hover:text-slate-200 hover:bg-slate-800/40 transition'
                        : ''
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{col.header}</span>
                      {isSortable && (
                        <span className="text-slate-500">
                          {isSorted ? (
                            sortDirection === 'asc' ? (
                              <ArrowUp className="w-3.5 h-3.5 text-teal-400" />
                            ) : (
                              <ArrowDown className="w-3.5 h-3.5 text-teal-400" />
                            )
                          ) : (
                            <ArrowUpDown className="w-3.5 h-3.5 opacity-40 hover:opacity-100" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {paginatedData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="py-8 text-center text-slate-500 text-xs">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              paginatedData.map((row, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-slate-800/30 transition-colors group text-slate-300 font-normal"
                >
                  {columns.map((col) => (
                    <td key={col.key} className="py-2.5 px-4 truncate max-w-xs">
                      {col.render ? col.render(row) : (row[col.key] !== null && row[col.key] !== undefined ? String(row[col.key]) : '—')}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-900/40 flex items-center justify-between text-xs text-slate-400">
        <div>
          Page <span className="font-semibold text-slate-200">{activePage}</span> of{' '}
          <span className="font-semibold text-slate-200">{totalPages}</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => goToPage(1)}
            disabled={activePage <= 1}
            className="p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-800 transition"
            title="First page"
          >
            <ChevronsLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => goToPage(activePage - 1)}
            disabled={activePage <= 1}
            className="p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-800 transition"
            title="Previous page"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <span className="px-2 font-mono text-teal-400 font-semibold">{activePage}</span>

          <button
            onClick={() => goToPage(activePage + 1)}
            disabled={activePage >= totalPages}
            className="p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-800 transition"
            title="Next page"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => goToPage(totalPages)}
            disabled={activePage >= totalPages}
            className="p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900 text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-800 transition"
            title="Last page"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  )
}
export default DataTable
