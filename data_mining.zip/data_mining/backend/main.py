import os
import sys
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from database import Base, engine
from routers import datasets, overview, explorer, clustering, anomaly, spatial, risk, correlation, reports

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Air Quality Data Mining API",
    description="Advanced Spatiotemporal Pattern Mining for Air Pollution",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create uploads and sample_data directories
os.makedirs(os.path.join(os.path.dirname(__file__), "uploads"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(__file__), "sample_data"), exist_ok=True)

# Mount routers
app.include_router(datasets.router, prefix="/api/v1/datasets", tags=["Datasets"])
app.include_router(overview.router, prefix="/api/v1/overview", tags=["Overview"])
app.include_router(explorer.router, prefix="/api/v1/explorer", tags=["Explorer"])
app.include_router(clustering.router, prefix="/api/v1/clustering", tags=["Clustering"])
app.include_router(anomaly.router, prefix="/api/v1/anomaly", tags=["Anomaly Detection"])
app.include_router(spatial.router, prefix="/api/v1/spatial", tags=["Spatial Analysis"])
app.include_router(risk.router, prefix="/api/v1/risk", tags=["Risk Profiling"])
app.include_router(correlation.router, prefix="/api/v1/correlation", tags=["Correlation"])
app.include_router(reports.router, prefix="/api/v1/reports", tags=["Reports"])

@app.get("/")
def root():
    return {"message": "Air Quality Data Mining API", "version": "1.0.0", "docs": "/docs"}
