import React, { useState, useEffect, useMemo } from 'react'
import {
  GitBranch,
  Play,
  Check,
  TrendingDown,
  Sparkles,
  BarChart2,
  Sliders,
  Layers,
  Award,
} from 'lucide-react'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import { useDataset } from '../hooks/useDataset'
import { api } from '../api/client'
import { ClusterScatter } from '../components/charts/ClusterScatter'
import { LoadingSpinner } from '../components/common/LoadingSpinner'
import type { ClusteringResponse, ElbowResponse } from '../types'

export const TemporalClustering: React.FC = () => {
  const { selectedDatasetId, selectedDataset } = useDataset()

  // Clustering parameters
  const [k, setK] = useState<number>(4)
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([])

  // API Responses
  const [clusteringResult, setClusteringResult] = useState<ClusteringResponse | null>(null)
  const [elbowData, setElbowData] = useState<ElbowResponse | null>(null)

  // Loading & states
  const [isRunning, setIsRunning] = useState(false)
  const [isLoadingElbow, setIsLoadingElbow] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Available features
  const availableFeatures = useMemo(() => {
    if (!selectedDataset) return ['pm25', 'pm10', 'no2', 'so2', 'o3', 'temperature', 'humidity']
    return (
      selectedDataset.numeric_columns ||
      selectedDataset.columns_list?.filter((c) => !['id', 'timestamp', 'date', 'station_id', 'station'].includes(c)) ||
      ['pm25', 'pm10', 'no2']
    )
  }, [selectedDataset])

  // Initialize selected features
  useEffect(() => {
    if (availableFeatures.length > 0 && selectedFeatures.length === 0) {
      setSelectedFeatures(availableFeatures.slice(0, 3))
    }
  }, [availableFeatures])

  // Fetch Elbow analysis curve
  const fetchElbow = async () => {
    if (!selectedDatasetId) return
    setIsLoadingElbow(true)
    try {
      const res = await api.clustering.getElbow(selectedDatasetId)
      setElbowData(res)
    } catch (err: any) {
      console.warn('Elbow curve API warning:', err?.message)
    } finally {
      setIsLoadingElbow(false)
    }
  };

  useEffect(() => {
    fetchElbow()
  }, [selectedDatasetId])

  // Run clustering execution
  const handleRunClustering = async () => {
    if (!selectedDatasetId) return
    setIsRunning(true)
    setError(null)
    try {
      const result = await api.clustering.run({
        dataset_id: selectedDatasetId,
        n_clusters: k,
        features: selectedFeatures.length > 0 ? selectedFeatures : undefined,
      })
      setClusteringResult(result)
    } catch (err: any) {
      console.error('Clustering error:', err)
      setError(err?.response?.data?.detail || err?.message || 'Failed to execute K-Means clustering')
    } finally {
      setIsRunning(false)
    }
  }

  // Toggle feature selection
  const toggleFeature = (feature: string) => {
    if (selectedFeatures.includes(feature)) {
      if (selectedFeatures.length > 2) {
        setSelectedFeatures(selectedFeatures.filter((f) => f !== feature))
      }
    } else {
      setSelectedFeatures([...selectedFeatures, feature])
    }
  }

  // Format Elbow data for Recharts
  const formattedElbow = useMemo(() => {
    if (!elbowData?.k_values) return []
    return elbowData.k_values.map((kVal, idx) => ({
      k: `K=${kVal}`,
      inertia: elbowData.inertias?.[idx] ? Number(elbowData.inertias[idx].toFixed(1)) : null,
      silhouette: elbowData.silhouette_scores?.[idx]
        ? Number(elbowData.silhouette_scores[idx].toFixed(3))
        : null,
    }))
  }, [elbowData])

  // Default axes for scatter
  const scatterX = selectedFeatures[0] || 'pm25'
  const scatterY = selectedFeatures[1] || selectedFeatures[0] || 'pm10'

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Configuration Header Card */}
      <div className="glass-card p-6 border border-slate-800 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-teal-400" />
              Unsupervised Temporal Pattern Clustering
            </h2>
            <p className="text-xs text-slate-400">
              Discover recurrent pollution profiles & diurnal regimes with partition-based K-Means
            </p>
          </div>

          <button
            onClick={handleRunClustering}
            disabled={isRunning || !selectedDatasetId}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-teal-500/20 transition disabled:opacity-50 self-start md:self-auto"
          >
            {isRunning ? (
              <>
                <LoadingSpinner size="sm" message="" />
                <span>Iterating Centroids...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-slate-950 stroke-none" />
                <span>Execute K-Means Analysis</span>
              </>
            )}
          </button>
        </div>

        {/* Hyperparameters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left: K Slider */}
          <div className="md:col-span-4 space-y-3 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-teal-400" />
                Cluster Count (K)
              </label>
              <span className="px-2.5 py-0.5 rounded font-mono text-sm font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                {k}
              </span>
            </div>
            <input
              type="range"
              min={2}
              max={10}
              step={1}
              value={k}
              onChange={(e) => setK(Number(e.target.value))}
              className="w-full accent-teal-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>K=2 (Broad)</span>
              <span>K=6 (Granular)</span>
              <span>K=10 (Micro)</span>
            </div>
          </div>

          {/* Right: Feature Checkboxes */}
          <div className="md:col-span-8 space-y-2 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-teal-400" />
                Clustering Feature Dimensions (Select at least 2)
              </span>
              <span className="text-[11px] text-teal-400 font-mono">
                {selectedFeatures.length} chosen
              </span>
            </label>

            <div className="flex flex-wrap gap-2 pt-1">
              {availableFeatures.map((feat) => {
                const isSelected = selectedFeatures.includes(feat)
                return (
                  <button
                    key={feat}
                    type="button"
                    onClick={() => toggleFeature(feat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition flex items-center gap-1.5 border ${
                      isSelected
                        ? 'bg-teal-500/20 border-teal-500 text-teal-300 shadow-sm'
                        : 'bg-slate-900 border-slate-700/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    <span>{feat.toUpperCase()}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs animate-fade-in">
          {error}
        </div>
      )}

      {/* Cluster Evaluation Performance Badges */}
      {clusteringResult && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="glass-card p-4 border border-slate-800 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-teal-500/15 text-teal-400">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Silhouette Score
              </p>
              <p className="text-xl font-bold font-mono text-teal-300">
                {clusteringResult.silhouette_score.toFixed(3)}
              </p>
              <p className="text-[10px] text-slate-500">
                {clusteringResult.silhouette_score > 0.5 ? 'Strong cohesion' : 'Acceptable separation'}
              </p>
            </div>
          </div>

          <div className="glass-card p-4 border border-slate-800 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-amber-500/15 text-amber-400">
              <TrendingDown className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Inertia (SSE)
              </p>
              <p className="text-xl font-bold font-mono text-amber-300">
                {clusteringResult.inertia.toFixed(1)}
              </p>
              <p className="text-[10px] text-slate-500">Within-cluster sum of squared errors</p>
            </div>
          </div>

          <div className="glass-card p-4 border border-slate-800 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-purple-500/15 text-purple-400">
              <BarChart2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Clusters Generated
              </p>
              <p className="text-xl font-bold font-mono text-purple-300">
                {clusteringResult.n_clusters} Profiles
              </p>
              <p className="text-[10px] text-slate-500">Across {clusteringResult.clustered_data.length} records</p>
            </div>
          </div>
        </div>
      )}

      {/* Visualizations: Elbow Curve & Cluster Scatter Plot */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Elbow Curve */}
        <div className="lg:col-span-5 glass-card p-6 border border-slate-800 flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-amber-400" />
              Optimal K Diagnostic (Elbow Curve)
            </h3>
            <p className="text-xs text-slate-400">
              Inertia minimization vs silhouette separation
            </p>
          </div>

          <div className="h-[320px] w-full pt-4">
            {isLoadingElbow ? (
              <LoadingSpinner message="Calculating multi-K SSE..." />
            ) : formattedElbow.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-500 text-xs">
                Run analysis to populate elbow trajectory
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={formattedElbow} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="k" stroke="#64748b" tick={{ fill: '#64748b', fontSize: 11 }} />
                  <YAxis stroke="#64748b" tick={{ fill: '#64748b', fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.95)',
                      borderColor: 'rgba(51, 65, 85, 0.8)',
                      borderRadius: '0.5rem',
                      fontSize: '11px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line
                    type="monotone"
                    dataKey="inertia"
                    stroke="#f59e0b"
                    name="Inertia (SSE)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="silhouette"
                    stroke="#2dd4bf"
                    name="Silhouette"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* 2D Cluster Scatter Plot */}
        <div className="lg:col-span-7 glass-card p-6 border border-slate-800 flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-400" />
                Cluster Projection ({scatterX.toUpperCase()} vs {scatterY.toUpperCase()})
              </h3>
              <p className="text-xs text-slate-400">
                Visualizing sample points partitioned by cluster membership
              </p>
            </div>
          </div>

          <div className="pt-2">
            {clusteringResult ? (
              <ClusterScatter
                data={clusteringResult.clustered_data}
                xKey={scatterX}
                yKey={scatterY}
                centroids={clusteringResult.centroids}
                height={320}
              />
            ) : (
              <div className="h-[320px] flex items-center justify-center text-slate-500 text-xs">
                Click "Execute K-Means Analysis" above to render cluster scatter plot
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Cluster Statistics Table */}
      {clusteringResult && (
        <div className="glass-card p-6 border border-slate-800">
          <h3 className="text-sm font-bold text-slate-100 pb-3 border-b border-slate-800 mb-4">
            Cluster Centroids & Distribution Statistics
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="text-slate-400 font-semibold border-b border-slate-800 text-left">
                <tr>
                  <th className="py-2.5 px-3">Cluster ID</th>
                  <th className="py-2.5 px-3">Obs Count</th>
                  <th className="py-2.5 px-3">% of Total</th>
                  {clusteringResult.feature_names.map((feat) => (
                    <th key={feat} className="py-2.5 px-3 uppercase font-mono">
                      Mean {feat}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {Object.entries(clusteringResult.cluster_sizes).map(([cId, count]) => {
                  const centroid = clusteringResult.centroids[Number(cId)] || {}
                  const total = clusteringResult.clustered_data.length || 1
                  const pct = ((count / total) * 100).toFixed(1)
                  return (
                    <tr key={cId} className="hover:bg-slate-800/30 transition">
                      <td className="py-2.5 px-3 font-bold text-teal-300">Cluster {cId}</td>
                      <td className="py-2.5 px-3 text-slate-200">{count.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-slate-400">{pct}%</td>
                      {clusteringResult.feature_names.map((feat) => (
                        <td key={feat} className="py-2.5 px-3 text-slate-300">
                          {centroid[feat] !== undefined ? Number(centroid[feat]).toFixed(2) : '—'}
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
export default TemporalClustering
