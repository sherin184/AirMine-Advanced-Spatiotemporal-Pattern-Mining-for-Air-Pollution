import React from 'react'
import { Loader2 } from 'lucide-react'

interface LoadingSpinnerProps {
  message?: string
  size?: 'sm' | 'md' | 'lg'
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  message = 'Loading analysis data...',
  size = 'md',
}) => {
  const sizeMap = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  }

  return (
    <div className="flex flex-col items-center justify-center p-8 space-y-3 min-h-[220px]">
      <div className="relative">
        <div className="absolute -inset-2 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-full blur-md opacity-25 animate-pulse"></div>
        <Loader2 className={`${sizeMap[size]} text-teal-400 animate-spin relative`} />
      </div>
      {message && (
        <p className="text-xs tracking-wide text-slate-400 font-medium animate-pulse">
          {message}
        </p>
      )}
    </div>
  )
}
export default LoadingSpinner
