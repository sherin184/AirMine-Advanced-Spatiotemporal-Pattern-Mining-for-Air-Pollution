"""Pydantic schemas for API request/response validation."""

from pydantic import BaseModel, ConfigDict
from typing import Optional, Any
from datetime import datetime


# ── Dataset Schemas ──────────────────────────────────────────────────────────

class DatasetBase(BaseModel):
    name: str
    description: str = ""

class DatasetCreate(DatasetBase):
    pass

class DatasetRead(BaseModel):
    id: int
    name: str
    filename: str
    original_filename: str
    upload_date: Optional[datetime] = None
    row_count: int
    column_count: int
    columns_list: list[str]
    column_mapping: dict
    has_coordinates: bool
    has_timestamps: bool
    is_sample: bool
    file_size_bytes: int
    description: str
    numeric_columns: list[str]
    cleaning_report: dict
    model_config = ConfigDict(from_attributes=True)

class DatasetPreview(BaseModel):
    dataset: DatasetRead
    rows: list[dict]
    total_rows: int

class ColumnMappingRequest(BaseModel):
    mapping: dict[str, str]  # user_column -> standard_field

class ColumnInfo(BaseModel):
    name: str
    dtype: str
    non_null_count: int
    null_count: int
    unique_count: int
    sample_values: list[Any]


# ── Overview Schemas ─────────────────────────────────────────────────────────

class KPIResponse(BaseModel):
    total_records: int
    total_datasets: int
    avg_aqi: Optional[float] = None
    max_aqi: Optional[float] = None
    anomaly_percentage: Optional[float] = None
    pollutant_summary: dict[str, dict] = {}
    risk_distribution: dict[str, int] = {}
    date_range: Optional[dict] = None

class TrendDataPoint(BaseModel):
    timestamp: str
    values: dict[str, Optional[float]]


# ── Explorer Schemas ─────────────────────────────────────────────────────────

class ExplorerResponse(BaseModel):
    data: list[dict]
    total: int
    page: int
    page_size: int
    total_pages: int
    columns: list[str]


# ── Clustering Schemas ───────────────────────────────────────────────────────

class ClusteringRequest(BaseModel):
    dataset_id: int
    n_clusters: int = 4
    features: list[str] = []

class ClusteringResponse(BaseModel):
    analysis_id: int
    n_clusters: int
    silhouette_score: float
    inertia: float
    cluster_sizes: dict[str, int]
    centroids: list[dict]
    clustered_data: list[dict]
    feature_names: list[str]

class ElbowResponse(BaseModel):
    k_values: list[int]
    inertias: list[float]
    silhouette_scores: list[float]


# ── Anomaly Schemas ──────────────────────────────────────────────────────────

class AnomalyRequest(BaseModel):
    dataset_id: int
    contamination: float = 0.05
    features: list[str] = []

class AnomalyResponse(BaseModel):
    analysis_id: int
    total_records: int
    anomaly_count: int
    anomaly_percentage: float
    anomaly_data: list[dict]
    normal_data: list[dict]
    feature_names: list[str]
    score_stats: dict


# ── Spatial Schemas ──────────────────────────────────────────────────────────

class StationData(BaseModel):
    station_id: str
    latitude: float
    longitude: float
    avg_values: dict[str, float]
    record_count: int
    risk_level: str = "Unknown"
    is_hotspot: bool = False

class SpatialResponse(BaseModel):
    stations: list[StationData]
    has_coordinates: bool
    center: Optional[dict] = None
    hotspot_count: int = 0


# ── Risk Schemas ─────────────────────────────────────────────────────────────

class RiskProfileResponse(BaseModel):
    overall_risk: str
    overall_score: float
    pollutant_risks: dict[str, dict]
    risk_distribution: dict[str, int]
    risk_data: list[dict]
    recommendations: list[str]

class RiskTrendResponse(BaseModel):
    trends: list[dict]
    period: str


# ── Correlation Schemas ──────────────────────────────────────────────────────

class CorrelationResponse(BaseModel):
    matrix: dict[str, dict[str, float]]
    significant_pairs: list[dict]
    columns: list[str]
    strongest_positive: Optional[dict] = None
    strongest_negative: Optional[dict] = None


# ── Report Schemas ───────────────────────────────────────────────────────────

class ReportInfo(BaseModel):
    id: int
    dataset_id: int
    analysis_type: str
    created_at: Optional[datetime] = None
    parameters: dict
    status: str
    model_config = ConfigDict(from_attributes=True)

class ReportListResponse(BaseModel):
    reports: list[ReportInfo]
    total: int


# ── Generic Response ─────────────────────────────────────────────────────────

class MessageResponse(BaseModel):
    message: str
    detail: Optional[str] = None
