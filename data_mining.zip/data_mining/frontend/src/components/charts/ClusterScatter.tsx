import React from 'react'
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts'

interface ClusterScatterProps {
  data: Record<string, any>[]
  xKey: string
  yKey: string
  clusterKey?: string
  centroids?: Record<string, any>[]
  height?: number
}

const CLUSTER_COLORS = [
  '#2dd4bf', // teal
  '#38bdf8', // sky
  '#a855f7', // purple
  '#f59e0b', // amber
  '#f43f5e', // rose
  '#10b981', // emerald
  '#ec4899', // pink
  '#6366f1', // indigo
]

export const ClusterScatter: React.FC<ClusterScatterProps> = ({
  data,
  xKey,
  yKey,
  clusterKey = 'cluster',
  centroids,
  height = 360,
}) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-slate-500 text-xs">
        No clustered data points to display
      </div>
    )
  }

  // Group data by cluster for legend and colors
  const clusters = Array.from(new Set(data.map((d) => d[clusterKey] ?? 0))).sort((a, b) => a - b)

  return (
    <div className="w-full" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.7} />
          <XAxis
            type="number"
            dataKey={xKey}
            name={xKey}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            label={{ value: xKey.toUpperCase(), fill: '#94a3b8', fontSize: 11, position: 'bottom', offset: 0 }}
          />
          <YAxis
            type="number"
            dataKey={yKey}
            name={yKey}
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            label={{ value: yKey.toUpperCase(), fill: '#94a3b8', fontSize: 11, angle: -90, position: 'left', offset: 10 }}
          />
          <Tooltip
            cursor={{ strokeDasharray: '3 3', stroke: '#475569' }}
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const pt = payload[0].payload
                return (
                  <div className="bg-slate-900/95 border border-slate-700 p-3 rounded-lg shadow-xl text-xs space-y-1">
                    <p className="font-semibold text-slate-200">
                      {pt.is_centroid ? 'Cluster Centroid' : `Point (Cluster ${pt[clusterKey]})`}
                    </p>
                    <p className="text-slate-400 font-mono">
                      {xKey}: <span className="text-teal-300">{Number(pt[xKey]).toFixed(2)}</span>
                    </p>
                    <p className="text-slate-400 font-mono">
                      {yKey}: <span className="text-teal-300">{Number(pt[yKey]).toFixed(2)}</span>
                    </p>
                    {pt.station_id && (
                      <p className="text-slate-500 text-[10px]">Station: {pt.station_id}</p>
                    )}
                  </div>
                )
              }
              return null
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
            formatter={(value) => <span className="text-slate-300 font-medium">{value}</span>}
          />

          {clusters.map((clusterId, idx) => {
            const clusterData = data.filter((d) => (d[clusterKey] ?? 0) === clusterId)
            const color = CLUSTER_COLORS[idx % CLUSTER_COLORS.length]
            return (
              <Scatter
                key={`cluster-${clusterId}`}
                name={`Cluster ${clusterId}`}
                data={clusterData}
                fill={color}
                opacity={0.7}
              >
                {clusterData.map((_, i) => (
                  <Cell key={`cell-${i}`} fill={color} />
                ))}
              </Scatter>
            )
          })}

          {/* Centroids rendered as distinct stars/crosses if available */}
          {centroids && centroids.length > 0 && (
            <Scatter
              name="Centroids"
              data={centroids.map((c) => ({ ...c, is_centroid: true }))}
              fill="#ffffff"
              shape="cross"
            />
          )}
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  )
}
export default ClusterScatter
