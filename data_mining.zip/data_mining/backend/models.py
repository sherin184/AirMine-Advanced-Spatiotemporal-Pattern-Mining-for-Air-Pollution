"""SQLAlchemy ORM models."""

from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, Float, JSON
from sqlalchemy.sql import func
from database import Base


class Dataset(Base):
    __tablename__ = "datasets"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    filename = Column(String(255), nullable=False)
    original_filename = Column(String(255), nullable=False)
    upload_date = Column(DateTime, default=func.now())
    row_count = Column(Integer, default=0)
    column_count = Column(Integer, default=0)
    columns_list = Column(JSON, default=list)
    column_mapping = Column(JSON, default=dict)
    has_coordinates = Column(Boolean, default=False)
    has_timestamps = Column(Boolean, default=False)
    is_sample = Column(Boolean, default=False)
    file_size_bytes = Column(Integer, default=0)
    description = Column(Text, default="")
    numeric_columns = Column(JSON, default=list)
    cleaning_report = Column(JSON, default=dict)


class AnalysisResult(Base):
    __tablename__ = "analysis_results"

    id = Column(Integer, primary_key=True, index=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    analysis_type = Column(String(50), nullable=False)  # clustering, anomaly, risk, correlation, spatial
    parameters = Column(JSON, default=dict)
    results = Column(JSON, default=dict)
    summary = Column(JSON, default=dict)
    created_at = Column(DateTime, default=func.now())
    status = Column(String(20), default="completed")  # running, completed, failed
    error_message = Column(Text, nullable=True)
