import React, { useMemo } from 'react'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts'
import type { TrendDataPoint } from '../../types'

interface PollutantLineChartProps {
  data: TrendDataPoint[]
  selectedPollutants?: string[]
  threshold?: number
  thresholdLabel?: string
  height?: number
}

const POLLUTANT_COLORS: Record<string, string> = {
  pm25: '#2dd4bf', // teal-400
  pm10: '#38bdf8', // sky-400
  no2: '#a855f7', // purple-500
  so2: '#f59e0b', // amber-500
  o3: '#10b981', // emerald-500
  co: '#f43f5e', // rose-500
  aqi: '#fb7185', // rose-400
  temperature: '#e879f9', // fuchsia-400
  humidity: '#60a5fa', // blue-400
}

export const PollutantLineChart: React.FC<PollutantLineChartProps> = ({
  data,
  selectedPollutants = ['pm25', 'pm10', 'no2'],
  threshold,
  thresholdLabel,
  height = 340,
}) => {
  // Flatten data for Recharts: [{ timestamp, pm25: 45, pm10: 80, ... }]
  const flattenedData = useMemo(() => {
    return data.map((point) => {
      const entry: Record<string, any> = {
        timestamp: point.timestamp ? point.timestamp.replace('T', ' ').slice(0, 16) : '',
      }
      if (point.values) {
        Object.entries(point.values).forEach(([k, v]) => {
          entry[k] = v !== null && v !== undefined ? Number(Number(v).toFixed(2)) : null
        })
      }
      return entry
    })
  }, [data])

  // Discover all available series if none selected
  const activePollutants = useMemo(() => {
    if (selectedPollutants.length > 0) return selectedPollutants
    const keys = new Set<string>()
    data.forEach((d) => {
      if (d.values) {
        Object.keys(d.values).forEach((k) => keys.add(k))
      }
    })
    return Array.from(keys).slice(0, 4)
  }, [data, selectedPollutants])

  if (!data || data.length === 0) {
    return (
      <div className="h-[280px] flex items-center justify-center text-slate-500 text-xs">
        No time-series data available for current dataset
      </div>
    )
  }

  return (
    <div className="w-full" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={flattenedData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.8} />
          <XAxis
            dataKey="timestamp"
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            tickLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            stroke="#64748b"
            tick={{ fill: '#64748b', fontSize: 11 }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(51, 65, 85, 0.8)',
              borderRadius: '0.5rem',
              backdropFilter: 'blur(10px)',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)',
              fontSize: '12px',
              color: '#f8fafc',
            }}
            labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontWeight: 600 }}
          />
          <Legend
            wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
            formatter={(value) => (
              <span className="text-slate-300 uppercase font-mono font-medium">{value}</span>
            )}
          />

          {threshold && (
            <ReferenceLine
              y={threshold}
              stroke="#ef4444"
              strokeDasharray="4 4"
              label={{
                value: thresholdLabel || `Threshold (${threshold})`,
                fill: '#f87171',
                fontSize: 10,
                position: 'top',
              }}
            />
          )}

          {activePollutants.map((pollutant, idx) => {
            const color =
              POLLUTANT_COLORS[pollutant.toLowerCase()] ||
              ['#2dd4bf', '#38bdf8', '#a855f7', '#fbbf24', '#f43f5e', '#34d399'][idx % 6]
            return (
              <Line
                key={pollutant}
                type="monotone"
                dataKey={pollutant}
                stroke={color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 5, fill: color, stroke: '#0f172a', strokeWidth: 2 }}
                connectNulls
              />
            )
          })}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
export default PollutantLineChart
