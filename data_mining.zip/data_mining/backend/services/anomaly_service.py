"""Anomaly detection service using Isolation Forest for air quality metrics."""

from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler


def _sanitize_val(val: Any) -> Any:
    """Safely convert NaN, infinity, and numpy types for JSON serialization."""
    if pd.isna(val) or val is None:
        return None
    if isinstance(val, (np.floating, float)):
        if np.isnan(val) or np.isinf(val):
            return None
        return round(float(val), 4)
    if isinstance(val, (np.integer, int)):
        return int(val)
    if isinstance(val, (np.bool_, bool)):
        return bool(val)
    return str(val)


def detect_anomalies(
    df: pd.DataFrame,
    features: Optional[List[str]] = None,
    contamination: float = 0.05,
) -> Dict[str, Any]:
    """
    Detect anomalous air quality events using Isolation Forest.
    
    Steps:
    - Feature validation and median imputation
    - StandardScaler normalization
    - Isolation Forest fitting (n_estimators=150, contamination=contamination, random_state=42, n_jobs=-1)
    - Decision function scoring and binary classification (-1 anomaly, 1 normal)
    - Compute score distributions and record subsets
    
    Returns:
        dict: {
            "total_records": int,
            "anomaly_count": int,
            "anomaly_percentage": float,
            "anomaly_labels": list[bool],
            "anomaly_scores": list[float],
            "anomaly_data": list[dict],
            "normal_data": list[dict],
            "feature_names": list[str],
            "score_stats": dict
        }
    """
    if df.empty:
        raise ValueError("Cannot run anomaly detection on an empty dataset.")

    # 1. Feature selection
    if not features:
        preferred = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI"]
        features = [col for col in preferred if col in df.columns]
        if not features:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            features = [c for c in numeric_cols if c not in ["latitude", "longitude", "id"]]

    if not features:
        raise ValueError("No numeric features available for anomaly detection.")

    # 2. Impute and prepare feature matrix
    X_df = df[features].copy()
    for col in features:
        X_df[col] = pd.to_numeric(X_df[col], errors="coerce")
        median_val = X_df[col].median()
        X_df[col] = X_df[col].fillna(median_val if pd.notna(median_val) else 0.0)

    # 3. Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_df.values)

    # 4. Fit Isolation Forest
    clamped_contamination = max(0.001, min(contamination, 0.5))
    iso_forest = IsolationForest(
        n_estimators=150,
        contamination=clamped_contamination,
        random_state=42,
        n_jobs=-1,
    )
    predictions = iso_forest.fit_predict(X_scaled)
    # decision_function: lower score = more abnormal
    raw_scores = iso_forest.decision_function(X_scaled)

    # Convert to labels: True if anomaly (-1), False if normal (1)
    anomaly_labels = [bool(p == -1) for p in predictions]
    scores_list = [round(float(s), 4) for s in raw_scores]

    total_records = len(df)
    anomaly_count = int(sum(anomaly_labels))
    anomaly_pct = round((anomaly_count / total_records * 100), 2) if total_records > 0 else 0.0

    # Attach results to dataframe copy
    augmented_df = df.copy()
    augmented_df["is_anomaly"] = anomaly_labels
    augmented_df["anomaly_score"] = scores_list

    # 5. Extract anomaly records and sample normal records
    anomaly_mask = augmented_df["is_anomaly"] == True
    normal_mask = ~anomaly_mask

    anomaly_subset = augmented_df[anomaly_mask]
    normal_subset = augmented_df[normal_mask].head(200)

    anomaly_data: List[Dict[str, Any]] = [
        {str(k): _sanitize_val(v) for k, v in row.items()}
        for row in anomaly_subset.to_dict(orient="records")
    ]

    normal_data: List[Dict[str, Any]] = [
        {str(k): _sanitize_val(v) for k, v in row.items()}
        for row in normal_subset.to_dict(orient="records")
    ]

    # Compute statistics of anomaly scores
    score_stats = {
        "min": round(float(np.min(raw_scores)), 4) if len(raw_scores) > 0 else 0.0,
        "max": round(float(np.max(raw_scores)), 4) if len(raw_scores) > 0 else 0.0,
        "mean": round(float(np.mean(raw_scores)), 4) if len(raw_scores) > 0 else 0.0,
        "std": round(float(np.std(raw_scores)), 4) if len(raw_scores) > 0 else 0.0,
    }

    return {
        "total_records": total_records,
        "anomaly_count": anomaly_count,
        "anomaly_percentage": anomaly_pct,
        "anomaly_labels": anomaly_labels,
        "anomaly_scores": scores_list,
        "anomaly_data": anomaly_data,
        "normal_data": normal_data,
        "feature_names": features,
        "score_stats": score_stats,
    }
