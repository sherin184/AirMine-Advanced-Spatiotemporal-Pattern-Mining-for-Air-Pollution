"""Spatial analysis and geospatial hotspot detection for monitoring stations."""

from typing import Dict, List, Any, Optional
import numpy as np
import pandas as pd


def _classify_aqi(aqi: float) -> str:
    """Classify AQI into risk level."""
    if aqi <= 50:
        return "Good"
    elif aqi <= 100:
        return "Moderate"
    elif aqi <= 150:
        return "Unhealthy_Sensitive"
    elif aqi <= 200:
        return "Unhealthy"
    elif aqi <= 300:
        return "Very_Unhealthy"
    else:
        return "Hazardous"


def detect_hotspots(
    df: pd.DataFrame,
    column_mapping: Optional[Dict[str, str]] = None,
    threshold_percentile: float = 90.0,
) -> List[Dict[str, Any]]:
    """
    Detect pollution hotspots where station average of any major pollutant
    exceeds the specified threshold percentile across the dataset.
    
    Returns:
        list[dict]: List of station summaries with is_hotspot flag.
    """
    data = get_station_data(df, column_mapping)
    stations = data.get("stations", [])
    if not stations:
        return []

    working_df = df.copy()
    if column_mapping:
        working_df = working_df.rename(columns=column_mapping)

    pollutant_cols = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI"]
    active_pollutants = [p for p in pollutant_cols if p in working_df.columns]

    # Calculate overall threshold per pollutant
    thresholds: Dict[str, float] = {}
    for p in active_pollutants:
        vals = pd.to_numeric(working_df[p], errors="coerce").dropna()
        if not vals.empty:
            thresholds[p] = float(np.percentile(vals, threshold_percentile))

    # Evaluate each station
    for st in stations:
        is_hotspot = False
        avg_vals = st.get("avg_values", {})
        for p, thresh in thresholds.items():
            if p in avg_vals and avg_vals[p] >= thresh:
                is_hotspot = True
                break
        st["is_hotspot"] = is_hotspot

    return stations


def get_station_data(
    df: pd.DataFrame,
    column_mapping: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Aggregate metrics by monitoring station and compute geographic center.
    
    Returns:
        dict: {
            "has_coordinates": bool,
            "stations": list[StationData],
            "center": dict | None,
            "hotspot_count": int
        }
    """
    if df.empty:
        return {
            "has_coordinates": False,
            "stations": [],
            "center": None,
            "hotspot_count": 0,
        }

    working_df = df.copy()
    if column_mapping:
        working_df = working_df.rename(columns=column_mapping)

    # Check for latitude and longitude
    has_lat = "latitude" in working_df.columns
    has_lon = "longitude" in working_df.columns

    if not (has_lat and has_lon):
        return {
            "has_coordinates": False,
            "stations": [],
            "center": None,
            "hotspot_count": 0,
        }

    # Ensure coordinates are numeric and valid
    working_df["latitude"] = pd.to_numeric(working_df["latitude"], errors="coerce")
    working_df["longitude"] = pd.to_numeric(working_df["longitude"], errors="coerce")
    valid_coords = working_df.dropna(subset=["latitude", "longitude"])

    if valid_coords.empty:
        return {
            "has_coordinates": False,
            "stations": [],
            "center": None,
            "hotspot_count": 0,
        }

    # Determine grouping key: station_id or round(lat, 4)_round(lon, 4)
    has_station_col = "station_id" in valid_coords.columns

    # Candidate pollutant and metric columns
    target_metrics = [
        "PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI",
        "temperature", "humidity", "wind_speed",
    ]
    numeric_cols = [c for c in target_metrics if c in valid_coords.columns]
    for c in numeric_cols:
        valid_coords[c] = pd.to_numeric(valid_coords[c], errors="coerce")

    # Calculate 90th percentile dataset-wide thresholds for hotspot detection
    thresholds: Dict[str, float] = {}
    for p in ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI"]:
        if p in valid_coords.columns:
            s = valid_coords[p].dropna()
            if not s.empty:
                thresholds[p] = float(np.percentile(s, 90.0))

    stations_list: List[Dict[str, Any]] = []

    if has_station_col:
        grouped = valid_coords.groupby("station_id")
    else:
        # Group by rounded lat/lon if station_id missing
        valid_coords["_coord_key"] = (
            valid_coords["latitude"].round(4).astype(str) + "," + valid_coords["longitude"].round(4).astype(str)
        )
        grouped = valid_coords.groupby("_coord_key")

    hotspot_count = 0

    for st_id, group in grouped:
        lat = round(float(group["latitude"].mean()), 6)
        lon = round(float(group["longitude"].mean()), 6)
        record_count = int(len(group))

        avg_values: Dict[str, float] = {}
        for col in numeric_cols:
            mean_val = group[col].mean()
            if pd.notna(mean_val):
                avg_values[col] = round(float(mean_val), 2)

        # Risk level determination based on AQI or PM2.5
        risk_level = "Unknown"
        if "AQI" in avg_values:
            risk_level = _classify_aqi(avg_values["AQI"])
        elif "PM2_5" in avg_values:
            # Estimate AQI from PM2.5 roughly
            pm25 = avg_values["PM2_5"]
            if pm25 <= 12:
                risk_level = "Good"
            elif pm25 <= 35.4:
                risk_level = "Moderate"
            elif pm25 <= 55.4:
                risk_level = "Unhealthy_Sensitive"
            elif pm25 <= 150.4:
                risk_level = "Unhealthy"
            elif pm25 <= 250.4:
                risk_level = "Very_Unhealthy"
            else:
                risk_level = "Hazardous"

        # Hotspot status: does this station exceed the 90th percentile for any major pollutant?
        is_hotspot = False
        for p, thresh in thresholds.items():
            if p in avg_values and avg_values[p] >= thresh:
                is_hotspot = True
                break

        if is_hotspot:
            hotspot_count += 1

        stations_list.append({
            "station_id": str(st_id),
            "latitude": lat,
            "longitude": lon,
            "avg_values": avg_values,
            "record_count": record_count,
            "risk_level": risk_level,
            "is_hotspot": is_hotspot,
        })

    # Overall center coordinate
    center_lat = round(float(valid_coords["latitude"].mean()), 6)
    center_lon = round(float(valid_coords["longitude"].mean()), 6)
    center = {"lat": center_lat, "lng": center_lon}

    return {
        "has_coordinates": True,
        "stations": stations_list,
        "center": center,
        "hotspot_count": hotspot_count,
    }
