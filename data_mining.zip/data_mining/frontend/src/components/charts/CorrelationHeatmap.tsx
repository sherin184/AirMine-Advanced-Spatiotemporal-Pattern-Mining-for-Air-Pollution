import React, { useState } from 'react'

interface CorrelationHeatmapProps {
  matrix: Record<string, Record<string, number>>
  columns?: string[]
}

export const CorrelationHeatmap: React.FC<CorrelationHeatmapProps> = ({ matrix, columns }) => {
  const [hoveredCell, setHoveredCell] = useState<{
    row: string
    col: string
    value: number
  } | null>(null)

  const cols = columns && columns.length > 0 ? columns : Object.keys(matrix || {})

  if (!cols || cols.length === 0 || !matrix) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-xs">
        No correlation matrix data available
      </div>
    )
  }

  // Helper to calculate color from correlation value [-1, 1]
  const getCellColor = (val: number | undefined) => {
    if (val === undefined || isNaN(val)) return 'rgba(30, 41, 59, 0.4)'
    // Positive: teal/emerald
    if (val > 0) {
      const alpha = Math.min(1, Math.max(0.1, val))
      return `rgba(45, 212, 191, ${alpha.toFixed(2)})`
    }
    // Negative: rose/red
    if (val < 0) {
      const alpha = Math.min(1, Math.max(0.1, Math.abs(val)))
      return `rgba(244, 63, 94, ${alpha.toFixed(2)})`
    }
    return 'rgba(51, 65, 85, 0.3)'
  }

  const getTextColor = (val: number | undefined) => {
    if (val === undefined || isNaN(val)) return '#64748b'
    if (Math.abs(val) > 0.6) return '#020617' // high contrast dark text on bright cell
    return '#f1f5f9'
  }

  return (
    <div className="flex flex-col items-center w-full overflow-x-auto p-2">
      {/* Active hover info badge */}
      <div className="h-7 mb-3 text-xs flex items-center gap-2">
        {hoveredCell ? (
          <div className="px-3 py-1 bg-slate-900 border border-slate-700 rounded-full text-slate-200 animate-fade-in flex items-center gap-2">
            <span className="font-semibold text-teal-300 uppercase">{hoveredCell.row}</span>
            <span className="text-slate-500">↔</span>
            <span className="font-semibold text-teal-300 uppercase">{hoveredCell.col}</span>
            <span className="font-mono ml-2 font-bold text-slate-100">
              r = {hoveredCell.value.toFixed(3)}
            </span>
            <span className="text-[10px] text-slate-400">
              ({hoveredCell.value > 0.7 ? 'Strong positive' : hoveredCell.value < -0.7 ? 'Strong inverse' : 'Moderate/Weak'})
            </span>
          </div>
        ) : (
          <span className="text-slate-500 text-xs italic">Hover over any matrix cell to inspect correlation</span>
        )}
      </div>

      <div className="inline-block bg-slate-900/60 p-4 rounded-xl border border-slate-800 shadow-xl">
        {/* Top Header Labels */}
        <div className="flex">
          <div className="w-20 shrink-0" />
          <div className="flex gap-1.5">
            {cols.map((col) => (
              <div
                key={col}
                className="w-14 h-8 flex items-center justify-center text-[11px] font-mono font-semibold text-slate-400 uppercase truncate"
                title={col}
              >
                {col.slice(0, 6)}
              </div>
            ))}
          </div>
        </div>

        {/* Matrix Grid */}
        <div className="flex flex-col gap-1.5 mt-1">
          {cols.map((rowKey) => (
            <div key={rowKey} className="flex items-center gap-1.5">
              {/* Row Label */}
              <div
                className="w-20 shrink-0 text-right pr-3 text-[11px] font-mono font-semibold text-slate-400 uppercase truncate"
                title={rowKey}
              >
                {rowKey}
              </div>

              {/* Row Cells */}
              <div className="flex gap-1.5">
                {cols.map((colKey) => {
                  const val = matrix[rowKey]?.[colKey] ?? 0
                  const isHovered =
                    hoveredCell?.row === rowKey && hoveredCell?.col === colKey
                  const isDiagonal = rowKey === colKey

                  return (
                    <div
                      key={colKey}
                      onMouseEnter={() =>
                        setHoveredCell({ row: rowKey, col: colKey, value: val })
                      }
                      onMouseLeave={() => setHoveredCell(null)}
                      style={{
                        backgroundColor: isDiagonal ? 'rgba(45, 212, 191, 0.85)' : getCellColor(val),
                        color: isDiagonal ? '#020617' : getTextColor(val),
                      }}
                      className={`w-14 h-12 rounded-lg flex items-center justify-center font-mono text-[11px] font-semibold transition-all duration-150 cursor-pointer select-none ${
                        isHovered
                          ? 'ring-2 ring-white scale-110 z-10 shadow-lg'
                          : 'hover:brightness-110'
                      }`}
                    >
                      {val !== undefined ? val.toFixed(2) : '—'}
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Color Scale Legend */}
      <div className="mt-4 flex items-center gap-3 text-xs text-slate-400">
        <span className="flex items-center gap-1.5">
          <span className="w-3.5 h-3.5 rounded bg-rose-500 inline-block" />
          -1.0 (Inverse)
        </span>
        <div className="w-24 h-2 rounded-full bg-gradient-to-r from-rose-500 via-slate-700 to-teal-400" />
        <span className="flex items-center gap-1.5">
          <span className="w-3.5 h-3.5 rounded bg-teal-400 inline-block" />
          +1.0 (Direct)
        </span>
      </div>
    </div>
  )
}
export default CorrelationHeatmap
