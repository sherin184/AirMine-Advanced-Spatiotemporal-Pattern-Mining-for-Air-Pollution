import React from 'react'
import { Calendar, RotateCcw } from 'lucide-react'

interface DateRangeFilterProps {
  startDate: string
  endDate: string
  onStartDateChange: (val: string) => void
  onEndDateChange: (val: string) => void
  onReset?: () => void
}

export const DateRangeFilter: React.FC<DateRangeFilterProps> = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onReset,
}) => {
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 focus-within:border-teal-400">
        <Calendar className="w-3.5 h-3.5 text-teal-400 shrink-0" />
        <span className="text-slate-500 text-[11px]">From</span>
        <input
          type="date"
          value={startDate}
          onChange={(e) => onStartDateChange(e.target.value)}
          className="bg-transparent text-slate-200 outline-none font-mono text-xs cursor-pointer"
        />
      </div>

      <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 focus-within:border-teal-400">
        <span className="text-slate-500 text-[11px]">To</span>
        <input
          type="date"
          value={endDate}
          onChange={(e) => onEndDateChange(e.target.value)}
          className="bg-transparent text-slate-200 outline-none font-mono text-xs cursor-pointer"
        />
      </div>

      {(startDate || endDate) && onReset && (
        <button
          onClick={onReset}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          title="Reset date range"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  )
}
export default DateRangeFilter
