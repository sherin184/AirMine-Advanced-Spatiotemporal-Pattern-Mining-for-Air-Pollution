import React, { useState, useRef } from 'react'
import { UploadCloud, CheckCircle2, AlertCircle, FileSpreadsheet, Loader2 } from 'lucide-react'
import { api } from '../../api/client'
import type { Dataset } from '../../types'

interface FileUploadProps {
  onUploadSuccess?: (dataset: Dataset) => void
  maxSizeBytes?: number // default 50MB
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onUploadSuccess,
  maxSizeBytes = 50 * 1024 * 1024,
}) => {
  const [isDragging, setIsDragging] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [customName, setCustomName] = useState('')
  const [description, setDescription] = useState('')
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const validateAndSetFile = (file: File) => {
    setError(null)
    setSuccess(null)
    if (!file.name.endsWith('.csv') && !file.name.endsWith('.txt')) {
      setError('Please upload a valid CSV file (.csv)')
      return
    }
    if (file.size > maxSizeBytes) {
      setError(`File size exceeds maximum limit (${(maxSizeBytes / (1024 * 1024)).toFixed(0)}MB)`)
      return
    }
    setSelectedFile(file)
    if (!customName) {
      setCustomName(file.name.replace(/\.[^/.]+$/, ''))
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndSetFile(e.dataTransfer.files[0])
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndSetFile(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (!selectedFile) return
    setIsUploading(true)
    setError(null)
    setSuccess(null)
    setUploadProgress(20)

    try {
      const interval = setInterval(() => {
        setUploadProgress((p) => (p < 85 ? p + 15 : p))
      }, 200)

      const dataset = await api.datasets.upload(
        selectedFile,
        customName || selectedFile.name,
        description
      )

      clearInterval(interval)
      setUploadProgress(100)
      setSuccess(`Dataset "${dataset.name}" uploaded successfully! (${dataset.row_count} records)`)
      setSelectedFile(null)
      setCustomName('')
      setDescription('')
      onUploadSuccess?.(dataset)
    } catch (err: any) {
      setError(
        err?.response?.data?.detail ||
          err?.response?.data?.message ||
          err?.message ||
          'Failed to upload dataset'
      )
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="glass-card p-6 border border-slate-700/60">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center ${
          isDragging
            ? 'border-teal-400 bg-teal-500/10 shadow-lg shadow-teal-500/10 scale-[1.01]'
            : 'border-slate-700/80 hover:border-teal-400/60 hover:bg-slate-800/40'
        }`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".csv,.txt"
          className="hidden"
        />

        <div className="w-14 h-14 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center mb-3 shadow-inner group-hover:scale-110 transition-transform">
          <UploadCloud className="w-7 h-7 text-teal-400" />
        </div>

        <h3 className="text-base font-semibold text-slate-100 mb-1">
          {selectedFile ? 'Change CSV File' : 'Drag & drop your CSV dataset here'}
        </h3>
        <p className="text-xs text-slate-400 max-w-sm mb-2">
          Supports standardized sensor logs, EPA air quality dumps, and synthetic IoT logs
        </p>
        <span className="inline-block px-2.5 py-1 text-[11px] font-mono text-teal-400 bg-teal-500/10 rounded-md border border-teal-500/20">
          Max file size: {(maxSizeBytes / (1024 * 1024)).toFixed(0)} MB
        </span>
      </div>

      {/* Selected file preview & metadata fields */}
      {selectedFile && (
        <div className="mt-5 p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4 animate-slide-up">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-teal-500/15 text-teal-400">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-200">{selectedFile.name}</p>
                <p className="text-xs text-slate-400 font-mono">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedFile(null)}
              className="text-xs text-rose-400 hover:text-rose-300 transition"
            >
              Remove
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                Dataset Name
              </label>
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder="E.g. Beijing PM2.5 2023"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-100 focus:ring-1 focus:ring-teal-400 focus:border-teal-400 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                Description (Optional)
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="E.g. Hourly particulate sensors"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-100 focus:ring-1 focus:ring-teal-400 focus:border-teal-400 outline-none"
              />
            </div>
          </div>

          {isUploading && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Uploading & parsing columns...</span>
                <span className="font-mono text-teal-400">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-teal-500 to-emerald-400 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              onClick={handleUpload}
              disabled={isUploading}
              className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-semibold text-xs flex items-center gap-2 shadow-lg shadow-teal-500/20 transition disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <UploadCloud className="w-4 h-4" />
                  Upload & Process Dataset
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Notifications */}
      {error && (
        <div className="mt-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-rose-400 text-xs animate-fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="mt-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-emerald-400 text-xs animate-fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}
    </div>
  )
}
export default FileUpload
