/**
 * TypeScript Interfaces matching API response schemas for Air Quality Analytics
 */

export interface Dataset {
  id: number
  name: string
  filename: string
  original_filename: string
  upload_date?: string | null
  row_count: number
  column_count: number
  columns_list: string[]
  column_mapping: Record<string, string>
  has_coordinates: boolean
  has_timestamps: boolean
  is_sample: boolean
  file_size_bytes: number
  description: string
  numeric_columns: string[]
  cleaning_report: Record<string, any>
}

export interface DatasetPreview {
  dataset: Dataset
  rows: Record<string, any>[]
  total_rows: number
}

export interface ColumnInfo {
  name: string
  dtype: string
  non_null_count: number
  null_count: number
  unique_count: number
  sample_values: any[]
}

export interface ColumnMappingRequest {
  mapping: Record<string, string>
}

export interface PollutantStats {
  mean?: number
  min?: number
  max?: number
  std?: number
  count?: number
  [key: string]: any
}

export interface KPIResponse {
  total_records: number
  total_datasets: number
  avg_aqi: number | null
  max_aqi: number | null
  anomaly_percentage: number | null
  pollutant_summary: Record<string, PollutantStats>
  risk_distribution: Record<string, number>
  date_range?: {
    start?: string
    end?: string
  } | null
}

export interface TrendDataPoint {
  timestamp: string
  values: Record<string, number | null>
}

export interface ExplorerResponse {
  data: Record<string, any>[]
  total: number
  page: number
  page_size: number
  total_pages: number
  columns: string[]
}

export interface ClusteringRequest {
  dataset_id: number
  n_clusters?: number
  features?: string[]
}

export interface ClusteringResponse {
  analysis_id: number
  n_clusters: number
  silhouette_score: number
  inertia: number
  cluster_sizes: Record<string, number>
  centroids: Record<string, any>[]
  clustered_data: Record<string, any>[]
  feature_names: string[]
}

export interface ElbowResponse {
  k_values: number[]
  inertias: number[]
  silhouette_scores: number[]
}

export interface AnomalyRequest {
  dataset_id: number
  contamination?: number
  features?: string[]
}

export interface AnomalyResponse {
  analysis_id: number
  total_records: number
  anomaly_count: number
  anomaly_percentage: number
  anomaly_data: Record<string, any>[]
  normal_data: Record<string, any>[]
  feature_names: string[]
  score_stats: {
    min?: number
    max?: number
    mean?: number
    threshold?: number
    [key: string]: any
  }
}

export interface StationData {
  station_id: string
  latitude: number
  longitude: number
  avg_values: Record<string, number>
  record_count: number
  risk_level: string
  is_hotspot: boolean
}

export interface SpatialResponse {
  stations: StationData[]
  has_coordinates: boolean
  center?: {
    latitude?: number
    longitude?: number
    lat?: number
    lon?: number
  } | null
  hotspot_count: number
}

export interface PollutantRiskInfo {
  score?: number
  category?: string
  dominant?: boolean
  exceedance_pct?: number
  avg_value?: number
  [key: string]: any
}

export interface RiskProfileResponse {
  overall_risk: string
  overall_score: number
  pollutant_risks: Record<string, PollutantRiskInfo>
  risk_distribution: Record<string, number>
  risk_data: Record<string, any>[]
  recommendations: string[]
}

export interface RiskTrendResponse {
  trends: Record<string, any>[]
  period: string
}

export interface CorrelationPair {
  col1: string
  col2: string
  correlation: number
  p_value?: number
  strength?: string
}

export interface CorrelationResponse {
  matrix: Record<string, Record<string, number>>
  significant_pairs: CorrelationPair[]
  columns: string[]
  strongest_positive?: CorrelationPair | null
  strongest_negative?: CorrelationPair | null
}

export interface ReportInfo {
  id: number
  dataset_id: number
  analysis_type: string
  created_at?: string | null
  parameters: Record<string, any>
  status: string
}

export interface ReportListResponse {
  reports: ReportInfo[]
  total: number
}

export interface MessageResponse {
  message: string
  detail?: string | null
}
