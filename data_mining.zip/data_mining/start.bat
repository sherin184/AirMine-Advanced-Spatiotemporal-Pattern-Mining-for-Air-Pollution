@echo off
title AirMine - Environmental Analytics Dashboard
echo ============================================================
echo   AirMine - Air Quality Data Mining Platform
echo   Advanced Spatiotemporal Pattern Mining
echo ============================================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://www.python.org/downloads/
    pause
    exit /b 1
)
echo [OK] Python found.

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js 18+ from https://nodejs.org/
    pause
    exit /b 1
)
echo [OK] Node.js found.

echo.
echo ── Installing Backend Dependencies ──
cd backend
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [ERROR] Failed to install backend dependencies.
    pause
    exit /b 1
)
echo [OK] Backend dependencies installed.

:: Generate sample data if not exists
if not exist "sample_data\synthetic_air_quality.csv" (
    echo [INFO] Generating synthetic sample dataset...
    python sample_data\generate_sample.py
    echo [OK] Sample dataset generated.
)

:: Create uploads directory
if not exist "uploads" mkdir uploads

echo.
echo ── Installing Frontend Dependencies ──
cd ..\frontend
call npm install --silent
if errorlevel 1 (
    echo [ERROR] Failed to install frontend dependencies.
    pause
    exit /b 1
)
echo [OK] Frontend dependencies installed.

echo.
echo ============================================================
echo   Starting Servers...
echo   Backend:  http://localhost:8000  (API docs: /docs)
echo   Frontend: http://localhost:5173
echo ============================================================
echo.
echo Press Ctrl+C in each window to stop the servers.
echo.

:: Start backend server in a new window
cd ..\backend
start "AirMine Backend" cmd /k "python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000"

:: Wait for backend to start
timeout /t 3 /nobreak >nul

:: Start frontend server in a new window
cd ..\frontend
start "AirMine Frontend" cmd /k "npm run dev"

:: Wait and open browser
timeout /t 4 /nobreak >nul
start http://localhost:5173

echo.
echo [OK] Both servers are running in separate windows.
echo Close this window or press any key to exit this launcher.
pause >nul
