import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react'
import { api } from '../api/client'
import type { Dataset } from '../types'

interface DatasetContextType {
  datasets: Dataset[]
  selectedDatasetId: number | null
  selectedDataset: Dataset | null
  setSelectedDatasetId: (id: number | null) => void
  refreshDatasets: () => Promise<void>
  isLoading: boolean
  error: string | null
}

const DatasetContext = createContext<DatasetContextType | undefined>(undefined)

export const DatasetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [datasets, setDatasets] = useState<Dataset[]>([])
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  const refreshDatasets = useCallback(async () => {
    setIsLoading(true)
    setError(null)
    try {
      const list = await api.datasets.list()
      setDatasets(list)
      if (list.length > 0) {
        // If current selection is invalid or null, pick first dataset
        setSelectedDatasetId((prev) => {
          if (prev !== null && list.some((d) => d.id === prev)) {
            return prev
          }
          return list[0].id
        })
      } else {
        setSelectedDatasetId(null)
      }
    } catch (err: any) {
      console.error('Failed to fetch datasets:', err)
      setError(err?.response?.data?.detail || err?.message || 'Failed to fetch datasets from API')
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    refreshDatasets()
  }, [refreshDatasets])

  const selectedDataset = useMemo(() => {
    if (selectedDatasetId === null) return null
    return datasets.find((d) => d.id === selectedDatasetId) || null
  }, [datasets, selectedDatasetId])

  return (
    <DatasetContext.Provider
      value={{
        datasets,
        selectedDatasetId,
        selectedDataset,
        setSelectedDatasetId,
        refreshDatasets,
        isLoading,
        error,
      }}
    >
      {children}
    </DatasetContext.Provider>
  )
}

export const useDataset = (): DatasetContextType => {
  const context = useContext(DatasetContext)
  if (!context) {
    throw new Error('useDataset must be used within a DatasetProvider')
  }
  return context
}
