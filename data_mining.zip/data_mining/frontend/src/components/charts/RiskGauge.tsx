import React from 'react'
import { ShieldAlert, ShieldCheck } from 'lucide-react'

interface RiskGaugeProps {
  score: number // typically 0 - 500 AQI or 0 - 100 Risk index
  maxScore?: number
  level?: string
  title?: string
  subtitle?: string
}

const RISK_LEVELS = [
  { max: 50, label: 'Good', color: '#10b981', textColor: 'text-emerald-400' },
  { max: 100, label: 'Moderate', color: '#f59e0b', textColor: 'text-amber-400' },
  { max: 150, label: 'Unhealthy (Sens.)', color: '#f97316', textColor: 'text-orange-400' },
  { max: 200, label: 'Unhealthy', color: '#ef4444', textColor: 'text-rose-500' },
  { max: 300, label: 'Very Unhealthy', color: '#a855f7', textColor: 'text-purple-400' },
  { max: 500, label: 'Hazardous', color: '#991b1b', textColor: 'text-red-700' },
]

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  score,
  maxScore = 300,
  level,
  title = 'Environmental Risk Level',
  subtitle,
}) => {
  const percentage = Math.min(100, Math.max(0, (score / maxScore) * 100))

  // Determine active level from score if not explicitly given
  const activeLevel =
    level ||
    (score <= 50
      ? 'Good'
      : score <= 100
      ? 'Moderate'
      : score <= 150
      ? 'Unhealthy (Sens.)'
      : score <= 200
      ? 'Unhealthy'
      : score <= 300
      ? 'Very Unhealthy'
      : 'Hazardous')

  const currentLevelConfig =
    RISK_LEVELS.find((l) => l.label.toLowerCase() === activeLevel.toLowerCase()) ||
    RISK_LEVELS[score > 200 ? 4 : score > 100 ? 2 : 0]

  return (
    <div className="glass-card p-5 border border-slate-700/60 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-sm font-semibold text-slate-200">{title}</h4>
          {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
        </div>
        <div
          className="p-2 rounded-lg"
          style={{ backgroundColor: `${currentLevelConfig.color}20` }}
        >
          {score > 150 ? (
            <ShieldAlert className="w-5 h-5" style={{ color: currentLevelConfig.color }} />
          ) : (
            <ShieldCheck className="w-5 h-5" style={{ color: currentLevelConfig.color }} />
          )}
        </div>
      </div>

      {/* Main Score Center Display */}
      <div className="flex items-baseline justify-between mb-2">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-extrabold tracking-tight text-slate-100">
            {score.toFixed(1)}
          </span>
          <span className="text-xs text-slate-400 uppercase font-mono">AQI score</span>
        </div>
        <span
          className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm"
          style={{
            backgroundColor: `${currentLevelConfig.color}25`,
            color: currentLevelConfig.color,
            border: `1px solid ${currentLevelConfig.color}60`,
          }}
        >
          {activeLevel}
        </span>
      </div>

      {/* Segmented Gradient Bar */}
      <div className="space-y-1.5 mt-2">
        <div className="relative w-full h-3.5 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <div
            className="h-full rounded-full transition-all duration-700 ease-out"
            style={{
              width: `${percentage}%`,
              background: 'linear-gradient(90deg, #10b981 0%, #f59e0b 35%, #ef4444 70%, #a855f7 100%)',
              boxShadow: `0 0 10px ${currentLevelConfig.color}80`,
            }}
          />
        </div>

        {/* Legend labels under bar */}
        <div className="flex justify-between text-[10px] text-slate-500 font-mono pt-1">
          <span>0 (Good)</span>
          <span>100</span>
          <span>200</span>
          <span>{maxScore}+ (Hazardous)</span>
        </div>
      </div>
    </div>
  )
}
export default RiskGauge
