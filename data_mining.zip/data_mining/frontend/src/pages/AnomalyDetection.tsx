import React, { useState, useEffect, useMemo } from 'react'
import {
  AlertTriangle,
  Play,
  Sliders,
  Check,
  ShieldAlert,
  Activity,
  Layers,
  Flame,
  FileSpreadsheet,
} from 'lucide-react'
import { useDataset } from '../hooks/useDataset'
import { api } from '../api/client'
import { AnomalyChart } from '../components/charts/AnomalyChart'
import { DataTable, ColumnDef } from '../components/common/DataTable'
import { LoadingSpinner } from '../components/common/LoadingSpinner'
import type { AnomalyResponse } from '../types'

export const AnomalyDetection: React.FC = () => {
  const { selectedDatasetId, selectedDataset } = useDataset()

  // Parameters
  const [contamination, setContamination] = useState<number>(0.05)
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([])

  // State
  const [result, setResult] = useState<AnomalyResponse | null>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Features available from dataset
  const availableFeatures = useMemo(() => {
    if (!selectedDataset) return ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3']
    return (
      selectedDataset.numeric_columns ||
      selectedDataset.columns_list?.filter(
        (c) => !['id', 'timestamp', 'date', 'station_id', 'station'].includes(c)
      ) || ['pm25', 'pm10']
    )
  }, [selectedDataset])

  useEffect(() => {
    if (availableFeatures.length > 0 && selectedFeatures.length === 0) {
      setSelectedFeatures(availableFeatures.slice(0, 3))
    }
  }, [availableFeatures])

  const handleRunDetection = async () => {
    if (!selectedDatasetId) return
    setIsRunning(true)
    setError(null)
    try {
      const res = await api.anomaly.run({
        dataset_id: selectedDatasetId,
        contamination,
        features: selectedFeatures.length > 0 ? selectedFeatures : undefined,
      })
      setResult(res)
    } catch (err: any) {
      console.error('Anomaly detection error:', err)
      setError(
        err?.response?.data?.detail || err?.message || 'Failed to execute Isolation Forest anomaly detection'
      )
    } finally {
      setIsRunning(false)
    }
  }

  const toggleFeature = (feat: string) => {
    if (selectedFeatures.includes(feat)) {
      if (selectedFeatures.length > 1) {
        setSelectedFeatures(selectedFeatures.filter((f) => f !== feat))
      }
    } else {
      setSelectedFeatures([...selectedFeatures, feat])
    }
  }

  // Define columns for flagged anomaly table
  const anomalyColumns: ColumnDef[] = useMemo(() => {
    if (!result?.anomaly_data || result.anomaly_data.length === 0) return []
    const sample = result.anomaly_data[0]
    const keys = Object.keys(sample)

    return keys.map((key) => ({
      key,
      header: key.toUpperCase().replace(/_/g, ' '),
      sortable: true,
      render: (row) => {
        const val = row[key]
        if (key === 'anomaly_score' || key === 'score') {
          return (
            <span className="font-mono text-rose-400 font-bold">
              {typeof val === 'number' ? val.toFixed(4) : val}
            </span>
          )
        }
        if (typeof val === 'number') {
          return (
            <span className="font-mono text-slate-200">
              {val % 1 !== 0 ? val.toFixed(2) : val}
            </span>
          )
        }
        return <span className="text-slate-300">{String(val ?? '—')}</span>
      },
    }))
  }, [result?.anomaly_data])

  const scatterX = selectedFeatures[0] || 'pm25'

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hyperparameter Config Card */}
      <div className="glass-card p-6 border border-slate-800 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              Isolation Forest Anomaly & Outlier Detection
            </h2>
            <p className="text-xs text-slate-400">
              Unsupervised tree-based partitioning to detect acute industrial spikes and sensor failures
            </p>
          </div>

          <button
            onClick={handleRunDetection}
            disabled={isRunning || !selectedDatasetId}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-500/20 transition disabled:opacity-50 self-start md:self-auto"
          >
            {isRunning ? (
              <>
                <LoadingSpinner size="sm" message="" />
                <span>Isolating Outliers...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-slate-950 stroke-none" />
                <span>Run Isolation Forest</span>
              </>
            )}
          </button>
        </div>

        {/* Sliders and feature selection */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Contamination rate */}
          <div className="md:col-span-5 space-y-3 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-rose-400" />
                Expected Contamination Rate
              </label>
              <span className="px-2.5 py-0.5 rounded font-mono text-sm font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {(contamination * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min={0.01}
              max={0.2}
              step={0.01}
              value={contamination}
              onChange={(e) => setContamination(Number(e.target.value))}
              className="w-full accent-rose-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>1% (Strict)</span>
              <span>5% (Balanced)</span>
              <span>20% (Aggressive)</span>
            </div>
          </div>

          {/* Feature checkboxes */}
          <div className="md:col-span-7 space-y-2 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-teal-400" />
                Target Feature Columns
              </span>
              <span className="text-[11px] text-teal-400 font-mono">
                {selectedFeatures.length} active
              </span>
            </label>
            <div className="flex flex-wrap gap-2 pt-1">
              {availableFeatures.map((feat) => {
                const isSelected = selectedFeatures.includes(feat)
                return (
                  <button
                    key={feat}
                    type="button"
                    onClick={() => toggleFeature(feat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition flex items-center gap-1.5 border ${
                      isSelected
                        ? 'bg-rose-500/20 border-rose-500 text-rose-300 shadow-sm'
                        : 'bg-slate-900 border-slate-700/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                    <span>{feat.toUpperCase()}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs animate-fade-in">
          {error}
        </div>
      )}

      {/* Metrics Row */}
      {result && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass-card p-4 border border-slate-800 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/15 text-rose-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Anomalies Flagged
              </p>
              <p className="text-xl font-bold font-mono text-rose-400">
                {result.anomaly_count.toLocaleString()}
              </p>
              <p className="text-[10px] text-slate-500">Out of {result.total_records} records</p>
            </div>
          </div>

          <div className="glass-card p-4 border border-slate-800 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/15 text-amber-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Anomaly Percentage
              </p>
              <p className="text-xl font-bold font-mono text-amber-300">
                {result.anomaly_percentage.toFixed(2)}%
              </p>
              <p className="text-[10px] text-slate-500">Contamination configured</p>
            </div>
          </div>

          <div className="glass-card p-4 border border-slate-800 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/15 text-teal-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Normal Baseline
              </p>
              <p className="text-xl font-bold font-mono text-teal-300">
                {result.normal_data.length.toLocaleString()}
              </p>
              <p className="text-[10px] text-slate-500">Compliant observations</p>
            </div>
          </div>

          <div className="glass-card p-4 border border-slate-800 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/15 text-purple-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Score Threshold
              </p>
              <p className="text-xl font-bold font-mono text-purple-300">
                {result.score_stats?.threshold !== undefined
                  ? Number(result.score_stats.threshold).toFixed(3)
                  : '—'}
              </p>
              <p className="text-[10px] text-slate-500">Decision boundary cutoff</p>
            </div>
          </div>
        </div>
      )}

      {/* Visual Anomaly Scatter Chart */}
      <div className="glass-card p-6 border border-slate-800">
        <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400" />
              Outlier Distribution ({scatterX.toUpperCase()} vs Anomaly Score)
            </h3>
            <p className="text-xs text-slate-400">
              Isolation Forest path length scores vs particulate intensity
            </p>
          </div>
        </div>

        {result ? (
          <AnomalyChart
            normalData={result.normal_data}
            anomalyData={result.anomaly_data}
            xKey={scatterX}
            yKey={result.normal_data[0]?.anomaly_score !== undefined ? 'anomaly_score' : selectedFeatures[1] || scatterX}
            scoreThreshold={result.score_stats?.threshold}
            height={360}
          />
        ) : (
          <div className="h-[300px] flex items-center justify-center text-slate-500 text-xs">
            Configure parameters and run detection above to visualize anomalies
          </div>
        )}
      </div>

      {/* Flagged Records Table */}
      {result && result.anomaly_data.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-rose-400" />
              Flagged Anomalous Records Log ({result.anomaly_data.length})
            </h3>
          </div>

          <DataTable
            columns={anomalyColumns}
            data={result.anomaly_data}
            pageSize={10}
            searchable={true}
            searchPlaceholder="Filter flagged anomalies..."
          />
        </div>
      )}
    </div>
  )
}
export default AnomalyDetection
