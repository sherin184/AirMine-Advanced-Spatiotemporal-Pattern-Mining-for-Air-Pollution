"""Datasets router for uploading, managing, and inspecting datasets."""

import os
import io
import uuid
import shutil
import numpy as np
import pandas as pd
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session

from database import get_db
from models import Dataset, AnalysisResult
from schemas import (
    DatasetRead,
    DatasetPreview,
    ColumnMappingRequest,
    ColumnInfo,
    MessageResponse,
)
from services.data_cleaning import (
    validate_csv,
    infer_columns,
    clean_data,
    get_numeric_columns,
)
from routers.helpers import get_dataset_or_404, get_dataset_df

router = APIRouter()

UPLOADS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "uploads"))
SAMPLE_DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "sample_data"))


@router.post("/upload", response_model=DatasetRead, status_code=status.HTTP_201_CREATED)
async def upload_dataset(
    file: UploadFile = File(...),
    name: Optional[str] = Form(None),
    description: Optional[str] = Form(""),
    db: Session = Depends(get_db),
):
    """
    Upload CSV dataset, validate, clean, infer column types, and store.
    """
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # 1. Validate CSV
    is_valid, validation_msg = validate_csv(contents)
    if not is_valid:
        raise HTTPException(status_code=400, detail=f"Invalid CSV: {validation_msg}")

    # 2. Parse CSV
    try:
        raw_df = pd.read_csv(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {str(e)}")

    if raw_df.empty:
        raise HTTPException(status_code=400, detail="CSV file contains no data rows.")

    # 3. Infer standard columns
    column_mapping = infer_columns(raw_df)

    # 4. Clean data
    cleaned_df, cleaning_report = clean_data(raw_df, column_mapping)

    # 5. Persist cleaned CSV
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    orig_filename = file.filename or "dataset.csv"
    ext = os.path.splitext(orig_filename)[1] or ".csv"
    unique_filename = f"{uuid.uuid4().hex}{ext}"
    dest_path = os.path.join(UPLOADS_DIR, unique_filename)
    cleaned_df.to_csv(dest_path, index=False)

    # 6. Detect attributes
    numeric_cols = get_numeric_columns(cleaned_df)
    has_coords = bool("latitude" in cleaned_df.columns and "longitude" in cleaned_df.columns)
    has_timestamps = bool("timestamp" in cleaned_df.columns)

    display_name = (name or "").strip()
    if not display_name:
        display_name = os.path.splitext(orig_filename)[0]

    dataset = Dataset(
        name=display_name,
        filename=unique_filename,
        original_filename=orig_filename,
        row_count=int(len(cleaned_df)),
        column_count=int(len(cleaned_df.columns)),
        columns_list=cleaned_df.columns.tolist(),
        column_mapping=column_mapping,
        has_coordinates=has_coords,
        has_timestamps=has_timestamps,
        is_sample=False,
        file_size_bytes=int(os.path.getsize(dest_path)),
        description=description or "",
        numeric_columns=numeric_cols,
        cleaning_report=cleaning_report,
    )

    db.add(dataset)
    db.commit()
    db.refresh(dataset)
    return dataset


@router.get("/", response_model=List[DatasetRead])
def list_datasets(db: Session = Depends(get_db)):
    """List all registered datasets."""
    return db.query(Dataset).order_by(Dataset.id.desc()).all()


@router.get("/{dataset_id}", response_model=DatasetPreview)
def get_dataset(dataset_id: int, db: Session = Depends(get_db)):
    """Retrieve dataset details and first 100 rows preview."""
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    preview_df = df.head(100).replace({np.nan: None})
    rows = preview_df.to_dict(orient="records")

    return DatasetPreview(
        dataset=dataset,
        rows=rows,
        total_rows=len(df),
    )


@router.get("/{dataset_id}/columns", response_model=List[ColumnInfo])
def get_dataset_columns(dataset_id: int, db: Session = Depends(get_db)):
    """Retrieve column schema, types, missing counts, and sample values."""
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    results: List[ColumnInfo] = []
    for col in df.columns:
        series = df[col]
        non_null_cnt = int(series.notna().sum())
        null_cnt = int(series.isna().sum())
        unique_cnt = int(series.nunique())

        samples = []
        for v in series.dropna().head(5):
            if isinstance(v, (np.floating, float)):
                samples.append(round(float(v), 4))
            elif isinstance(v, (np.integer, int)):
                samples.append(int(v))
            else:
                samples.append(str(v))

        results.append(
            ColumnInfo(
                name=str(col),
                dtype=str(series.dtype),
                non_null_count=non_null_cnt,
                null_count=null_cnt,
                unique_count=unique_cnt,
                sample_values=samples,
            )
        )
    return results


@router.post("/{dataset_id}/map-columns", response_model=DatasetRead)
def map_columns(
    dataset_id: int,
    request: ColumnMappingRequest,
    db: Session = Depends(get_db),
):
    """
    Update column mappings and recalculate coordinate/timestamp availability.
    """
    dataset = get_dataset_or_404(db, dataset_id)

    # Merge or update column mapping
    current_mapping = dict(dataset.column_mapping or {})
    current_mapping.update(request.mapping)
    dataset.column_mapping = current_mapping

    # Re-evaluate coordinate and timestamp flags
    mapped_targets = set(current_mapping.values()).union(set(dataset.columns_list or []))
    dataset.has_coordinates = bool("latitude" in mapped_targets and "longitude" in mapped_targets)
    dataset.has_timestamps = bool("timestamp" in mapped_targets)

    db.commit()
    db.refresh(dataset)
    return dataset


@router.delete("/{dataset_id}", response_model=MessageResponse)
def delete_dataset(dataset_id: int, db: Session = Depends(get_db)):
    """Delete a dataset, its disk file, and associated analysis results."""
    dataset = get_dataset_or_404(db, dataset_id)

    # Delete physical file
    file_path = os.path.join(UPLOADS_DIR, dataset.filename)
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except OSError:
            pass

    # Delete associated analysis records
    db.query(AnalysisResult).filter(AnalysisResult.dataset_id == dataset_id).delete()

    db.delete(dataset)
    db.commit()

    return MessageResponse(message=f"Dataset {dataset_id} deleted successfully.")


@router.post("/load-sample", response_model=DatasetRead, status_code=status.HTTP_201_CREATED)
def load_sample_dataset(db: Session = Depends(get_db)):
    """
    Load synthetic air quality benchmark dataset into system.
    """
    sample_file_path = os.path.join(SAMPLE_DATA_DIR, "synthetic_air_quality.csv")
    if not os.path.exists(sample_file_path):
        raise HTTPException(
            status_code=404,
            detail="Sample dataset file 'synthetic_air_quality.csv' not found.",
        )

    with open(sample_file_path, "rb") as f:
        contents = f.read()

    raw_df = pd.read_csv(io.BytesIO(contents))
    column_mapping = infer_columns(raw_df)
    cleaned_df, cleaning_report = clean_data(raw_df, column_mapping)

    os.makedirs(UPLOADS_DIR, exist_ok=True)
    unique_filename = f"sample_{uuid.uuid4().hex[:8]}_synthetic_air_quality.csv"
    dest_path = os.path.join(UPLOADS_DIR, unique_filename)
    cleaned_df.to_csv(dest_path, index=False)

    numeric_cols = get_numeric_columns(cleaned_df)
    has_coords = bool("latitude" in cleaned_df.columns and "longitude" in cleaned_df.columns)
    has_timestamps = bool("timestamp" in cleaned_df.columns)

    dataset = Dataset(
        name="Synthetic Air Quality Benchmark",
        filename=unique_filename,
        original_filename="synthetic_air_quality.csv",
        row_count=int(len(cleaned_df)),
        column_count=int(len(cleaned_df.columns)),
        columns_list=cleaned_df.columns.tolist(),
        column_mapping=column_mapping,
        has_coordinates=has_coords,
        has_timestamps=has_timestamps,
        is_sample=True,
        file_size_bytes=int(os.path.getsize(dest_path)),
        description="Pre-packaged benchmark dataset featuring multi-pollutant sensor telemetry.",
        numeric_columns=numeric_cols,
        cleaning_report=cleaning_report,
    )

    db.add(dataset)
    db.commit()
    db.refresh(dataset)
    return dataset
