"""Correlation router for Pearson correlation matrices and significance testing."""

from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from schemas import CorrelationResponse
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.correlation_service import compute_correlation

router = APIRouter()


@router.get("/matrix", response_model=CorrelationResponse)
def get_correlation_matrix(
    dataset_id: int = Query(..., description="Target dataset ID"),
    columns: Optional[List[str]] = Query(None, description="Subset of numeric columns to correlate"),
    db: Session = Depends(get_db),
):
    """
    Compute pairwise Pearson correlation coefficients, p-values, and identify strongest correlations.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        corr_res = compute_correlation(df, columns=columns if columns else None)
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Correlation analysis failed: {str(e)}",
        )

    return CorrelationResponse(
        matrix=corr_res["matrix"],
        significant_pairs=corr_res["significant_pairs"],
        columns=corr_res["columns"],
        strongest_positive=corr_res["strongest_positive"],
        strongest_negative=corr_res["strongest_negative"],
    )
