"""Overview router for dashboard KPIs and temporal trend aggregations."""

from typing import List, Optional, Dict
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
import pandas as pd
import numpy as np

from database import get_db
from models import Dataset, AnalysisResult
from schemas import KPIResponse, TrendDataPoint
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.risk_service import calculate_risk_profile

router = APIRouter()


@router.get("/kpis", response_model=KPIResponse)
def get_kpis(
    dataset_id: int = Query(..., description="ID of dataset to compute KPIs for"),
    db: Session = Depends(get_db),
):
    """
    Compute key performance indicators (KPIs) for the selected dataset.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    total_records = len(df)
    total_datasets = db.query(Dataset).count()

    # Calculate AQI metrics
    avg_aqi: Optional[float] = None
    max_aqi: Optional[float] = None

    if "AQI" in df.columns:
        aqi_series = pd.to_numeric(df["AQI"], errors="coerce").dropna()
        if not aqi_series.empty:
            avg_aqi = round(float(aqi_series.mean()), 2)
            max_aqi = round(float(aqi_series.max()), 2)

    # Risk distribution
    risk_dist: Dict[str, int] = {}
    try:
        risk_res = calculate_risk_profile(df)
        risk_dist = risk_res.get("risk_distribution", {})
        if avg_aqi is None and "overall_score" in risk_res:
            avg_aqi = round(float(risk_res["overall_score"]), 2)
    except Exception:
        pass

    # Anomaly percentage from prior analysis if available
    latest_anomaly = (
        db.query(AnalysisResult)
        .filter(
            AnalysisResult.dataset_id == dataset_id,
            AnalysisResult.analysis_type == "anomaly",
            AnalysisResult.status == "completed",
        )
        .order_by(AnalysisResult.id.desc())
        .first()
    )
    anomaly_pct: Optional[float] = None
    if latest_anomaly and latest_anomaly.results:
        anomaly_pct = latest_anomaly.results.get("anomaly_percentage")

    # Pollutant summary
    pollutant_summary: Dict[str, Dict[str, float]] = {}
    target_cols = dataset.numeric_columns or [
        c for c in df.select_dtypes(include=[np.number]).columns if c not in ["id", "latitude", "longitude"]
    ]

    for col in target_cols:
        if col in df.columns:
            series = pd.to_numeric(df[col], errors="coerce").dropna()
            if not series.empty:
                pollutant_summary[col] = {
                    "min": round(float(series.min()), 2),
                    "max": round(float(series.max()), 2),
                    "mean": round(float(series.mean()), 2),
                    "std": round(float(series.std()), 2) if len(series) > 1 else 0.0,
                }

    # Date range
    date_range: Optional[Dict[str, str]] = None
    if "timestamp" in df.columns:
        ts = pd.to_datetime(df["timestamp"], errors="coerce").dropna()
        if not ts.empty:
            date_range = {
                "min": str(ts.min().strftime("%Y-%m-%d %H:%M:%S")),
                "max": str(ts.max().strftime("%Y-%m-%d %H:%M:%S")),
            }

    return KPIResponse(
        total_records=total_records,
        total_datasets=total_datasets,
        avg_aqi=avg_aqi,
        max_aqi=max_aqi,
        anomaly_percentage=anomaly_pct,
        pollutant_summary=pollutant_summary,
        risk_distribution=risk_dist,
        date_range=date_range,
    )


@router.get("/trends", response_model=List[TrendDataPoint])
def get_trends(
    dataset_id: int = Query(..., description="ID of dataset to extract trends for"),
    db: Session = Depends(get_db),
):
    """
    Extract daily mean pollutant concentrations over time.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    if "timestamp" not in df.columns:
        return []

    ts_series = pd.to_datetime(df["timestamp"], errors="coerce")
    valid_mask = ts_series.notna()
    if valid_mask.sum() == 0:
        return []

    working_df = df[valid_mask].copy()
    working_df["date_day"] = ts_series[valid_mask].dt.strftime("%Y-%m-%d")

    # Select numerical pollutants
    pollutant_keys = [
        "PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI",
        "temperature", "humidity", "wind_speed",
    ]
    active_pollutants = [p for p in pollutant_keys if p in working_df.columns]
    if not active_pollutants:
        # Fallback to general numeric columns
        num_cols = dataset.numeric_columns or []
        active_pollutants = [c for c in num_cols if c not in ["id", "latitude", "longitude"] and c in working_df.columns]

    for p in active_pollutants:
        working_df[p] = pd.to_numeric(working_df[p], errors="coerce")

    grouped = working_df.groupby("date_day")[active_pollutants].mean()

    results: List[TrendDataPoint] = []
    for day_str, row in grouped.iterrows():
        day_values: Dict[str, Optional[float]] = {}
        for p in active_pollutants:
            val = row[p]
            day_values[p] = round(float(val), 2) if pd.notna(val) else None
        results.append(
            TrendDataPoint(
                timestamp=str(day_str),
                values=day_values,
            )
        )

    return results
