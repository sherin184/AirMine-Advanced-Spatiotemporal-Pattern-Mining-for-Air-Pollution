"""Clustering service using K-Means and Elbow evaluation for air quality analysis."""

from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score


def _sanitize_record(val: Any) -> Any:
    """Helper to convert NaN, infinity, and numpy types to JSON-safe values."""
    if pd.isna(val) or val is None:
        return None
    if isinstance(val, (np.floating, float)):
        if np.isnan(val) or np.isinf(val):
            return None
        return round(float(val), 4)
    if isinstance(val, (np.integer, int)):
        return int(val)
    if isinstance(val, (np.bool_, bool)):
        return bool(val)
    return str(val)


def _prepare_features(df: pd.DataFrame, features: Optional[List[str]]) -> Tuple_Prepared:
    """
    Select and validate feature matrix, filling NaNs with median.
    """
    if not features:
        # Auto-detect pollutant or numeric features
        preferred = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "AQI"]
        features = [col for col in preferred if col in df.columns]
        if not features:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            features = [c for c in numeric_cols if c not in ["latitude", "longitude", "id"]]
    
    if not features:
        raise ValueError("No numeric features available for clustering.")

    X = df[features].copy()

    # Convert all to numeric
    for col in features:
        X[col] = pd.to_numeric(X[col], errors="coerce")
        median_val = X[col].median()
        fill_val = median_val if pd.notna(median_val) else 0.0
        X[col] = X[col].fillna(fill_val)

    return X, features


Tuple_Prepared = tuple[pd.DataFrame, List[str]]


def run_kmeans(df: pd.DataFrame, features: List[str], n_clusters: int = 4) -> Dict[str, Any]:
    """
    Run K-Means clustering on selected air quality features.
    
    Steps:
    - StandardScaler normalization
    - Median imputation for missing values
    - KMeans fit (init='k-means++', n_init=10, random_state=42)
    - Inverse transform for centroid values in original scale
    - Silhouette score computation
    
    Returns:
        dict: {
            "n_clusters": int,
            "cluster_labels": list[int],
            "centroids": list[dict],
            "inertia": float,
            "silhouette_score": float,
            "cluster_sizes": dict[str, int],
            "feature_names": list[str],
            "clustered_data": list[dict]
        }
    """
    if df.empty:
        raise ValueError("Cannot perform clustering on empty dataset.")

    X_df, feature_names = _prepare_features(df, features)
    n_samples = len(X_df)

    # Adjust cluster count if samples are few
    effective_k = max(2, min(n_clusters, n_samples - 1)) if n_samples > 2 else 1

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_df.values)

    kmeans = KMeans(
        n_clusters=effective_k,
        init="k-means++",
        n_init=10,
        random_state=42,
    )
    cluster_labels = kmeans.fit_predict(X_scaled)

    # Calculate inertia
    inertia = float(round(kmeans.inertia_, 2))

    # Calculate silhouette score (requires 2 <= k < n_samples)
    sil_score = 0.0
    if 1 < effective_k < n_samples:
        try:
            sil_score = float(round(silhouette_score(X_scaled, cluster_labels), 4))
        except Exception:
            sil_score = 0.0

    # Invert cluster centroids back to original physical scale
    centroids_orig = scaler.inverse_transform(kmeans.cluster_centers_)
    centroids: List[Dict[str, Any]] = []
    for cluster_id, center in enumerate(centroids_orig):
        center_dict: Dict[str, Any] = {"cluster": cluster_id}
        for feat_idx, feat_name in enumerate(feature_names):
            center_dict[feat_name] = round(float(center[feat_idx]), 2)
        centroids.append(center_dict)

    # Cluster sizes distribution
    unique_clusters, counts = np.unique(cluster_labels, return_counts=True)
    cluster_sizes: Dict[str, int] = {
        str(int(c)): int(cnt) for c, cnt in zip(unique_clusters, counts)
    }

    # Prepare clustered data records with original columns plus 'cluster'
    result_df = df.copy()
    result_df["cluster"] = cluster_labels

    # Serialize rows safely
    clustered_records: List[Dict[str, Any]] = []
    for _, row in result_df.iterrows():
        record = {str(k): _sanitize_record(v) for k, v in row.to_dict().items()}
        clustered_records.append(record)

    return {
        "n_clusters": effective_k,
        "cluster_labels": [int(l) for l in cluster_labels],
        "centroids": centroids,
        "inertia": inertia,
        "silhouette_score": sil_score,
        "cluster_sizes": cluster_sizes,
        "feature_names": feature_names,
        "clustered_data": clustered_records,
    }


def run_elbow(df: pd.DataFrame, features: List[str], max_k: int = 10) -> Dict[str, Any]:
    """
    Run Elbow method evaluation for k in [2..max_k].
    
    Computes inertia and silhouette scores for each k value.
    
    Returns:
        dict: {
            "k_values": list[int],
            "inertias": list[float],
            "silhouette_scores": list[float]
        }
    """
    if df.empty:
        raise ValueError("Cannot perform elbow analysis on empty dataset.")

    X_df, feature_names = _prepare_features(df, features)
    n_samples = len(X_df)

    upper_k = min(max_k, n_samples - 1)
    if upper_k < 2:
        return {
            "k_values": [2],
            "inertias": [0.0],
            "silhouette_scores": [0.0],
        }

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_df.values)

    k_values: List[int] = []
    inertias: List[float] = []
    silhouette_scores: List[float] = []

    for k in range(2, upper_k + 1):
        kmeans = KMeans(
            n_clusters=k,
            init="k-means++",
            n_init=10,
            random_state=42,
        )
        labels = kmeans.fit_predict(X_scaled)
        
        inertias.append(round(float(kmeans.inertia_), 2))
        k_values.append(k)

        try:
            sil = float(round(silhouette_score(X_scaled, labels), 4))
        except Exception:
            sil = 0.0
        silhouette_scores.append(sil)

    return {
        "k_values": k_values,
        "inertias": inertias,
        "silhouette_scores": silhouette_scores,
    }
