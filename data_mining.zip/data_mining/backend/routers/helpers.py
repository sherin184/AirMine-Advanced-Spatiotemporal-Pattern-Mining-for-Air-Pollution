"""Helper utilities for router modules."""

import os
from typing import Optional
from fastapi import HTTPException
import pandas as pd
from sqlalchemy.orm import Session
from models import Dataset


def get_dataset_or_404(db: Session, dataset_id: int) -> Dataset:
    """Fetch a Dataset record by ID from DB or raise 404."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(status_code=404, detail=f"Dataset with ID {dataset_id} not found")
    return dataset


def get_dataset_df(dataset: Dataset) -> pd.DataFrame:
    """Read dataset CSV file and apply column_mapping."""
    uploads_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "uploads"))
    path = os.path.join(uploads_dir, dataset.filename)
    if not os.path.exists(path):
        sample_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "sample_data"))
        sample_path = os.path.join(sample_dir, dataset.filename)
        if os.path.exists(sample_path):
            path = sample_path
        else:
            raise HTTPException(
                status_code=404,
                detail=f"CSV file '{dataset.filename}' for dataset {dataset.id} not found on disk"
            )

    try:
        df = pd.read_csv(path)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error reading CSV file '{dataset.filename}': {str(e)}"
        )

    if dataset.column_mapping and isinstance(dataset.column_mapping, dict):
        df = df.rename(columns=dataset.column_mapping)

    return df
