import React, { useState, useEffect } from 'react'
import {
  Map,
  MapPin,
  AlertTriangle,
  Radio,
  Search,
  RefreshCw,
  Navigation,
  Flame,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react'
import { useDataset } from '../hooks/useDataset'
import { api } from '../api/client'
import { PollutionMap } from '../components/maps/PollutionMap'
import { LoadingSpinner } from '../components/common/LoadingSpinner'
import type { SpatialResponse, StationData } from '../types'

export const SpatialAnalysis: React.FC = () => {
  const { selectedDatasetId, selectedDataset } = useDataset()
  const [spatialData, setSpatialData] = useState<SpatialResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedStation, setSelectedStation] = useState<StationData | null>(null)
  const [stationSearch, setStationSearch] = useState('')

  const fetchSpatial = async () => {
    if (!selectedDatasetId) return
    setLoading(true)
    setError(null)
    try {
      const res = await api.spatial.getData(selectedDatasetId)
      setSpatialData(res)
      if (res.stations && res.stations.length > 0) {
        setSelectedStation(res.stations[0])
      }
    } catch (err: any) {
      console.error('Failed to load spatial data:', err)
      setError(err?.response?.data?.detail || err?.message || 'Failed to fetch spatial stations')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSpatial()
  }, [selectedDatasetId])

  const filteredStations = (spatialData?.stations || []).filter((s) =>
    s.station_id.toLowerCase().includes(stationSearch.toLowerCase())
  )

  const hotspots = (spatialData?.stations || []).filter((s) => s.is_hotspot)

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner & Stats */}
      <div className="glass-card p-5 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Map className="w-5 h-5 text-teal-400" />
            Spatial Pollution Distribution & Hotspot Mapping
          </h2>
          <p className="text-xs text-slate-400">
            Geographic dispersion of monitoring stations & automated spatial hotspot identification
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs">
            <Radio className="w-3.5 h-3.5 text-teal-400" />
            <span className="text-slate-300">
              <span className="font-bold text-teal-300">
                {spatialData?.stations?.length ?? 0}
              </span>{' '}
              Stations
            </span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span className="text-slate-300">
              <span className="font-bold text-rose-400">
                {spatialData?.hotspot_count ?? hotspots.length}
              </span>{' '}
              Hotspots
            </span>
          </div>

          <button
            onClick={fetchSpatial}
            className="p-2 rounded-lg bg-slate-900 border border-slate-700 hover:border-teal-400 text-slate-300 hover:text-teal-300 transition"
            title="Refresh spatial data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {loading ? (
        <LoadingSpinner message="Querying geospatial telemetry and station centroids..." />
      ) : error ? (
        <div className="glass-card p-8 text-center text-rose-400 text-xs border border-rose-500/30">
          <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-80" />
          <p className="font-semibold mb-1">Spatial Query Error</p>
          <p className="text-slate-400">{error}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main Leaflet Map View */}
          <div className="lg:col-span-8 space-y-4">
            <PollutionMap
              stations={spatialData?.stations || []}
              hasCoordinates={spatialData?.has_coordinates ?? selectedDataset?.has_coordinates ?? true}
              center={spatialData?.center}
              height="580px"
              onSelectStation={(st) => setSelectedStation(st)}
            />

            {/* Selected Station Deep Dive Banner */}
            {selectedStation && (
              <div className="glass-card p-4 border border-slate-800 bg-slate-900/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-teal-500/15 text-teal-400">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-100">
                        Station: {selectedStation.station_id}
                      </span>
                      {selectedStation.is_hotspot && (
                        <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-400 font-bold border border-rose-500/30">
                          Critical Hotspot
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 font-mono">
                      Coordinates: {selectedStation.latitude.toFixed(4)}°N,{' '}
                      {selectedStation.longitude.toFixed(4)}°E • {selectedStation.record_count} logs
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {selectedStation.avg_values &&
                    Object.entries(selectedStation.avg_values).map(([p, v]) => (
                      <div
                        key={p}
                        className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono"
                      >
                        <span className="text-slate-400 uppercase text-[10px] mr-1.5">{p}:</span>
                        <span className="text-teal-300 font-bold">{Number(v).toFixed(1)}</span>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Station List Sidebar */}
          <div className="lg:col-span-4 glass-card p-5 border border-slate-800 flex flex-col h-[580px]">
            <div className="pb-3 border-b border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Monitoring Stations Directory
                </h3>
                <span className="text-[11px] font-mono text-slate-400">
                  {filteredStations.length} found
                </span>
              </div>

              {/* Station Search input */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={stationSearch}
                  onChange={(e) => setStationSearch(e.target.value)}
                  placeholder="Filter stations by code..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-400"
                />
              </div>
            </div>

            {/* Scrollable Station Items */}
            <div className="flex-1 overflow-y-auto space-y-2 pt-3 pr-1">
              {filteredStations.length === 0 ? (
                <div className="text-center text-slate-500 text-xs py-8">
                  No stations matching filter
                </div>
              ) : (
                filteredStations.map((station) => {
                  const isSelected = selectedStation?.station_id === station.station_id
                  return (
                    <div
                      key={station.station_id}
                      onClick={() => setSelectedStation(station)}
                      className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between group ${
                        isSelected
                          ? 'bg-teal-500/10 border-teal-500/40 shadow-sm'
                          : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-200 group-hover:text-teal-300 transition">
                            {station.station_id}
                          </span>
                          {station.is_hotspot ? (
                            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          )}
                        </div>

                        <div className="text-[10px] text-slate-400 font-mono">
                          {station.record_count} logs • Risk:{' '}
                          <span
                            className={
                              station.risk_level?.toLowerCase().includes('unhealthy')
                                ? 'text-rose-400'
                                : 'text-emerald-400'
                            }
                          >
                            {station.risk_level}
                          </span>
                        </div>
                      </div>

                      <ChevronRight
                        className={`w-4 h-4 transition ${
                          isSelected ? 'text-teal-400 translate-x-0.5' : 'text-slate-600'
                        }`}
                      />
                    </div>
                  )
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
export default SpatialAnalysis
