import React, { useEffect, useMemo } from 'react'
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { MapPin, Navigation, AlertTriangle, ShieldCheck, Database } from 'lucide-react'
import type { StationData } from '../../types'

// Fix standard Leaflet default icon
// @ts-ignore
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

interface PollutionMapProps {
  stations: StationData[]
  hasCoordinates?: boolean
  center?: { lat?: number; lon?: number; latitude?: number; longitude?: number } | null
  height?: string
  onSelectStation?: (station: StationData) => void
}

const getPollutionColor = (riskLevel: string, avgValues?: Record<string, number>) => {
  const level = (riskLevel || '').toLowerCase()
  if (level.includes('hazard')) return '#991b1b'
  if (level.includes('very')) return '#a855f7'
  if (level.includes('unhealthy')) return '#ef4444'
  if (level.includes('moderate')) return '#f59e0b'
  if (level.includes('good')) return '#10b981'

  // Fallback to checking PM2.5 avg if level is unknown
  const pm25 = avgValues?.pm25 ?? avgValues?.pm2_5 ?? 0
  if (pm25 > 150) return '#ef4444'
  if (pm25 > 55) return '#f97316'
  if (pm25 > 35) return '#f59e0b'
  if (pm25 > 12) return '#38bdf8'
  return '#10b981'
}

// Controller component to automatically center and zoom map bounds
const MapBoundsAdjuster: React.FC<{ stations: StationData[]; center?: [number, number] }> = ({
  stations,
  center,
}) => {
  const map = useMap()

  useEffect(() => {
    if (stations.length > 0) {
      const validPoints = stations.filter(
        (s) => s.latitude && s.longitude && !isNaN(s.latitude) && !isNaN(s.longitude)
      )
      if (validPoints.length > 1) {
        const bounds = L.latLngBounds(validPoints.map((s) => [s.latitude, s.longitude]))
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 })
      } else if (validPoints.length === 1) {
        map.setView([validPoints[0].latitude, validPoints[0].longitude], 12)
      }
    } else if (center) {
      map.setView(center, 10)
    }
  }, [stations, center, map])

  return null
}

export const PollutionMap: React.FC<PollutionMapProps> = ({
  stations,
  hasCoordinates = true,
  center,
  height = '500px',
  onSelectStation,
}) => {
  const validStations = useMemo(() => {
    return stations.filter(
      (s) => s.latitude && s.longitude && !isNaN(s.latitude) && !isNaN(s.longitude)
    )
  }, [stations])

  const initialCenter: [number, number] = useMemo(() => {
    if (center?.lat && center?.lon) return [center.lat, center.lon]
    if (center?.latitude && center?.longitude) return [center.latitude, center.longitude]
    if (validStations.length > 0) return [validStations[0].latitude, validStations[0].longitude]
    return [28.6139, 77.209] // Default New Delhi coordinates
  }, [center, validStations])

  if (!hasCoordinates || validStations.length === 0) {
    return (
      <div
        className="glass-card flex flex-col items-center justify-center p-12 text-center border border-slate-800"
        style={{ height }}
      >
        <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-700/80 flex items-center justify-center mb-4 text-amber-400">
          <Navigation className="w-8 h-8 opacity-75" />
        </div>
        <h3 className="text-base font-bold text-slate-100 mb-1">
          No Geographic Coordinates Detected
        </h3>
        <p className="text-xs text-slate-400 max-w-md mb-4">
          The active dataset does not contain recognized latitude and longitude coordinates. Map
          geographic columns in the Dataset Management view to enable spatial analytics.
        </p>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-300 text-xs font-mono">
          <Database className="w-3.5 h-3.5" />
          <span>Expected schema: `latitude` (-90 to +90) & `longitude` (-180 to +180)</span>
        </div>
      </div>
    )
  }

  return (
    <div className="relative rounded-xl overflow-hidden border border-slate-700/60 shadow-2xl" style={{ height }}>
      {/* Map Legend Overlay */}
      <div className="absolute top-4 right-4 z-[400] glass-card px-3 py-2 bg-slate-900/90 text-xs border border-slate-700 shadow-xl space-y-1.5">
        <p className="font-semibold text-slate-300 text-[11px] uppercase tracking-wider">
          Pollution Level
        </p>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            Good
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
            Moderate
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
            Unhealthy
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500 inline-block" />
            Hazardous
          </span>
        </div>
      </div>

      <MapContainer
        center={initialCenter}
        zoom={11}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          maxZoom={19}
        />

        <MapBoundsAdjuster stations={validStations} center={initialCenter} />

        {validStations.map((station) => {
          const color = getPollutionColor(station.risk_level, station.avg_values)
          const radius = station.is_hotspot ? 14 : 9

          return (
            <CircleMarker
              key={station.station_id}
              center={[station.latitude, station.longitude]}
              pathOptions={{
                color: station.is_hotspot ? '#f43f5e' : color,
                fillColor: color,
                fillOpacity: 0.8,
                weight: station.is_hotspot ? 3 : 1.5,
              }}
              radius={radius}
              eventHandlers={{
                click: () => onSelectStation?.(station),
              }}
            >
              <Popup>
                <div className="space-y-2 text-slate-100">
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-700">
                    <span className="font-bold text-xs flex items-center gap-1 text-teal-300">
                      <MapPin className="w-3.5 h-3.5" />
                      Station: {station.station_id}
                    </span>
                    {station.is_hotspot ? (
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-400 font-bold flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> Hotspot
                      </span>
                    ) : (
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-medium flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Monitored
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Risk Assessment:</span>
                      <span className="font-semibold" style={{ color }}>
                        {station.risk_level || 'Normal'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Records Logged:</span>
                      <span className="font-mono text-slate-200">{station.record_count}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Coordinates:</span>
                      <span className="font-mono text-slate-400 text-[10px]">
                        {station.latitude.toFixed(4)}, {station.longitude.toFixed(4)}
                      </span>
                    </div>
                  </div>

                  {station.avg_values && Object.keys(station.avg_values).length > 0 && (
                    <div className="pt-2 border-t border-slate-700/80">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-1">
                        Average Pollutants:
                      </p>
                      <div className="grid grid-cols-2 gap-1 text-[11px]">
                        {Object.entries(station.avg_values).map(([k, v]) => (
                          <div key={k} className="bg-slate-800/80 px-2 py-0.5 rounded flex justify-between font-mono">
                            <span className="text-slate-400 uppercase text-[10px]">{k}:</span>
                            <span className="text-teal-300">{Number(v).toFixed(1)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Popup>
            </CircleMarker>
          )
        })}
      </MapContainer>
    </div>
  )
}
export default PollutionMap
