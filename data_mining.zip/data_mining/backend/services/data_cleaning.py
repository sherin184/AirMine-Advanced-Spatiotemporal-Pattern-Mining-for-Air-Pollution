"""Data cleaning and validation service for air quality datasets."""

import io
import re
from typing import Tuple, Dict, List, Any
import numpy as np
import pandas as pd

# Maximum allowed file size for CSV validation (50 MB)
MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024

# Physical bounds for standard air quality metrics
PHYSICAL_BOUNDS: Dict[str, Tuple[float, float]] = {
    "PM2_5": (0.0, 1000.0),
    "PM10": (0.0, 1500.0),
    "NO2": (0.0, 500.0),
    "SO2": (0.0, 500.0),
    "CO": (0.0, 50.0),
    "O3": (0.0, 300.0),
    "AQI": (0.0, 500.0),
    "temperature": (-50.0, 60.0),
    "humidity": (0.0, 100.0),
    "wind_speed": (0.0, 200.0),
    "latitude": (-90.0, 90.0),
    "longitude": (-180.0, 180.0),
}

# Sentinel values commonly representing missing/invalid data
SENTINEL_VALUES = {
    -999, -9999, 9999, -999.0, -9999.0, 9999.0,
    "-999", "-9999", "9999", "-999.0", "-9999.0", "9999.0",
    "None", "none", "NONE", "NULL", "null", "Null",
    "NA", "na", "N/A", "n/a", "NaN", "nan", "NAN",
    "", " ", "?", "-", "--"
}

# Standard column detection patterns
COLUMN_PATTERNS = [
    ("timestamp", [r"^time(stamp)?$", r"^datetime$", r"^date$", r"^recorded_at$", r"^time_stamp$"]),
    ("station_id", [r"^station(_?id)?$", r"^site(_?id)?$", r"^location(_?id)?$", r"^sensor(_?id)?$"]),
    ("latitude", [r"^lat(itude)?$"]),
    ("longitude", [r"^lon(gitude)?$", r"^lng$"]),
    ("PM2_5", [r"^pm_?2\.?5$", r"^pm25$"]),
    ("PM10", [r"^pm_?10$"]),
    ("NO2", [r"^no2$", r"^nitrogen_dioxide$"]),
    ("SO2", [r"^so2$", r"^sulfur_dioxide$"]),
    ("CO", [r"^co$", r"^carbon_monoxide$", r"^co_ppm$"]),
    ("O3", [r"^o3$", r"^ozone$"]),
    ("AQI", [r"^aqi$", r"^air_quality_index$"]),
    ("temperature", [r"^temp(erature)?$", r"^temp_c$", r"^t_deg$"]),
    ("humidity", [r"^humid(ity)?$", r"^rh$", r"^rel_humidity$"]),
    ("wind_speed", [r"^wind(_?speed)?$", r"^ws$", r"^wind_spd$"]),
]


def validate_csv(file_bytes: bytes) -> Tuple[bool, str]:
    """
    Validate raw bytes as a valid CSV file.
    
    Checks:
    - Not exceeding 50MB
    - Non-empty byte content
    - Parseable CSV structure
    - Contains at least one row of data and headers
    
    Returns:
        tuple[bool, str]: (is_valid, error_or_success_message)
    """
    if not file_bytes:
        return False, "File is empty."

    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        return False, f"File size ({len(file_bytes) / (1024 * 1024):.2f}MB) exceeds 50MB limit."

    # Try common encodings
    encodings_to_try = ["utf-8", "utf-8-sig", "latin1", "cp1252"]
    parsed_df = None
    last_error = ""

    for enc in encodings_to_try:
        try:
            buffer = io.BytesIO(file_bytes)
            # Read first 10 rows to quickly verify structure
            parsed_df = pd.read_csv(buffer, encoding=enc, nrows=10)
            break
        except Exception as e:
            last_error = str(e)
            continue

    if parsed_df is None:
        return False, f"Unable to parse CSV file: {last_error}"

    if parsed_df.empty and len(parsed_df.columns) == 0:
        return False, "CSV file has no headers or data."

    # Verify that full CSV has data rows
    try:
        buffer = io.BytesIO(file_bytes)
        row_count = sum(1 for _ in buffer) - 1  # approximate line count minus header
        if row_count < 1:
            return False, "CSV file contains header only, no data rows."
    except Exception as e:
        return False, f"Error inspecting CSV contents: {str(e)}"

    return True, "Valid CSV file."


def infer_columns(df: pd.DataFrame) -> Dict[str, str]:
    """
    Auto-detect standard air quality column types using case-insensitive regex patterns.
    
    Returns:
        dict: Mapping of {detected_original_column_name: standard_field_name}
    """
    mapping: Dict[str, str] = {}
    assigned_targets = set()

    for col in df.columns:
        col_clean = str(col).strip().lower()
        matched = False

        for target_field, patterns in COLUMN_PATTERNS:
            if target_field in assigned_targets:
                continue

            for pattern in patterns:
                if re.match(pattern, col_clean, re.IGNORECASE):
                    mapping[col] = target_field
                    assigned_targets.add(target_field)
                    matched = True
                    break
            if matched:
                break

    return mapping


def get_numeric_columns(df: pd.DataFrame) -> List[str]:
    """
    Identify and return a list of numeric column names.
    Attempts soft coercion for object columns that are predominantly numeric.
    """
    numeric_cols: List[str] = []
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            numeric_cols.append(col)
        else:
            # Check if column contains numeric data stored as strings
            coerced = pd.to_numeric(df[col], errors="coerce")
            non_null_count = coerced.notna().sum()
            if non_null_count > 0 and (non_null_count / len(df)) >= 0.5:
                numeric_cols.append(col)
    return numeric_cols


def clean_data(df: pd.DataFrame, column_mapping: Dict[str, str]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Clean dataset using column mapping and domain-specific rules:
    - Apply column renaming
    - Replace sentinel values (-999, -9999, NULL, empty string, etc.) with NaN
    - Parse timestamps safely
    - Remove duplicate records
    - Enforce physical pollutant bounds (values outside replaced with NaN)
    - Forward-fill (limit 3) followed by backward-fill (limit 1) for numeric data
    
    Returns:
        tuple[pd.DataFrame, dict]: Cleaned dataframe and data cleaning report dictionary
    """
    cleaned_df = df.copy()
    initial_rows = len(cleaned_df)
    invalid_values_replaced = 0

    # 1. Apply column mapping if provided
    if column_mapping:
        cleaned_df = cleaned_df.rename(columns=column_mapping)

    # 2. Count and replace sentinel values across all columns
    for col in cleaned_df.columns:
        # Check sentinel membership
        is_sentinel = cleaned_df[col].isin(SENTINEL_VALUES)
        sentinel_count = int(is_sentinel.sum())
        if sentinel_count > 0:
            invalid_values_replaced += sentinel_count
            cleaned_df.loc[is_sentinel, col] = np.nan

    # 3. Parse timestamps if present
    if "timestamp" in cleaned_df.columns:
        try:
            # Count invalid timestamps
            ts_series = pd.to_datetime(cleaned_df["timestamp"], errors="coerce")
            invalid_ts_count = int((cleaned_df["timestamp"].notna() & ts_series.isna()).sum())
            invalid_values_replaced += invalid_ts_count
            cleaned_df["timestamp"] = ts_series.dt.strftime("%Y-%m-%d %H:%M:%S").fillna("")
        except Exception:
            pass

    # 4. Remove duplicate rows
    cleaned_df = cleaned_df.drop_duplicates()
    final_rows_after_dedup = len(cleaned_df)
    removed_rows = initial_rows - final_rows_after_dedup

    # 5. Enforce physical bounds on recognized columns
    for col, (min_val, max_val) in PHYSICAL_BOUNDS.items():
        if col in cleaned_df.columns:
            # Ensure numeric conversion
            cleaned_df[col] = pd.to_numeric(cleaned_df[col], errors="coerce")
            out_of_bounds = (cleaned_df[col] < min_val) | (cleaned_df[col] > max_val)
            oob_count = int(out_of_bounds.sum())
            if oob_count > 0:
                invalid_values_replaced += oob_count
                cleaned_df.loc[out_of_bounds, col] = np.nan

    # 6. Missing value imputation: Forward-fill (limit=3) then backfill (limit=1) for numeric columns
    numeric_columns = get_numeric_columns(cleaned_df)
    missing_values_filled = 0

    for col in numeric_columns:
        cleaned_df[col] = pd.to_numeric(cleaned_df[col], errors="coerce")
        nans_before = int(cleaned_df[col].isna().sum())
        if nans_before > 0:
            filled_col = cleaned_df[col].ffill(limit=3).bfill(limit=1)
            nans_after = int(filled_col.isna().sum())
            missing_values_filled += (nans_before - nans_after)
            cleaned_df[col] = filled_col

    final_rows = len(cleaned_df)

    cleaning_report = {
        "initial_rows": int(initial_rows),
        "final_rows": int(final_rows),
        "removed_rows": int(removed_rows),
        "missing_values_filled": int(missing_values_filled),
        "invalid_values_replaced": int(invalid_values_replaced),
    }

    return cleaned_df, cleaning_report
