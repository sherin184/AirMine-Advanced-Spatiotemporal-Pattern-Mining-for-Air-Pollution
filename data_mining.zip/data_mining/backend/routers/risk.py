"""Risk router for environmental health profiling and temporal risk trends."""

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from schemas import RiskProfileResponse, RiskTrendResponse
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.risk_service import calculate_risk_profile, calculate_risk_trends

router = APIRouter()


@router.get("/profile", response_model=RiskProfileResponse)
def get_risk_profile(
    dataset_id: int = Query(..., description="Target dataset ID"),
    db: Session = Depends(get_db),
):
    """
    Calculate EPA AQI risk profile, risk category distribution, and health advisories.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        profile = calculate_risk_profile(df, column_mapping=dataset.column_mapping)
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Risk profile calculation failed: {str(e)}",
        )

    return RiskProfileResponse(
        overall_risk=profile["overall_risk"],
        overall_score=profile["overall_score"],
        pollutant_risks=profile["pollutant_risks"],
        risk_distribution=profile["risk_distribution"],
        risk_data=profile["risk_data"],
        recommendations=profile["recommendations"],
    )


@router.get("/trends", response_model=RiskTrendResponse)
def get_risk_trends(
    dataset_id: int = Query(..., description="Target dataset ID"),
    period: str = Query("daily", regex="^(daily|weekly|monthly)$", description="Aggregation period ('daily', 'weekly', 'monthly')"),
    db: Session = Depends(get_db),
):
    """
    Calculate chronological risk score evolution over daily, weekly, or monthly periods.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        trends_res = calculate_risk_trends(
            df=df,
            column_mapping=dataset.column_mapping,
            period=period,
        )
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Risk trends calculation failed: {str(e)}",
        )

    return RiskTrendResponse(
        trends=trends_res["trends"],
        period=trends_res["period"],
    )
