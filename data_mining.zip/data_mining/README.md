# 🌍 AirMine — Advanced Spatiotemporal Pattern Mining for Air Pollution

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104-green.svg)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-18-61dafb.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178c6.svg)](https://typescriptlang.org)

> An advanced environmental analytics platform for air pollution anomaly detection, temporal clustering, and environmental risk profiling using real data-mining algorithms.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 📊 **Overview Dashboard** | KPI cards, pollutant trends, risk distribution |
| 🌬️ **Air Quality Explorer** | Interactive data browsing with filters and charts |
| 🔬 **Temporal Clustering** | K-Means clustering with elbow method and silhouette scoring |
| 🗺️ **Spatial Analysis** | Leaflet maps with pollution markers and hotspot detection |
| ⚠️ **Anomaly Detection** | Isolation Forest with configurable contamination |
| 🛡️ **Risk Profiling** | EPA AQI-based risk scoring and recommendations |
| 📈 **Correlation Analysis** | Pearson correlation matrix with significance testing |
| 📁 **Dataset Management** | CSV upload, column mapping, data cleaning |
| 📋 **Reports** | Downloadable PDF and CSV analysis reports |
| ℹ️ **About** | Project methodology and tech stack |

---

## 🚀 Quick Start (Windows)

### Prerequisites
- **Python 3.10+** — [Download](https://python.org/downloads)
- **Node.js 18+** — [Download](https://nodejs.org)

### One-Click Start
```batch
start.bat
```

This will:
1. Install Python dependencies
2. Install Node.js dependencies
3. Generate the synthetic sample dataset
4. Start the FastAPI backend on `http://localhost:8000`
5. Start the Vite dev server on `http://localhost:5173`
6. Open the dashboard in your browser

### Manual Start

**Backend:**
```bash
cd backend
pip install -r requirements.txt
python sample_data/generate_sample.py
uvicorn main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

---

## 📐 Architecture

```
data_mining/
├── backend/                    # FastAPI + Python ML
│   ├── main.py                 # App entry point
│   ├── database.py             # SQLite + SQLAlchemy
│   ├── models.py               # ORM models
│   ├── schemas.py              # Pydantic schemas
│   ├── routers/                # API endpoints (9 routers)
│   ├── services/               # ML & data processing (7 services)
│   ├── sample_data/            # Synthetic dataset generator
│   ├── uploads/                # Uploaded CSV files
│   └── tests/                  # pytest test suite
├── frontend/                   # React + TypeScript + Tailwind
│   ├── src/
│   │   ├── pages/              # 10 dashboard pages
│   │   ├── components/         # Reusable UI components
│   │   ├── api/                # API client
│   │   ├── hooks/              # React hooks
│   │   └── types/              # TypeScript interfaces
│   └── ...
├── start.bat                   # Windows launcher
└── README.md
```

---

## 🧪 Algorithms

### K-Means Temporal Clustering
- StandardScaler preprocessing
- Elbow method for optimal K selection
- Silhouette score evaluation
- Cluster centroids in original units

### Isolation Forest Anomaly Detection
- Configurable contamination parameter (1-20%)
- 150 estimators for robust detection
- Anomaly scores via decision function
- No fabricated accuracy — real algorithm output

### Environmental Risk Profiling
- EPA AQI breakpoint calculations
- Per-pollutant sub-index computation
- Multi-pollutant risk aggregation
- Actionable recommendations

### Pearson Correlation Analysis
- Full correlation matrix
- P-value significance testing
- Significant pair identification

---

## 🔌 API Documentation

Once the backend is running, visit **http://localhost:8000/docs** for the interactive Swagger UI with all endpoints documented.

---

## 🧪 Testing

```bash
cd backend
python -m pytest tests/ -v
```

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS 3 |
| Charts | Recharts |
| Maps | Leaflet + react-leaflet |
| Backend | FastAPI, Python 3.10+ |
| Database | SQLite + SQLAlchemy 2.0 |
| ML | Scikit-learn, Pandas, NumPy, SciPy |
| PDF | fpdf2 |

---

## ⚠️ Important Notes

- The included sample dataset is **clearly labeled as synthetic** (generated for demonstration)
- All analysis results come from **actual algorithm execution** — no fabricated metrics
- The platform handles **missing timestamps and coordinates gracefully**
- Column mapping allows any CSV format to be used

---

## 📄 License

This project is for academic and educational purposes.
