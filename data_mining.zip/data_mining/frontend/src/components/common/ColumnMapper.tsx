import React, { useState, useEffect } from 'react'
import {
  X,
  Check,
  Sparkles,
  ArrowRight,
  Database,
  Loader2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react'
import { api } from '../../api/client'
import type { Dataset, ColumnInfo } from '../../types'

const STANDARD_FIELDS = [
  { key: '', label: '-- Not Mapped (Ignore) --' },
  { key: 'pm25', label: 'PM2.5 (µg/m³)' },
  { key: 'pm10', label: 'PM10 (µg/m³)' },
  { key: 'no2', label: 'NO₂ (Nitrogen Dioxide)' },
  { key: 'so2', label: 'SO₂ (Sulfur Dioxide)' },
  { key: 'co', label: 'CO (Carbon Monoxide)' },
  { key: 'o3', label: 'O₃ (Ozone)' },
  { key: 'aqi', label: 'AQI (Air Quality Index)' },
  { key: 'temperature', label: 'Temperature (°C)' },
  { key: 'humidity', label: 'Humidity (%)' },
  { key: 'wind_speed', label: 'Wind Speed (m/s)' },
  { key: 'pressure', label: 'Pressure (hPa)' },
  { key: 'timestamp', label: 'Timestamp / DateTime' },
  { key: 'latitude', label: 'Latitude (°N)' },
  { key: 'longitude', label: 'Longitude (°E)' },
  { key: 'station_id', label: 'Station ID / Code' },
]

interface ColumnMapperProps {
  dataset: Dataset
  isOpen: boolean
  onClose: () => void
  onSaveSuccess?: (updated: Dataset) => void
}

export const ColumnMapper: React.FC<ColumnMapperProps> = ({
  dataset,
  isOpen,
  onClose,
  onSaveSuccess,
}) => {
  const [columnsInfo, setColumnsInfo] = useState<ColumnInfo[]>([])
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    if (!isOpen) return

    const fetchCols = async () => {
      setLoading(true)
      setError(null)
      try {
        const info = await api.datasets.getColumns(dataset.id)
        setColumnsInfo(info)

        // Initialize mapping with existing mapping or auto-suggest
        const initialMapping: Record<string, string> = { ...(dataset.column_mapping || {}) }

        info.forEach((col) => {
          if (!initialMapping[col.name]) {
            const lower = col.name.toLowerCase().replace(/[^a-z0-9]/g, '')
            if (lower.includes('pm25') || lower === 'pm2_5') initialMapping[col.name] = 'pm25'
            else if (lower.includes('pm10')) initialMapping[col.name] = 'pm10'
            else if (lower.includes('no2')) initialMapping[col.name] = 'no2'
            else if (lower.includes('so2')) initialMapping[col.name] = 'so2'
            else if (lower === 'co' || lower.includes('carbonmonoxide')) initialMapping[col.name] = 'co'
            else if (lower.includes('o3') || lower.includes('ozone')) initialMapping[col.name] = 'o3'
            else if (lower.includes('aqi')) initialMapping[col.name] = 'aqi'
            else if (lower.includes('temp')) initialMapping[col.name] = 'temperature'
            else if (lower.includes('humid') || lower.includes('rh')) initialMapping[col.name] = 'humidity'
            else if (lower.includes('wind') || lower.includes('ws')) initialMapping[col.name] = 'wind_speed'
            else if (lower.includes('press') || lower.includes('baro')) initialMapping[col.name] = 'pressure'
            else if (lower.includes('time') || lower.includes('date')) initialMapping[col.name] = 'timestamp'
            else if (lower.includes('lat')) initialMapping[col.name] = 'latitude'
            else if (lower.includes('lon') || lower.includes('lng')) initialMapping[col.name] = 'longitude'
            else if (lower.includes('station') || lower.includes('site')) initialMapping[col.name] = 'station_id'
          }
        })

        setMapping(initialMapping)
      } catch (err: any) {
        setError(err?.response?.data?.detail || err?.message || 'Failed to load column information')
      } finally {
        setLoading(false)
      }
    }

    fetchCols()
  }, [isOpen, dataset])

  if (!isOpen) return null

  const handleFieldChange = (colName: string, stdField: string) => {
    setMapping((prev) => ({
      ...prev,
      [colName]: stdField,
    }))
  }

  const handleAutoSuggest = () => {
    const updated = { ...mapping }
    columnsInfo.forEach((col) => {
      const lower = col.name.toLowerCase().replace(/[^a-z0-9]/g, '')
      if (lower.includes('pm25')) updated[col.name] = 'pm25'
      else if (lower.includes('pm10')) updated[col.name] = 'pm10'
      else if (lower.includes('no2')) updated[col.name] = 'no2'
      else if (lower.includes('so2')) updated[col.name] = 'so2'
      else if (lower === 'co') updated[col.name] = 'co'
      else if (lower.includes('o3')) updated[col.name] = 'o3'
      else if (lower.includes('aqi')) updated[col.name] = 'aqi'
      else if (lower.includes('temp')) updated[col.name] = 'temperature'
      else if (lower.includes('humid')) updated[col.name] = 'humidity'
      else if (lower.includes('time') || lower.includes('date')) updated[col.name] = 'timestamp'
      else if (lower.includes('lat')) updated[col.name] = 'latitude'
      else if (lower.includes('lon') || lower.includes('lng')) updated[col.name] = 'longitude'
      else if (lower.includes('station')) updated[col.name] = 'station_id'
    })
    setMapping(updated)
  }

  const handleSave = async () => {
    setSaving(true)
    setError(null)
    setSuccess(null)
    try {
      // Clean mapping to only include defined standard fields
      const cleanMap: Record<string, string> = {}
      Object.entries(mapping).forEach(([src, target]) => {
        if (target) cleanMap[src] = target
      })

      const updated = await api.datasets.mapColumns(dataset.id, cleanMap)
      setSuccess('Column mapping updated successfully!')
      setTimeout(() => {
        onSaveSuccess?.(updated)
        onClose()
      }, 700)
    } catch (err: any) {
      setError(err?.response?.data?.detail || err?.message || 'Failed to save column mapping')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="glass-card w-full max-w-3xl border border-slate-700 max-h-[90vh] flex flex-col shadow-2xl animate-slide-up">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/10 text-teal-400 rounded-lg">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                Standardize Column Schema
              </h2>
              <p className="text-xs text-slate-400">
                Dataset #{dataset.id}: <span className="text-slate-200 font-semibold">{dataset.name}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-teal-400" />
              <span>Map CSV headers to recognized environmental dimensions for automated mining.</span>
            </div>
            <button
              onClick={handleAutoSuggest}
              type="button"
              className="px-3 py-1.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 text-xs font-medium flex items-center gap-1.5 border border-teal-500/30 transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Auto-Suggest All
            </button>
          </div>

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-teal-400" />
              <p className="text-xs text-slate-400">Inspecting CSV metadata...</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {columnsInfo.map((col) => (
                <div
                  key={col.name}
                  className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center p-3 rounded-lg bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition"
                >
                  {/* Left: Source Column */}
                  <div className="md:col-span-5 flex flex-col min-w-0">
                    <span className="text-xs font-semibold text-slate-200 truncate font-mono">
                      {col.name}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      dtype: <code className="text-slate-400">{col.dtype}</code> • non-null:{' '}
                      {col.non_null_count}
                    </span>
                  </div>

                  {/* Center arrow */}
                  <div className="md:col-span-1 flex justify-center text-slate-600">
                    <ArrowRight className="w-4 h-4" />
                  </div>

                  {/* Right: Target Standard Field */}
                  <div className="md:col-span-6">
                    <select
                      value={mapping[col.name] || ''}
                      onChange={(e) => handleFieldChange(col.name, e.target.value)}
                      className={`w-full text-xs rounded-lg px-3 py-2 border outline-none transition font-medium ${
                        mapping[col.name]
                          ? 'bg-slate-950 border-teal-500/50 text-teal-300'
                          : 'bg-slate-950 border-slate-700/80 text-slate-400'
                      }`}
                    >
                      {STANDARD_FIELDS.map((opt) => (
                        <option key={opt.key} value={opt.key}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
            </div>
          )}

          {error && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-rose-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-emerald-400 text-xs">
              <Check className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || loading}
            className="px-5 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-teal-500/20 transition disabled:opacity-50"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[2.5]" />
                Apply Schema Mapping
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
export default ColumnMapper
