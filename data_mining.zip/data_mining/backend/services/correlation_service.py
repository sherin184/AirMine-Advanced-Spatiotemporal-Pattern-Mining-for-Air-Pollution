"""Correlation analysis service computing Pearson correlations and statistical significance."""

from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd
from scipy import stats


def compute_correlation(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Compute Pearson correlation matrix and statistical significance (p-values) for numeric features.
    
    Identifies:
    - Pairwise correlation matrix
    - Significant correlations where p-value < 0.05
    - Strongest positive and strongest negative correlations
    
    Returns:
        dict: {
            "matrix": dict[str, dict[str, float]],
            "columns": list[str],
            "significant_pairs": list[dict], # [{col1, col2, correlation, p_value}]
            "strongest_positive": dict | None,
            "strongest_negative": dict | None
        }
    """
    if df.empty:
        return {
            "matrix": {},
            "columns": [],
            "significant_pairs": [],
            "strongest_positive": None,
            "strongest_negative": None,
        }

    # 1. Determine valid numeric columns
    if not columns:
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        # Filter out IDs or indices if present
        columns = [c for c in numeric_cols if c.lower() not in ["id", "index"]]

    # Filter columns to those existing and having sufficient non-null numeric entries
    valid_cols: List[str] = []
    numeric_df = pd.DataFrame()

    for col in columns:
        if col in df.columns:
            series = pd.to_numeric(df[col], errors="coerce")
            if series.count() >= 3 and series.std(skipna=True) > 1e-9:
                valid_cols.append(col)
                numeric_df[col] = series

    if len(valid_cols) < 2:
        return {
            "matrix": {c: {c: 1.0} for c in valid_cols},
            "columns": valid_cols,
            "significant_pairs": [],
            "strongest_positive": None,
            "strongest_negative": None,
        }

    # 2. Compute correlation matrix using pandas
    raw_corr = numeric_df.corr(method="pearson")
    corr_matrix: Dict[str, Dict[str, float]] = {}

    for c1 in valid_cols:
        corr_matrix[c1] = {}
        for c2 in valid_cols:
            val = raw_corr.loc[c1, c2]
            corr_matrix[c1][c2] = 1.0 if c1 == c2 else (round(float(val), 4) if pd.notna(val) else 0.0)

    # 3. Compute pairwise p-values and collect pairs
    significant_pairs: List[Dict[str, Any]] = []
    all_distinct_pairs: List[Dict[str, Any]] = []

    for i in range(len(valid_cols)):
        for j in range(i + 1, len(valid_cols)):
            col1 = valid_cols[i]
            col2 = valid_cols[j]

            pair_df = numeric_df[[col1, col2]].dropna()
            if len(pair_df) < 3:
                continue

            try:
                r, p_val = stats.pearsonr(pair_df[col1], pair_df[col2])
                if np.isnan(r) or np.isnan(p_val):
                    continue

                r_val = round(float(r), 4)
                p_val_rounded = round(float(p_val), 6)

                pair_info = {
                    "col1": col1,
                    "col2": col2,
                    "correlation": r_val,
                    "p_value": p_val_rounded,
                }
                all_distinct_pairs.append(pair_info)

                if p_val < 0.05:
                    significant_pairs.append(pair_info)
            except Exception:
                continue

    # Sort significant pairs by absolute correlation descending
    significant_pairs.sort(key=lambda x: abs(x["correlation"]), reverse=True)

    # Determine strongest positive and negative correlations
    strongest_pos: Optional[Dict[str, Any]] = None
    strongest_neg: Optional[Dict[str, Any]] = None

    pos_candidates = [p for p in all_distinct_pairs if p["correlation"] > 0]
    neg_candidates = [p for p in all_distinct_pairs if p["correlation"] < 0]

    if pos_candidates:
        best_pos = max(pos_candidates, key=lambda x: x["correlation"])
        strongest_pos = {
            "col1": best_pos["col1"],
            "col2": best_pos["col2"],
            "value": best_pos["correlation"],
        }

    if neg_candidates:
        best_neg = min(neg_candidates, key=lambda x: x["correlation"])
        strongest_neg = {
            "col1": best_neg["col1"],
            "col2": best_neg["col2"],
            "value": best_neg["correlation"],
        }

    return {
        "matrix": corr_matrix,
        "columns": valid_cols,
        "significant_pairs": significant_pairs,
        "strongest_positive": strongest_pos,
        "strongest_negative": strongest_neg,
    }
