import React, { useState } from 'react'
import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  Wind,
  GitBranch,
  Map,
  AlertTriangle,
  Shield,
  BarChart3,
  Database,
  FileText,
  Info,
  ChevronLeft,
  ChevronRight,
  Activity,
  Layers,
} from 'lucide-react'
import { useDataset } from '../../hooks/useDataset'

const navItems = [
  { path: '/', label: 'Overview', icon: LayoutDashboard },
  { path: '/explorer', label: 'Air Explorer', icon: Wind },
  { path: '/clustering', label: 'Clustering', icon: GitBranch },
  { path: '/spatial', label: 'Spatial Map', icon: Map },
  { path: '/anomaly', label: 'Anomalies', icon: AlertTriangle },
  { path: '/risk', label: 'Risk Profiling', icon: Shield },
  { path: '/correlation', label: 'Correlation', icon: BarChart3 },
  { path: '/datasets', label: 'Datasets', icon: Database },
  { path: '/reports', label: 'Reports', icon: FileText },
  { path: '/about', label: 'About', icon: Info },
]

export const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false)
  const { datasets, selectedDatasetId, setSelectedDatasetId, isLoading } = useDataset()

  return (
    <aside
      className={`fixed top-0 left-0 h-screen z-30 transition-all duration-300 ease-in-out flex flex-col border-r border-slate-800 bg-slate-950/95 backdrop-blur-xl ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center shadow-lg shadow-teal-500/20 shrink-0">
            <Activity className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          {!collapsed && (
            <div className="flex flex-col min-w-0">
              <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-teal-300 via-emerald-300 to-slate-100 bg-clip-text text-transparent truncate">
                AirMine
              </span>
              <span className="text-[10px] tracking-wider uppercase text-slate-400 font-semibold truncate">
                Pattern Mining & AI
              </span>
            </div>
          )}
        </div>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1.5 rounded-lg text-slate-400 hover:text-teal-300 hover:bg-slate-800/60 transition-colors"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto overflow-x-hidden">
        {navItems.map((item) => {
          const Icon = item.icon
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200 group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-teal-500/20 to-emerald-500/5 text-teal-300 border-l-4 border-teal-400 font-medium shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/80'
                } ${collapsed ? 'justify-center px-0' : ''}`
              }
              title={collapsed ? item.label : undefined}
            >
              <Icon className="w-5 h-5 shrink-0 transition-transform group-hover:scale-110" />
              {!collapsed && <span className="truncate">{item.label}</span>}
              {collapsed && (
                <div className="absolute left-full ml-3 px-2.5 py-1 bg-slate-900 text-teal-300 text-xs rounded-md shadow-xl border border-slate-700/80 opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap">
                  {item.label}
                </div>
              )}
            </NavLink>
          )
        })}
      </nav>

      {/* Bottom Dataset Selector */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-900/40">
        {!collapsed ? (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-medium">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-teal-400" />
                Active Dataset
              </span>
              <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">
                {datasets.length} avail.
              </span>
            </div>
            <select
              value={selectedDatasetId ?? ''}
              onChange={(e) => setSelectedDatasetId(e.target.value ? Number(e.target.value) : null)}
              disabled={isLoading || datasets.length === 0}
              className="w-full bg-slate-900 border border-slate-700/80 text-slate-200 text-xs rounded-lg px-2.5 py-2 focus:ring-1 focus:ring-teal-400 focus:border-teal-400 outline-none transition disabled:opacity-50"
            >
              {datasets.length === 0 ? (
                <option value="">No datasets loaded</option>
              ) : (
                datasets.map((d) => (
                  <option key={d.id} value={d.id}>
                    #{d.id} - {d.name} ({d.row_count} rows)
                  </option>
                ))
              )}
            </select>
          </div>
        ) : (
          <div className="flex justify-center" title="Active Dataset">
            <div className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-700/80 flex items-center justify-center text-teal-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
        )}
      </div>
    </aside>
  )
}
