"""Report generation service for PDF and CSV export formats."""

import io
import csv
from datetime import datetime
from typing import Dict, List, Any, Optional
from fpdf import FPDF


def _sanitize_pdf_text(text: Any) -> str:
    """Sanitize strings to ensure compatibility with standard FPDF latin-1 fonts."""
    if text is None:
        return ""
    s = str(text)
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "--",
        "\u00b0": "deg ",
        "\u03bc": "u",
        "\u2265": ">=",
        "\u2264": "<=",
        "\u00b1": "+/-",
        "\u2022": "*",
    }
    for k, v in replacements.items():
        s = s.replace(k, v)
    return s.encode("latin-1", "replace").decode("latin-1")


class AirQualityPDF(FPDF):
    """Custom styled PDF document for Air Quality analysis reports."""

    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.set_text_color(100, 116, 139)  # Slate-500
        self.cell(0, 8, "Air Quality Data Mining System - Analytical Report", border=0, align="L")
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(148, 163, 184)
        page_str = f"Page {self.page_no()}"
        self.cell(0, 10, page_str, border=0, align="C")

    def chapter_title(self, title: str):
        self.set_font("Helvetica", "B", 14)
        self.set_text_color(15, 23, 42)  # Slate-900
        self.set_fill_color(241, 245, 249)  # Slate-100
        self.cell(0, 10, f"  {_sanitize_pdf_text(title)}", fill=True, ln=True, align="L")
        self.ln(3)

    def section_title(self, title: str):
        self.set_font("Helvetica", "B", 11)
        self.set_text_color(30, 41, 59)
        self.cell(0, 7, _sanitize_pdf_text(title), ln=True, align="L")
        self.ln(1)


def generate_pdf_report(dataset_info: Dict[str, Any], analyses: List[Dict[str, Any]]) -> bytes:
    """
    Generate a formatted multi-section analytical PDF report.
    
    Includes:
    - Cover Header & Metadata
    - Executive Summary
    - Data Quality & Cleaning Metrics
    - Individual Analysis Summaries (Clustering, Anomaly, Risk, Correlation, Spatial)
    
    Returns:
        bytes: Raw PDF document bytes
    """
    pdf = AirQualityPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # --- Title Banner ---
    pdf.set_fill_color(30, 58, 138)  # Deep blue
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 20)
    pdf.cell(0, 16, " AIR QUALITY ANALYSIS REPORT", fill=True, ln=True, align="L")

    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(226, 232, 240)
    pdf.set_fill_color(49, 46, 129)
    current_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pdf.cell(0, 8, f" Generated on: {current_time_str}", fill=True, ln=True, align="L")
    pdf.ln(6)

    # --- Dataset Overview Section ---
    pdf.chapter_title("1. Dataset Overview")
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(51, 65, 85)

    name = dataset_info.get("name", "Unknown Dataset")
    orig_name = dataset_info.get("original_filename", "N/A")
    row_count = dataset_info.get("row_count", 0)
    col_count = dataset_info.get("column_count", 0)
    has_coords = "Yes" if dataset_info.get("has_coordinates") else "No"
    has_times = "Yes" if dataset_info.get("has_timestamps") else "No"

    meta_rows = [
        ("Dataset Name:", str(name)),
        ("Source File:", str(orig_name)),
        ("Total Records:", f"{row_count:,}"),
        ("Attributes:", str(col_count)),
        ("Geographic Coordinates:", has_coords),
        ("Time-Series Stamps:", has_times),
    ]

    for label, val in meta_rows:
        pdf.set_font("Helvetica", "B", 9)
        pdf.cell(48, 6, _sanitize_pdf_text(label), border=0)
        pdf.set_font("Helvetica", "", 9)
        pdf.cell(0, 6, _sanitize_pdf_text(val), ln=True, border=0)

    pdf.ln(4)

    # --- Data Cleaning & Quality Section ---
    pdf.chapter_title("2. Data Quality & Preprocessing")
    cleaning = dataset_info.get("cleaning_report", {})

    pdf.set_fill_color(248, 250, 252)
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_text_color(71, 85, 105)
    pdf.cell(90, 7, "Quality Metric", border=1, fill=True)
    pdf.cell(50, 7, "Value", border=1, fill=True, align="R")
    pdf.ln()

    cleaning_rows = [
        ("Initial Records Processed", f"{cleaning.get('initial_rows', row_count):,}"),
        ("Final Cleaned Records", f"{cleaning.get('final_rows', row_count):,}"),
        ("Duplicates Removed", f"{cleaning.get('removed_rows', 0):,}"),
        ("Missing Values Imputed", f"{cleaning.get('missing_values_filled', 0):,}"),
        ("Out-of-Bounds / Invalid Replaced", f"{cleaning.get('invalid_values_replaced', 0):,}"),
    ]

    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(30, 41, 59)
    for metric, val in cleaning_rows:
        pdf.cell(90, 6, _sanitize_pdf_text(metric), border=1)
        pdf.cell(50, 6, _sanitize_pdf_text(val), border=1, align="R")
        pdf.ln()

    pdf.ln(6)

    # --- Analytical Findings Section ---
    pdf.chapter_title("3. Analytical Findings")

    if not analyses:
        pdf.set_font("Helvetica", "I", 9)
        pdf.cell(0, 6, "No analyses have been executed on this dataset yet.", ln=True)
    else:
        for a_idx, analysis in enumerate(analyses, start=1):
            atype = analysis.get("analysis_type", "Unknown")
            results = analysis.get("results", {})
            summary = analysis.get("summary", {})

            pdf.section_title(f"3.{a_idx} {atype.capitalize()} Analysis")

            if atype.lower() == "clustering":
                n_clusters = results.get("n_clusters", "N/A")
                sil = results.get("silhouette_score", "N/A")
                inertia = results.get("inertia", "N/A")

                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"Cluster Count: {n_clusters} | Silhouette Score: {sil} | Inertia: {inertia}", ln=True)

                # Cluster sizes table
                cluster_sizes = results.get("cluster_sizes", {})
                if cluster_sizes:
                    pdf.ln(2)
                    pdf.set_font("Helvetica", "B", 8)
                    pdf.cell(40, 5, "Cluster ID", border=1, fill=True)
                    pdf.cell(40, 5, "Record Count", border=1, fill=True, align="R")
                    pdf.ln()
                    pdf.set_font("Helvetica", "", 8)
                    for cid, cnt in cluster_sizes.items():
                        pdf.cell(40, 5, f"Cluster {cid}", border=1)
                        pdf.cell(40, 5, f"{cnt:,}", border=1, align="R")
                        pdf.ln()

            elif atype.lower() == "anomaly":
                total = results.get("total_records", 0)
                count = results.get("anomaly_count", 0)
                pct = results.get("anomaly_percentage", 0.0)
                stats_info = results.get("score_stats", {})

                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"Anomalies Detected: {count:,} of {total:,} ({pct}%)", ln=True)
                pdf.cell(0, 5, f"Score Stats: Min={stats_info.get('min')}, Max={stats_info.get('max')}, Mean={stats_info.get('mean')}", ln=True)

            elif atype.lower() == "risk":
                ov_risk = results.get("overall_risk", "N/A")
                ov_score = results.get("overall_score", "N/A")
                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"Overall Risk Level: {ov_risk} (Index Score: {ov_score})", ln=True)

                dist = results.get("risk_distribution", {})
                if dist:
                    pdf.ln(2)
                    pdf.set_font("Helvetica", "B", 8)
                    pdf.cell(45, 5, "Category", border=1, fill=True)
                    pdf.cell(35, 5, "Count", border=1, fill=True, align="R")
                    pdf.ln()
                    pdf.set_font("Helvetica", "", 8)
                    for cat, c_val in dist.items():
                        pdf.cell(45, 5, _sanitize_pdf_text(cat), border=1)
                        pdf.cell(35, 5, f"{c_val:,}", border=1, align="R")
                        pdf.ln()

                recs = results.get("recommendations", [])
                if recs:
                    pdf.ln(2)
                    pdf.set_font("Helvetica", "B", 9)
                    pdf.cell(0, 5, "Key Health Recommendations:", ln=True)
                    pdf.set_font("Helvetica", "", 8)
                    for rec in recs[:3]:
                        pdf.cell(0, 5, f"- {_sanitize_pdf_text(rec)}", ln=True)

            elif atype.lower() == "correlation":
                sig_pairs = results.get("significant_pairs", [])
                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"Identified {len(sig_pairs)} statistically significant feature correlations (p < 0.05).", ln=True)

                if sig_pairs:
                    pdf.ln(2)
                    pdf.set_font("Helvetica", "B", 8)
                    pdf.cell(35, 5, "Feature 1", border=1, fill=True)
                    pdf.cell(35, 5, "Feature 2", border=1, fill=True)
                    pdf.cell(25, 5, "Pearson r", border=1, fill=True, align="R")
                    pdf.cell(25, 5, "p-value", border=1, fill=True, align="R")
                    pdf.ln()
                    pdf.set_font("Helvetica", "", 8)
                    for pair in sig_pairs[:5]:
                        pdf.cell(35, 5, _sanitize_pdf_text(pair.get("col1")), border=1)
                        pdf.cell(35, 5, _sanitize_pdf_text(pair.get("col2")), border=1)
                        pdf.cell(25, 5, str(pair.get("correlation")), border=1, align="R")
                        pdf.cell(25, 5, str(pair.get("p_value")), border=1, align="R")
                        pdf.ln()

            elif atype.lower() == "spatial":
                stations = results.get("stations", [])
                hotspots = results.get("hotspot_count", 0)
                pdf.set_font("Helvetica", "", 9)
                pdf.cell(0, 5, f"Stations Evaluated: {len(stations)} | Hotspot Stations: {hotspots}", ln=True)

            pdf.ln(4)

    return bytes(pdf.output())


def generate_csv_report(analysis_result: Dict[str, Any]) -> str:
    """
    Convert an analysis result structure into a clean CSV string.
    
    If the result contains primary tabular records (e.g., clustered_data, anomaly_data,
    significant_pairs, stations, trends), exports records with metadata headers.
    Otherwise, flattens the nested dictionary into key-value pairs.
    """
    output = io.StringIO()
    writer = csv.writer(output)

    # 1. Check for primary tabular arrays
    results_dict = analysis_result.get("results", analysis_result)

    tabular_keys = [
        "clustered_data",
        "anomaly_data",
        "significant_pairs",
        "stations",
        "trends",
        "risk_data",
    ]

    primary_table: Optional[List[Dict[str, Any]]] = None
    table_name = ""

    for k in tabular_keys:
        if k in results_dict and isinstance(results_dict[k], list) and len(results_dict[k]) > 0:
            if isinstance(results_dict[k][0], dict):
                primary_table = results_dict[k]
                table_name = k
                break

    if primary_table:
        # Export as tabular data
        # Get consistent header from first record
        keys = list(primary_table[0].keys())
        writer.writerow(keys)
        for row in primary_table:
            writer.writerow([row.get(k, "") for k in keys])
    else:
        # Flatten dictionary
        writer.writerow(["Parameter", "Value"])

        def _flatten(obj: Any, prefix: str = ""):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    sub_key = f"{prefix}.{k}" if prefix else str(k)
                    _flatten(v, sub_key)
            elif isinstance(obj, list):
                writer.writerow([prefix, f"[{len(obj)} items]"])
            else:
                writer.writerow([prefix, str(obj)])

        _flatten(analysis_result)

    return output.getvalue()
