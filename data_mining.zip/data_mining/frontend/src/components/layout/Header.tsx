import React from 'react'
import { useLocation } from 'react-router-dom'
import { useDataset } from '../../hooks/useDataset'
import { Activity, Database, CheckCircle2, AlertCircle } from 'lucide-react'

const pageTitles: Record<string, { title: string; subtitle: string }> = {
  '/': { title: 'Executive Overview', subtitle: 'Real-time air pollution metrics & critical KPIs' },
  '/explorer': { title: 'Air Quality Explorer', subtitle: 'Interactive multi-dimensional pollution explorer' },
  '/clustering': { title: 'Temporal Clustering', subtitle: 'Unsupervised K-Means temporal pattern detection' },
  '/spatial': { title: 'Spatial Pollution Map', subtitle: 'Geographic hotspot monitoring & station clustering' },
  '/anomaly': { title: 'Anomaly Detection', subtitle: 'Isolation Forest automated anomaly scoring' },
  '/risk': { title: 'Risk Profiling', subtitle: 'Air Quality Index classification & health advisories' },
  '/correlation': { title: 'Correlation Analysis', subtitle: 'Cross-pollutant correlation matrix & collinearity' },
  '/datasets': { title: 'Dataset Management', subtitle: 'Upload, preprocess, and map air quality datasets' },
  '/reports': { title: 'Analytics Reports', subtitle: 'Export analytical findings into PDF & CSV dossiers' },
  '/about': { title: 'About AirMine', subtitle: 'System architecture, algorithms & methodology' },
}

export const Header: React.FC = () => {
  const location = useLocation()
  const { selectedDataset, isLoading, error } = useDataset()

  const currentInfo = pageTitles[location.pathname] || {
    title: 'Analytics Console',
    subtitle: 'Air Quality Environmental Intelligence',
  }

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Page Title & Breadcrumb */}
      <div>
        <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          {currentInfo.title}
        </h1>
        <p className="text-xs text-slate-400 font-medium hidden sm:block">
          {currentInfo.subtitle}
        </p>
      </div>

      {/* Right status badges */}
      <div className="flex items-center gap-3">
        {/* Backend status indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs">
          {error ? (
            <>
              <AlertCircle className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span className="text-rose-400 font-medium">Backend Disconnected</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-300">API Connected</span>
            </>
          )}
        </div>

        {/* Selected Dataset Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700/80">
          <Database className="w-3.5 h-3.5 text-teal-400" />
          {isLoading ? (
            <span className="text-xs text-slate-400 animate-pulse">Loading dataset...</span>
          ) : selectedDataset ? (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-200 font-semibold max-w-[140px] truncate">
                {selectedDataset.name}
              </span>
              <span className="px-1.5 py-0.2 bg-teal-500/20 text-teal-300 rounded text-[10px] font-mono">
                {selectedDataset.row_count} rows
              </span>
            </div>
          ) : (
            <span className="text-xs text-amber-400/90 font-medium">No dataset selected</span>
          )}
        </div>
      </div>
    </header>
  )
}
