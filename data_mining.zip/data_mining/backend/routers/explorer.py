"""Explorer router for querying, filtering, sorting, and paginating raw dataset records."""

import math
from typing import Optional
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
import pandas as pd
import numpy as np

from database import get_db
from schemas import ExplorerResponse
from routers.helpers import get_dataset_or_404, get_dataset_df

router = APIRouter()


@router.get("/data", response_model=ExplorerResponse)
def get_explorer_data(
    dataset_id: int = Query(..., description="Target dataset ID"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(50, ge=1, le=500, description="Items per page"),
    pollutant: Optional[str] = Query(None, description="Optional pollutant column to filter by"),
    station: Optional[str] = Query(None, description="Optional station_id filter"),
    sort_by: Optional[str] = Query(None, description="Column to sort by"),
    sort_order: str = Query("asc", regex="^(asc|desc)$", description="Sort direction ('asc' or 'desc')"),
    db: Session = Depends(get_db),
):
    """
    Search, filter, sort, and paginate through records of a dataset.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    # 1. Filter by station if provided
    if station and station.strip():
        station_clean = station.strip()
        if "station_id" in df.columns:
            df = df[df["station_id"].astype(str) == station_clean]

    # 2. Filter columns if specific pollutant requested
    if pollutant and pollutant.strip():
        pollutant_clean = pollutant.strip()
        if pollutant_clean in df.columns:
            selected_cols = []
            for meta_col in ["timestamp", "station_id"]:
                if meta_col in df.columns and meta_col not in selected_cols:
                    selected_cols.append(meta_col)
            if pollutant_clean not in selected_cols:
                selected_cols.append(pollutant_clean)
            df = df[selected_cols]

    # 3. Sort records if requested
    if sort_by and sort_by in df.columns:
        is_ascending = (sort_order.lower() == "asc")
        # Attempt numeric conversion for sorting if column can be coerced
        sort_series = pd.to_numeric(df[sort_by], errors="coerce")
        if sort_series.notna().sum() > 0:
            df = df.iloc[sort_series.argsort(na_position="last" if is_ascending else "first")]
            if not is_ascending:
                df = df.iloc[::-1]
        else:
            df = df.sort_values(by=sort_by, ascending=is_ascending, na_position="last")

    # 4. Pagination calculations
    total = len(df)
    total_pages = max(1, math.ceil(total / page_size)) if total > 0 else 1
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size

    page_df = df.iloc[start_idx:end_idx].replace({np.nan: None})
    records = page_df.to_dict(orient="records")

    # Ensure all values are JSON safe
    cleaned_records = []
    for r in records:
        cleaned_row = {}
        for k, v in r.items():
            if isinstance(v, (np.floating, float)) and (np.isnan(v) or np.isinf(v)):
                cleaned_row[k] = None
            elif isinstance(v, (np.floating, float)):
                cleaned_row[k] = round(float(v), 4)
            elif isinstance(v, (np.integer, int)):
                cleaned_row[k] = int(v)
            else:
                cleaned_row[k] = v
        cleaned_records.append(cleaned_row)

    return ExplorerResponse(
        data=cleaned_records,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        columns=df.columns.tolist(),
    )
