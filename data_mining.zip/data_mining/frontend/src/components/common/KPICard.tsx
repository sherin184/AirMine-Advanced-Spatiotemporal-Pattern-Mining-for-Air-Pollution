import React from 'react'
import { LucideIcon } from 'lucide-react'

interface KPICardProps {
  title: string
  value: string | number | null
  subtitle?: string
  icon: LucideIcon
  accent?: 'teal' | 'emerald' | 'amber' | 'rose' | 'cyan'
  trend?: {
    value: string
    isPositive?: boolean
    label?: string
  }
}

export const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  accent = 'teal',
  trend,
}) => {
  const accentStyles = {
    teal: {
      bg: 'from-teal-500/10 to-transparent',
      border: 'hover:border-teal-500/40',
      iconBg: 'bg-teal-500/15 text-teal-400',
      glow: 'shadow-teal-500/5',
      textAccent: 'text-teal-400',
    },
    emerald: {
      bg: 'from-emerald-500/10 to-transparent',
      border: 'hover:border-emerald-500/40',
      iconBg: 'bg-emerald-500/15 text-emerald-400',
      glow: 'shadow-emerald-500/5',
      textAccent: 'text-emerald-400',
    },
    amber: {
      bg: 'from-amber-500/10 to-transparent',
      border: 'hover:border-amber-500/40',
      iconBg: 'bg-amber-500/15 text-amber-400',
      glow: 'shadow-amber-500/5',
      textAccent: 'text-amber-400',
    },
    rose: {
      bg: 'from-rose-500/10 to-transparent',
      border: 'hover:border-rose-500/40',
      iconBg: 'bg-rose-500/15 text-rose-400',
      glow: 'shadow-rose-500/5',
      textAccent: 'text-rose-400',
    },
    cyan: {
      bg: 'from-cyan-500/10 to-transparent',
      border: 'hover:border-cyan-500/40',
      iconBg: 'bg-cyan-500/15 text-cyan-400',
      glow: 'shadow-cyan-500/5',
      textAccent: 'text-cyan-400',
    },
  }[accent]

  return (
    <div
      className={`glass-card p-5 bg-gradient-to-br ${accentStyles.bg} transition-all duration-300 hover:scale-[1.02] hover:shadow-xl ${accentStyles.glow} ${accentStyles.border} group`}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase">
            {title}
          </span>
          <div className="text-2xl font-bold tracking-tight text-slate-100 flex items-baseline gap-2">
            <span>{value !== null && value !== undefined ? value : '—'}</span>
          </div>
        </div>
        <div className={`p-2.5 rounded-xl ${accentStyles.iconBg} transition-transform group-hover:scale-110`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>

      {(subtitle || trend) && (
        <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-800/60">
          {subtitle && <span className="text-slate-400 truncate">{subtitle}</span>}
          {trend && (
            <span
              className={`font-semibold ml-auto flex items-center gap-1 ${
                trend.isPositive ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              <span>{trend.value}</span>
              {trend.label && <span className="text-slate-500 text-[10px]">{trend.label}</span>}
            </span>
          )}
        </div>
      )}
    </div>
  )
}
export default KPICard
