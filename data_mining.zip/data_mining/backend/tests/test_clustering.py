"""Unit tests for clustering service (K-Means and Elbow method)."""

import pandas as pd
import numpy as np
import pytest

from services.clustering_service import run_kmeans, run_elbow


@pytest.fixture
def synthetic_clustering_df():
    """Generate reproducible synthetic data with two well-separated clusters."""
    np.random.seed(42)
    # Cluster 1: Clean air
    c1_pm25 = np.random.normal(loc=15.0, scale=3.0, size=50)
    c1_pm10 = np.random.normal(loc=30.0, scale=5.0, size=50)
    c1_no2 = np.random.normal(loc=20.0, scale=4.0, size=50)

    # Cluster 2: Heavy pollution
    c2_pm25 = np.random.normal(loc=180.0, scale=15.0, size=50)
    c2_pm10 = np.random.normal(loc=300.0, scale=20.0, size=50)
    c2_no2 = np.random.normal(loc=95.0, scale=10.0, size=50)

    df = pd.DataFrame({
        "PM2_5": np.concatenate([c1_pm25, c2_pm25]),
        "PM10": np.concatenate([c1_pm10, c2_pm10]),
        "NO2": np.concatenate([c1_no2, c2_no2]),
        "temperature": np.random.uniform(15.0, 30.0, size=100),
    })
    return df


def test_run_kmeans_returns_valid_clusters(synthetic_clustering_df):
    """Test that K-Means clustering partitions data correctly and returns required keys."""
    features = ["PM2_5", "PM10", "NO2"]
    k = 2
    result = run_kmeans(synthetic_clustering_df, features=features, n_clusters=k)

    # Assert schema & fields
    assert "n_clusters" in result
    assert result["n_clusters"] == 2
    assert "cluster_labels" in result
    assert len(result["cluster_labels"]) == len(synthetic_clustering_df)
    assert set(result["cluster_labels"]) == {0, 1}

    # Centroids
    assert "centroids" in result
    assert len(result["centroids"]) == 2
    for centroid in result["centroids"]:
        assert "cluster" in centroid
        for feat in features:
            assert feat in centroid

    # Quality metrics
    assert "silhouette_score" in result
    assert -1.0 <= result["silhouette_score"] <= 1.0
    # Separation between clean and heavy pollution should yield strong silhouette score
    assert result["silhouette_score"] > 0.5

    assert "inertia" in result
    assert result["inertia"] > 0.0

    # Cluster sizes
    assert "cluster_sizes" in result
    assert sum(result["cluster_sizes"].values()) == 100

    # Clustered records
    assert "clustered_data" in result
    assert len(result["clustered_data"]) == 100
    assert "cluster" in result["clustered_data"][0]


def test_run_kmeans_auto_selects_features(synthetic_clustering_df):
    """Test feature auto-selection when empty feature list is passed."""
    result = run_kmeans(synthetic_clustering_df, features=[], n_clusters=3)
    assert result["n_clusters"] == 3
    assert len(result["feature_names"]) > 0
    assert "PM2_5" in result["feature_names"]


def test_run_elbow_evaluates_k_range(synthetic_clustering_df):
    """Test that Elbow analysis calculates inertia and silhouette for expected k values."""
    features = ["PM2_5", "PM10"]
    max_k = 6
    result = run_elbow(synthetic_clustering_df, features=features, max_k=max_k)

    assert "k_values" in result
    assert "inertias" in result
    assert "silhouette_scores" in result

    expected_k_values = [2, 3, 4, 5, 6]
    assert result["k_values"] == expected_k_values
    assert len(result["inertias"]) == len(expected_k_values)
    assert len(result["silhouette_scores"]) == len(expected_k_values)

    # Inertia must decrease monotonically with increasing k
    for i in range(len(result["inertias"]) - 1):
        assert result["inertias"][i] >= result["inertias"][i + 1]
