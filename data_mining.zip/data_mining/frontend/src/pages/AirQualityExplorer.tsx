import React, { useState, useEffect, useMemo } from 'react'
import {
  Wind,
  Search,
  Filter,
  RefreshCw,
  TrendingUp,
  MapPin,
  Calendar,
  Layers,
} from 'lucide-react'
import { useDataset } from '../hooks/useDataset'
import { api } from '../api/client'
import { DataTable, ColumnDef } from '../components/common/DataTable'
import { PollutantLineChart } from '../components/charts/PollutantLineChart'
import { DateRangeFilter } from '../components/filters/DateRangeFilter'
import { PollutantFilter } from '../components/filters/PollutantFilter'
import { LoadingSpinner } from '../components/common/LoadingSpinner'
import type { ExplorerResponse, TrendDataPoint } from '../types'

export const AirQualityExplorer: React.FC = () => {
  const { selectedDatasetId, selectedDataset } = useDataset()

  // Filters
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(50)
  const [selectedStation, setSelectedStation] = useState<string>('')
  const [selectedPollutants, setSelectedPollutants] = useState<string[]>(['pm25', 'pm10', 'no2'])
  const [startDate, setStartDate] = useState<string>('')
  const [endDate, setEndDate] = useState<string>('')

  // State
  const [explorerData, setExplorerData] = useState<ExplorerResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Fetch explorer data
  const fetchData = async () => {
    if (!selectedDatasetId) return
    setLoading(true)
    setError(null)
    try {
      const res = await api.explorer.getData({
        dataset_id: selectedDatasetId,
        page,
        page_size: pageSize,
        station: selectedStation || undefined,
        pollutant: selectedPollutants.join(',') || undefined,
        start_date: startDate || undefined,
        end_date: endDate || undefined,
      })
      setExplorerData(res)
    } catch (err: any) {
      console.error('Failed to load explorer data:', err)
      setError(err?.response?.data?.detail || err?.message || 'Failed to fetch explorer data')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    setPage(1)
  }, [selectedStation, selectedPollutants, startDate, endDate, selectedDatasetId])

  useEffect(() => {
    fetchData()
  }, [selectedDatasetId, page, pageSize, selectedStation, selectedPollutants, startDate, endDate])

  // Extract all available columns and pollutants
  const availablePollutants = useMemo(() => {
    if (!selectedDataset?.columns_list) return ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3', 'aqi']
    const pollutants = ['pm25', 'pm10', 'no2', 'so2', 'co', 'o3', 'aqi', 'temp', 'humidity']
    return selectedDataset.columns_list.filter((col) =>
      pollutants.some((p) => col.toLowerCase().includes(p))
    )
  }, [selectedDataset])

  // Extract distinct station IDs from explorer rows or sample
  const availableStations = useMemo(() => {
    if (!explorerData?.data) return []
    const stations = new Set<string>()
    explorerData.data.forEach((row) => {
      const s = row.station_id || row.station || row.site
      if (s) stations.add(String(s))
    })
    return Array.from(stations)
  }, [explorerData])

  // Format table columns
  const tableColumns: ColumnDef[] = useMemo(() => {
    if (!explorerData?.columns || explorerData.columns.length === 0) return []
    return explorerData.columns.map((colName) => ({
      key: colName,
      header: colName.toUpperCase().replace(/_/g, ' '),
      sortable: true,
      render: (row) => {
        const val = row[colName]
        if (val === null || val === undefined) return <span className="text-slate-600">—</span>
        if (typeof val === 'number') {
          return (
            <span
              className={`font-mono ${
                colName.includes('aqi') || colName.includes('pm')
                  ? val > 150
                    ? 'text-rose-400 font-bold'
                    : val > 50
                    ? 'text-amber-400'
                    : 'text-teal-300'
                  : 'text-slate-300'
              }`}
            >
              {val % 1 !== 0 ? val.toFixed(2) : val}
            </span>
          )
        }
        return <span className="text-slate-300">{String(val)}</span>
      },
    }))
  }, [explorerData?.columns])

  // Convert current table rows to TrendDataPoints for instant charting
  const chartTrends: TrendDataPoint[] = useMemo(() => {
    if (!explorerData?.data || explorerData.data.length === 0) return []
    // Take sorted sample up to 100 points
    return explorerData.data
      .slice(0, 100)
      .map((row, idx) => {
        const timestamp =
          row.timestamp || row.date || row.datetime || `Obs #${(page - 1) * pageSize + idx + 1}`
        const values: Record<string, number | null> = {}
        selectedPollutants.forEach((p) => {
          const val = row[p]
          values[p] = typeof val === 'number' ? val : parseFloat(val) || null
        })
        return {
          timestamp: String(timestamp),
          values,
        }
      })
      .reverse()
  }, [explorerData?.data, selectedPollutants, page, pageSize])

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Filter Bar */}
      <div className="glass-card p-5 border border-slate-800/80 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Wind className="w-5 h-5 text-teal-400" />
              Air Quality Data Explorer
            </h2>
            <p className="text-xs text-slate-400">
              Interactive multi-dimensional filtering, sensor logs & time series inspection
            </p>
          </div>

          <button
            onClick={fetchData}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-teal-400 text-slate-300 hover:text-teal-300 text-xs transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reload Query</span>
          </button>
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Station dropdown */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs">
            <MapPin className="w-3.5 h-3.5 text-teal-400" />
            <select
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
              className="bg-transparent text-slate-200 outline-none cursor-pointer"
            >
              <option value="" className="bg-slate-900 text-slate-400">
                All Monitoring Stations
              </option>
              {availableStations.map((st) => (
                <option key={st} value={st} className="bg-slate-900 text-slate-200">
                  Station: {st}
                </option>
              ))}
            </select>
          </div>

          {/* Pollutant multi-select */}
          <PollutantFilter
            availablePollutants={availablePollutants}
            selectedPollutants={selectedPollutants}
            onChange={setSelectedPollutants}
          />

          {/* Date Range filter */}
          <DateRangeFilter
            startDate={startDate}
            endDate={endDate}
            onStartDateChange={setStartDate}
            onEndDateChange={setEndDate}
            onReset={() => {
              setStartDate('')
              setEndDate('')
            }}
          />

          {/* Page size select */}
          <div className="ml-auto flex items-center gap-2 text-xs text-slate-400">
            <span>Rows:</span>
            <select
              value={pageSize}
              onChange={(e) => setPageSize(Number(e.target.value))}
              className="bg-slate-900 border border-slate-700/80 text-slate-200 rounded-lg px-2 py-1 outline-none font-mono"
            >
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>
        </div>
      </div>

      {/* Explorer Time Series Visualizer */}
      <div className="glass-card p-6 border border-slate-800/80">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-bold text-slate-200">
              Selected Query Dynamics ({selectedPollutants.join(', ').toUpperCase() || 'All'})
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Plotting current slice ({chartTrends.length} records)
          </span>
        </div>

        <PollutantLineChart
          data={chartTrends}
          selectedPollutants={selectedPollutants}
          height={280}
        />
      </div>

      {/* Data Table */}
      {loading ? (
        <LoadingSpinner message="Querying dataset partitions..." />
      ) : error ? (
        <div className="glass-card p-8 text-center text-rose-400 text-xs border border-rose-500/30">
          <p className="font-semibold mb-1">Failed to query explorer dataset</p>
          <p className="text-slate-400">{error}</p>
        </div>
      ) : (
        <DataTable
          columns={tableColumns}
          data={explorerData?.data || []}
          pageSize={pageSize}
          totalRows={explorerData?.total || 0}
          currentPage={page}
          onPageChange={setPage}
          serverPagination={true}
          searchPlaceholder="Quick filter visible rows..."
        />
      )}
    </div>
  )
}
export default AirQualityExplorer
