import React, { useState, useRef, useEffect } from 'react'
import { Filter, Check, ChevronDown } from 'lucide-react'

interface PollutantFilterProps {
  availablePollutants: string[]
  selectedPollutants: string[]
  onChange: (selected: string[]) => void
}

export const PollutantFilter: React.FC<PollutantFilterProps> = ({
  availablePollutants,
  selectedPollutants,
  onChange,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const togglePollutant = (pollutant: string) => {
    if (selectedPollutants.includes(pollutant)) {
      onChange(selectedPollutants.filter((p) => p !== pollutant))
    } else {
      onChange([...selectedPollutants, pollutant])
    }
  }

  const selectAll = () => onChange(availablePollutants)
  const clearAll = () => onChange([])

  return (
    <div className="relative inline-block text-xs" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 hover:border-teal-400 text-slate-200 transition"
      >
        <Filter className="w-3.5 h-3.5 text-teal-400" />
        <span>
          Pollutants (
          <span className="text-teal-300 font-semibold">{selectedPollutants.length}</span>/
          {availablePollutants.length})
        </span>
        <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-700/90 shadow-2xl z-50 p-2 animate-slide-up">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px]">
            <button
              onClick={selectAll}
              className="text-teal-400 hover:text-teal-300 font-medium"
            >
              Select All
            </button>
            <button
              onClick={clearAll}
              className="text-slate-400 hover:text-slate-300"
            >
              Clear
            </button>
          </div>

          <div className="max-h-56 overflow-y-auto space-y-1">
            {availablePollutants.map((pollutant) => {
              const isChecked = selectedPollutants.includes(pollutant)
              return (
                <div
                  key={pollutant}
                  onClick={() => togglePollutant(pollutant)}
                  className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-slate-800/80 cursor-pointer text-slate-300 transition select-none"
                >
                  <span className="uppercase font-mono text-[11px]">{pollutant}</span>
                  <div
                    className={`w-4 h-4 rounded flex items-center justify-center border transition ${
                      isChecked
                        ? 'bg-teal-500 border-teal-500 text-slate-950'
                        : 'border-slate-600 bg-slate-800'
                    }`}
                  >
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
export default PollutantFilter
