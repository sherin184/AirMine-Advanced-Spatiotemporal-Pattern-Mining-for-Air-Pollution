"""Clustering router for K-Means and Elbow evaluation."""

from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from models import AnalysisResult
from schemas import ClusteringRequest, ClusteringResponse, ElbowResponse
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.clustering_service import run_kmeans, run_elbow

router = APIRouter()


@router.post("/run", response_model=ClusteringResponse, status_code=status.HTTP_201_CREATED)
def execute_clustering(
    request: ClusteringRequest,
    db: Session = Depends(get_db),
):
    """
    Execute K-Means clustering algorithm on dataset features and persist analysis record.
    """
    dataset = get_dataset_or_404(db, request.dataset_id)
    df = get_dataset_df(dataset)

    try:
        results = run_kmeans(
            df=df,
            features=request.features or [],
            n_clusters=request.n_clusters,
        )
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Clustering failed: {str(e)}",
        )

    # Save to AnalysisResult
    analysis = AnalysisResult(
        dataset_id=request.dataset_id,
        analysis_type="clustering",
        parameters={
            "n_clusters": results["n_clusters"],
            "features": results["feature_names"],
        },
        results=results,
        summary={
            "n_clusters": results["n_clusters"],
            "silhouette_score": results["silhouette_score"],
            "inertia": results["inertia"],
            "cluster_sizes": results["cluster_sizes"],
        },
        status="completed",
    )

    db.add(analysis)
    db.commit()
    db.refresh(analysis)

    return ClusteringResponse(
        analysis_id=analysis.id,
        n_clusters=results["n_clusters"],
        silhouette_score=results["silhouette_score"],
        inertia=results["inertia"],
        cluster_sizes=results["cluster_sizes"],
        centroids=results["centroids"],
        clustered_data=results["clustered_data"],
        feature_names=results["feature_names"],
    )


@router.get("/elbow", response_model=ElbowResponse)
def get_elbow_evaluation(
    dataset_id: int = Query(..., description="Target dataset ID"),
    features: Optional[List[str]] = Query(None, description="Feature columns to evaluate"),
    db: Session = Depends(get_db),
):
    """
    Compute elbow curve inertias and silhouette scores across cluster counts.
    """
    dataset = get_dataset_or_404(db, dataset_id)
    df = get_dataset_df(dataset)

    try:
        results = run_elbow(df=df, features=features or [], max_k=10)
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Elbow evaluation failed: {str(e)}",
        )

    return ElbowResponse(
        k_values=results["k_values"],
        inertias=results["inertias"],
        silhouette_scores=results["silhouette_scores"],
    )


@router.get("/results/{analysis_id}", response_model=ClusteringResponse)
def get_clustering_result(analysis_id: int, db: Session = Depends(get_db)):
    """
    Retrieve stored clustering analysis results by analysis ID.
    """
    analysis = db.query(AnalysisResult).filter(AnalysisResult.id == analysis_id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail=f"Analysis result {analysis_id} not found.")

    if analysis.analysis_type != "clustering":
        raise HTTPException(
            status_code=400,
            detail=f"Analysis {analysis_id} is of type '{analysis.analysis_type}', not 'clustering'.",
        )

    res = analysis.results or {}
    return ClusteringResponse(
        analysis_id=analysis.id,
        n_clusters=res.get("n_clusters", 0),
        silhouette_score=res.get("silhouette_score", 0.0),
        inertia=res.get("inertia", 0.0),
        cluster_sizes=res.get("cluster_sizes", {}),
        centroids=res.get("centroids", []),
        clustered_data=res.get("clustered_data", []),
        feature_names=res.get("feature_names", []),
    )
