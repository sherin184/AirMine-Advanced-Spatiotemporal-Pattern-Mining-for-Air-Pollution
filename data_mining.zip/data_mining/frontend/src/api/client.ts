import axios from 'axios'
import type {
  Dataset,
  DatasetPreview,
  ColumnInfo,
  ColumnMappingRequest,
  KPIResponse,
  TrendDataPoint,
  ExplorerResponse,
  ClusteringRequest,
  ClusteringResponse,
  ElbowResponse,
  AnomalyRequest,
  AnomalyResponse,
  SpatialResponse,
  RiskProfileResponse,
  RiskTrendResponse,
  CorrelationResponse,
  ReportListResponse,
  MessageResponse,
} from '../types'

export const API_BASE_URL = 'http://localhost:8000/api/v1'

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 60000,
})

export const api = {
  // Datasets
  datasets: {
    list: async (): Promise<Dataset[]> => {
      const response = await apiClient.get<Dataset[]>('/datasets/')
      return response.data
    },

    upload: async (file: File, name?: string, description?: string): Promise<Dataset> => {
      const formData = new FormData()
      formData.append('file', file)
      if (name) formData.append('name', name)
      if (description) formData.append('description', description)

      const response = await apiClient.post<Dataset>('/datasets/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      return response.data
    },

    loadSample: async (): Promise<Dataset> => {
      const response = await apiClient.post<Dataset>('/datasets/load-sample')
      return response.data
    },

    getById: async (id: number): Promise<DatasetPreview> => {
      const response = await apiClient.get<DatasetPreview>(`/datasets/${id}`)
      return response.data
    },

    getColumns: async (id: number): Promise<ColumnInfo[]> => {
      const response = await apiClient.get<ColumnInfo[]>(`/datasets/${id}/columns`)
      return response.data
    },

    mapColumns: async (id: number, mapping: Record<string, string>): Promise<Dataset> => {
      const payload: ColumnMappingRequest = { mapping }
      const response = await apiClient.post<Dataset>(`/datasets/${id}/map-columns`, payload)
      return response.data
    },

    delete: async (id: number): Promise<MessageResponse> => {
      const response = await apiClient.delete<MessageResponse>(`/datasets/${id}`)
      return response.data
    },
  },

  // Overview
  overview: {
    getKPIs: async (datasetId?: number): Promise<KPIResponse> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<KPIResponse>('/overview/kpis', { params })
      return response.data
    },

    getTrends: async (datasetId?: number): Promise<TrendDataPoint[]> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<TrendDataPoint[]>('/overview/trends', { params })
      return response.data
    },
  },

  // Explorer
  explorer: {
    getData: async (params: {
      dataset_id?: number
      page?: number
      page_size?: number
      pollutant?: string
      station?: string
      start_date?: string
      end_date?: string
      sort_by?: string
      sort_order?: 'asc' | 'desc'
    }): Promise<ExplorerResponse> => {
      const response = await apiClient.get<ExplorerResponse>('/explorer/data', { params })
      return response.data
    },
  },

  // Clustering
  clustering: {
    run: async (request: ClusteringRequest): Promise<ClusteringResponse> => {
      const response = await apiClient.post<ClusteringResponse>('/clustering/run', request)
      return response.data
    },

    getElbow: async (datasetId: number): Promise<ElbowResponse> => {
      const response = await apiClient.get<ElbowResponse>('/clustering/elbow', {
        params: { dataset_id: datasetId },
      })
      return response.data
    },

    getResults: async (analysisId: number): Promise<ClusteringResponse> => {
      const response = await apiClient.get<ClusteringResponse>(`/clustering/results/${analysisId}`)
      return response.data
    },
  },

  // Anomaly Detection
  anomaly: {
    run: async (request: AnomalyRequest): Promise<AnomalyResponse> => {
      const response = await apiClient.post<AnomalyResponse>('/anomaly/run', request)
      return response.data
    },

    getResults: async (analysisId: number): Promise<AnomalyResponse> => {
      const response = await apiClient.get<AnomalyResponse>(`/anomaly/results/${analysisId}`)
      return response.data
    },
  },

  // Spatial Analysis
  spatial: {
    getData: async (datasetId?: number): Promise<SpatialResponse> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<SpatialResponse>('/spatial/data', { params })
      return response.data
    },

    getHotspots: async (datasetId?: number): Promise<SpatialResponse> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<SpatialResponse>('/spatial/hotspots', { params })
      return response.data
    },
  },

  // Risk Profiling
  risk: {
    getProfile: async (datasetId?: number): Promise<RiskProfileResponse> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<RiskProfileResponse>('/risk/profile', { params })
      return response.data
    },

    getTrends: async (datasetId?: number, period: string = 'daily'): Promise<RiskTrendResponse> => {
      const params = { ...(datasetId ? { dataset_id: datasetId } : {}), period }
      const response = await apiClient.get<RiskTrendResponse>('/risk/trends', { params })
      return response.data
    },
  },

  // Correlation Analysis
  correlation: {
    getMatrix: async (datasetId?: number, columns?: string[]): Promise<CorrelationResponse> => {
      const params: Record<string, any> = {}
      if (datasetId) params.dataset_id = datasetId
      if (columns && columns.length > 0) params.columns = columns.join(',')
      const response = await apiClient.get<CorrelationResponse>('/correlation/matrix', { params })
      return response.data
    },
  },

  // Reports
  reports: {
    list: async (datasetId?: number): Promise<ReportListResponse> => {
      const params = datasetId ? { dataset_id: datasetId } : {}
      const response = await apiClient.get<ReportListResponse>('/reports/list', { params })
      return response.data
    },

    downloadCsv: async (analysisId: number, filename = `analysis_report_${analysisId}.csv`): Promise<void> => {
      const response = await apiClient.get(`/reports/csv/${analysisId}`, {
        responseType: 'blob',
      })
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    },

    downloadPdf: async (datasetId: number, filename = `air_quality_report_${datasetId}.pdf`): Promise<void> => {
      const response = await apiClient.get(`/reports/pdf/${datasetId}`, {
        responseType: 'blob',
      })
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
    },
  },
}

export default apiClient
