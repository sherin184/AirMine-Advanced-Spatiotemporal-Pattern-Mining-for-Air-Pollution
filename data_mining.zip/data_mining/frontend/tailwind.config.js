/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        aqi: {
          good: '#10b981',
          moderate: '#f59e0b',
          unhealthy_sensitive: '#f97316',
          unhealthy: '#ef4444',
          very_unhealthy: '#a855f7',
          hazardous: '#991b1b'
        }
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp: { '0%': { opacity: '0', transform: 'translateY(20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        pulseGlow: { '0%, 100%': { boxShadow: '0 0 5px rgba(45,212,191,0.3)' }, '50%': { boxShadow: '0 0 20px rgba(45,212,191,0.6)' } },
      },
    },
  },
  plugins: [],
}
