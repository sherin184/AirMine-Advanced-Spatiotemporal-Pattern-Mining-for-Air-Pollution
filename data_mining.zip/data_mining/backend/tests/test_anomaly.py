"""Unit tests for anomaly detection service using Isolation Forest."""

import pandas as pd
import numpy as np
import pytest

from services.anomaly_service import detect_anomalies


@pytest.fixture
def synthetic_anomaly_df():
    """Create a dataset of 100 normal observations and 5 extreme outliers."""
    np.random.seed(42)
    # 100 typical urban air quality readings
    normal_pm25 = np.random.normal(loc=35.0, scale=5.0, size=100)
    normal_pm10 = np.random.normal(loc=65.0, scale=8.0, size=100)
    normal_co = np.random.normal(loc=1.2, scale=0.2, size=100)

    # 5 extreme pollution spike events (e.g. fire/industrial leakage)
    outlier_pm25 = np.array([450.0, 520.0, 600.0, 750.0, 800.0])
    outlier_pm10 = np.array([800.0, 950.0, 1100.0, 1200.0, 1350.0])
    outlier_co = np.array([25.0, 30.0, 35.0, 40.0, 45.0])

    df = pd.DataFrame({
        "PM2_5": np.concatenate([normal_pm25, outlier_pm25]),
        "PM10": np.concatenate([normal_pm10, outlier_pm10]),
        "CO": np.concatenate([normal_co, outlier_co]),
    })
    return df


def test_detect_anomalies_finds_outliers(synthetic_anomaly_df):
    """Test that Isolation Forest identifies extreme pollution spikes."""
    features = ["PM2_5", "PM10", "CO"]
    # 5 outliers in 105 samples is ~0.048 contamination
    result = detect_anomalies(synthetic_anomaly_df, features=features, contamination=0.05)

    assert "total_records" in result
    assert result["total_records"] == 105

    assert "anomaly_count" in result
    assert result["anomaly_count"] > 0
    # Isolation Forest with 0.05 contamination on 105 items should flag approximately 5-6 points
    assert 4 <= result["anomaly_count"] <= 10

    assert "anomaly_percentage" in result
    assert result["anomaly_percentage"] > 0.0

    assert "anomaly_data" in result
    assert len(result["anomaly_data"]) == result["anomaly_count"]

    # Verify that the detected anomalies capture the extreme values
    anomaly_pm25_vals = [r["PM2_5"] for r in result["anomaly_data"]]
    # The extreme spike values (450+) should be flagged
    assert any(val >= 400.0 for val in anomaly_pm25_vals)

    # Validate score statistics
    assert "score_stats" in result
    stats = result["score_stats"]
    assert "min" in stats
    assert "max" in stats
    assert "mean" in stats
    assert "std" in stats
    assert stats["min"] <= stats["mean"] <= stats["max"]


def test_detect_anomalies_with_missing_values():
    """Test anomaly detection handles missing values gracefully with median imputation."""
    df = pd.DataFrame({
        "PM2_5": [25.0, 30.0, np.nan, 32.0, 450.0, 28.0, 27.0, 31.0, 29.0, 30.0],
        "PM10": [50.0, 55.0, 52.0, np.nan, 800.0, 51.0, 49.0, 53.0, 50.0, 52.0],
    })
    result = detect_anomalies(df, features=["PM2_5", "PM10"], contamination=0.1)

    assert result["total_records"] == 10
    assert result["anomaly_count"] >= 1
    # Check that row with 450 is detected
    anomalous_pm25 = [r["PM2_5"] for r in result["anomaly_data"]]
    assert 450.0 in anomalous_pm25
