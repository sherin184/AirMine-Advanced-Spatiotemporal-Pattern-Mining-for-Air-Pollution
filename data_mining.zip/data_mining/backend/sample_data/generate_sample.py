"""Generate synthetic air quality dataset for data mining and analysis."""

import os
import numpy as np
import pandas as pd


def calculate_epa_aqi(pm25: float) -> float:
    """Calculate EPA AQI based on PM2.5 concentration."""
    if np.isnan(pm25) or pm25 < 0:
        return 0.0

    breakpoints = [
        (0.0, 12.0, 0, 50),
        (12.1, 35.4, 51, 100),
        (35.5, 55.4, 101, 150),
        (55.5, 150.4, 151, 200),
        (150.5, 250.4, 201, 300),
        (250.5, 500.0, 301, 500),
    ]

    for c_lo, c_hi, i_lo, i_hi in breakpoints:
        if c_lo <= pm25 <= c_hi:
            return round(((i_hi - i_lo) / (c_hi - c_lo)) * (pm25 - c_lo) + i_lo, 1)

    if pm25 > 500.0:
        return 500.0
    return 0.0


def generate_synthetic_data(output_path: str = "synthetic_air_quality.csv") -> pd.DataFrame:
    """
    Generate realistic synthetic air quality dataset.
    
    Stations:
    - Downtown-01: (28.6139, 77.2090)
    - Industrial-02: (28.5355, 77.3910)
    - Suburban-03: (28.4595, 77.0266)
    - Highway-04: (28.7041, 77.1025)
    - Residential-05: (28.6329, 77.2195)
    """
    np.random.seed(42)

    stations = [
        {"id": "Downtown-01", "lat": 28.6139, "lon": 77.2090, "pm25_base": 65.0, "pm10_base": 120.0, "no2_base": 48.0, "so2_base": 18.0, "co_base": 2.2, "o3_base": 28.0},
        {"id": "Industrial-02", "lat": 28.5355, "lon": 77.3910, "pm25_base": 95.0, "pm10_base": 190.0, "no2_base": 55.0, "so2_base": 42.0, "co_base": 3.1, "o3_base": 22.0},
        {"id": "Suburban-03", "lat": 28.4595, "lon": 77.0266, "pm25_base": 32.0, "pm10_base": 65.0, "no2_base": 20.0, "so2_base": 8.0, "co_base": 0.9, "o3_base": 42.0},
        {"id": "Highway-04", "lat": 28.7041, "lon": 77.1025, "pm25_base": 80.0, "pm10_base": 155.0, "no2_base": 62.0, "so2_base": 22.0, "co_base": 3.8, "o3_base": 25.0},
        {"id": "Residential-05", "lat": 28.6329, "lon": 77.2195, "pm25_base": 45.0, "pm10_base": 85.0, "no2_base": 28.0, "so2_base": 12.0, "co_base": 1.4, "o3_base": 32.0},
    ]

    # Full date range for January 2024 (744 hourly timestamps)
    date_range = pd.date_range(start="2024-01-01 00:00:00", end="2024-01-31 23:00:00", freq="h")
    
    rows = []

    for st in stations:
        # Sample ~200 random hourly timestamps per station to reach exactly 1000 total rows
        selected_times = np.random.choice(date_range, size=200, replace=False)
        selected_times = sorted(pd.to_datetime(selected_times))

        for ts in selected_times:
            hour = ts.hour
            # Diurnal factor: higher during daytime rush hours (8-10, 17-20)
            if 7 <= hour <= 10 or 17 <= hour <= 20:
                time_factor = 1.35
            elif 11 <= hour <= 16:
                time_factor = 1.10
            else:
                time_factor = 0.75  # night time dip

            # Ozone peaks mid-afternoon with sunlight
            o3_factor = 1.6 if 12 <= hour <= 16 else 0.6

            # Weather simulations
            temp = round(12.0 + 8.0 * np.sin((hour - 8) * np.pi / 12) + np.random.normal(0, 1.5), 1)
            temp = float(np.clip(temp, 4.0, 28.0))

            humidity = round(70.0 - 25.0 * np.sin((hour - 8) * np.pi / 12) + np.random.normal(0, 4.0), 1)
            humidity = float(np.clip(humidity, 20.0, 95.0))

            wind_speed = round(max(0.5, 3.5 + np.random.normal(0, 1.5)), 1)

            # Inversion effect: low wind traps pollution
            inversion_boost = 1.25 if wind_speed < 2.0 else 1.0

            # Base pollutant calculation with log-normal noise
            pm25 = max(5.0, st["pm25_base"] * time_factor * inversion_boost + np.random.normal(0, 8.0))
            pm10 = max(10.0, st["pm10_base"] * time_factor * inversion_boost + np.random.normal(0, 15.0))
            no2 = max(2.0, st["no2_base"] * time_factor + np.random.normal(0, 5.0))
            so2 = max(1.0, st["so2_base"] * time_factor + np.random.normal(0, 3.0))
            co = max(0.2, st["co_base"] * time_factor + np.random.normal(0, 0.3))
            o3 = max(5.0, st["o3_base"] * o3_factor + np.random.normal(0, 4.0))

            # Introduce occasional spikes (anomalies) in ~3.5% of records
            if np.random.rand() < 0.035:
                spike_type = np.random.choice(["fire", "traffic", "industrial"])
                if spike_type == "fire":
                    pm25 *= np.random.uniform(2.5, 4.0)
                    pm10 *= np.random.uniform(2.0, 3.5)
                    co *= np.random.uniform(1.8, 2.5)
                elif spike_type == "traffic":
                    no2 *= np.random.uniform(2.2, 3.8)
                    co *= np.random.uniform(2.5, 4.5)
                    pm25 *= np.random.uniform(1.8, 2.8)
                else:
                    so2 *= np.random.uniform(3.0, 5.5)
                    pm10 *= np.random.uniform(2.0, 3.0)

            # Round concentrations
            pm25_val = round(float(pm25), 1)
            pm10_val = round(float(pm10), 1)
            no2_val = round(float(no2), 1)
            so2_val = round(float(so2), 1)
            co_val = round(float(co), 2)
            o3_val = round(float(o3), 1)

            # EPA AQI derived from PM2.5
            aqi_val = calculate_epa_aqi(pm25_val)

            rows.append({
                "timestamp": ts.strftime("%Y-%m-%d %H:%M:%S"),
                "station_id": st["id"],
                "latitude": st["lat"],
                "longitude": st["lon"],
                "PM2_5": pm25_val,
                "PM10": pm10_val,
                "NO2": no2_val,
                "SO2": so2_val,
                "CO": co_val,
                "O3": o3_val,
                "AQI": aqi_val,
                "temperature": temp,
                "humidity": humidity,
                "wind_speed": wind_speed,
            })

    df = pd.DataFrame(rows)
    # Sort by timestamp
    df = df.sort_values(by="timestamp").reset_index(drop=True)

    # Introduce ~2% random missing values in pollutant columns
    numeric_pollutants = ["PM2_5", "PM10", "NO2", "SO2", "CO", "O3", "temperature", "humidity", "wind_speed"]
    for col in numeric_pollutants:
        missing_mask = np.random.rand(len(df)) < 0.02
        df.loc[missing_mask, col] = np.nan

    # Format to string representation where NaN is empty string ""
    # Header is first line, no comments
    df.to_csv(output_path, index=False, na_rep="")
    print(f"Generated {len(df)} synthetic air quality records at: {output_path}")
    return df


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    target_csv = os.path.join(base_dir, "synthetic_air_quality.csv")
    generate_synthetic_data(target_csv)
