"""Anomaly detection router using Isolation Forest."""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from models import AnalysisResult
from schemas import AnomalyRequest, AnomalyResponse
from routers.helpers import get_dataset_or_404, get_dataset_df
from services.anomaly_service import detect_anomalies

router = APIRouter()


@router.post("/run", response_model=AnomalyResponse, status_code=status.HTTP_201_CREATED)
def execute_anomaly_detection(
    request: AnomalyRequest,
    db: Session = Depends(get_db),
):
    """
    Run Isolation Forest anomaly detection to identify pollution spikes and outliers.
    """
    dataset = get_dataset_or_404(db, request.dataset_id)
    df = get_dataset_df(dataset)

    try:
        results = detect_anomalies(
            df=df,
            features=request.features if request.features else None,
            contamination=request.contamination,
        )
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Anomaly detection failed: {str(e)}",
        )

    analysis = AnalysisResult(
        dataset_id=request.dataset_id,
        analysis_type="anomaly",
        parameters={
            "contamination": request.contamination,
            "features": results["feature_names"],
        },
        results=results,
        summary={
            "total_records": results["total_records"],
            "anomaly_count": results["anomaly_count"],
            "anomaly_percentage": results["anomaly_percentage"],
            "score_stats": results["score_stats"],
        },
        status="completed",
    )

    db.add(analysis)
    db.commit()
    db.refresh(analysis)

    return AnomalyResponse(
        analysis_id=analysis.id,
        total_records=results["total_records"],
        anomaly_count=results["anomaly_count"],
        anomaly_percentage=results["anomaly_percentage"],
        anomaly_data=results["anomaly_data"],
        normal_data=results["normal_data"],
        feature_names=results["feature_names"],
        score_stats=results["score_stats"],
    )


@router.get("/results/{analysis_id}", response_model=AnomalyResponse)
def get_anomaly_result(analysis_id: int, db: Session = Depends(get_db)):
    """
    Retrieve stored anomaly detection results by analysis ID.
    """
    analysis = db.query(AnalysisResult).filter(AnalysisResult.id == analysis_id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail=f"Analysis result {analysis_id} not found.")

    if analysis.analysis_type != "anomaly":
        raise HTTPException(
            status_code=400,
            detail=f"Analysis {analysis_id} is of type '{analysis.analysis_type}', not 'anomaly'.",
        )

    res = analysis.results or {}
    return AnomalyResponse(
        analysis_id=analysis.id,
        total_records=res.get("total_records", 0),
        anomaly_count=res.get("anomaly_count", 0),
        anomaly_percentage=res.get("anomaly_percentage", 0.0),
        anomaly_data=res.get("anomaly_data", []),
        normal_data=res.get("normal_data", []),
        feature_names=res.get("feature_names", []),
        score_stats=res.get("score_stats", {}),
    )
